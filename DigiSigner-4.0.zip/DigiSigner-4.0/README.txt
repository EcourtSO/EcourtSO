
           DigiSigner - Digital Signatures for your PDFs

                     http://digisigner.com


  What is it?
  -----------

  DigiSigner is a tool for viewing and digitally signing PDF documents
  using X.509 certificates. DigiSigner is implemented in Java and can
  run on MS Windows, Mac OS X, Linux or other platforms with Java support.


  Documentation
  -------------

  The documentation can be found at our web site http://digisigner.com.


  System Requirements
  -------------------

  JRE:
    1.6 or above (MS Windows installer will download and install the latest JRE
    for you automatically, if your current JRE version is too old or you don't have any).
  Memory:
    No minimum requirement.
  Disk:
    No minimum requirement. 
  Operating System:
    Every operating system with Java support. Operating systems like MS Windows,
    Mac OS X or Linux meet this requirement.


  Installing DigiSigner
  ---------------------

  MS Windows:
    Start the installer and follow the instructions.

  MAC OS X:
    Unzip the archive and start the application.
 
  Linux: 
    Unzip the archive and make digisigner.sh script executable using chmod +x digisigner.sh.


  Licensing
  ---------

  Please see the file called LICENSE.TXT


  DigiSigner URLS
  ---------------

  Home Page:          http://digisigner.com/
