_prefix=/usr
_libdir=/usr/lib
_bindir=/usr/bin
_machine_type="MACHINETYPE=i686"
_cflags="CFLAGS=-m32 -march=i686"

if [ `uname -m` == "x86_64" ]; then
	_machine_type="MACHINETYPE=x86_64"
	_cflags="CFLAGS=-m64 -march=x86-64"
	if which rpm > /dev/null 2>&1; then
		_libdir=/usr/lib64
	fi
fi

cd ppd
./autogen.sh "${_machine_type}" "${_cflags}" --prefix="${_prefix}" 

cd ../cngplp
./autogen.sh "${_machine_type}" "${_cflags}" --prefix="${_prefix}" --libdir="${_libdir}"

cd files
./autogen.sh "${_machine_type}" "${_cflags}"
cd ..

cd ../StatusMonitor
./autogen.sh "${_machine_type}" "${_cflags}" --prefix="${_prefix}" --enable-progpath="${_bindir}"

cd ../cpca
./autogen.sh "${_machine_type}" "${_cflags}" --prefix="${_prefix}" --libdir="${_libdir}"  --enable-progpath="${_bindir}"
make
cd ..

make

