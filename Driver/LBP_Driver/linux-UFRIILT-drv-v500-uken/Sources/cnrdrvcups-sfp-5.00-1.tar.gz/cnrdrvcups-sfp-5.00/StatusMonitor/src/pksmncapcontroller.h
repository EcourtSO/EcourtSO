/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#ifndef _PKSMNCAPCONTROLLER
#define _PKSMNCAPCONTROLLER

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>

typedef struct{
	int pid;
	int cmd_fd;
	int res_fd;
}Mngpksmncap;

#define PKSM_ID_CREATECOMMDATA	1
#define PKSM_ID_MAKECOMMDATA	2
#define PKSM_ID_MAKESENDDATA	3
#define PKSM_ID_SENDDATA		4
#define PKSM_ID_READCOMMDATA	5
#define PKSM_ID_DESTROYCOMMDATA	6
#define PKSM_ID_EXIT_PROC		7
#define PKSM_ID_SENDDATA_WITH_PDLTYPE 8

#define COMM_HOST_NO_ERROR		0
#define COMM_HOST_ERROR		-1
#define COMM_HOST_PRINTER_PAUSE	-2
#define COMM_HOST_NETWORK_ERROR	-3
#define COMM_HOST_USB_ERROR		-4
#define COMM_HOST_ERROR_USB_RETRY     -5

enum {
    DATATYPE_UNKNOWN = 0,
    DATATYPE_L,
    DATATYPE_D,
    DATATYPE_S,
    DATATYPE_B,
    DATATYPE_A_L,
    DATATYPE_A_D,
    DATATYPE_A_S,
    DATATYPE_A_B,
    DATATYPE_A_OP,
    DATATYPE_A_CL,
    DATATYPE_A_CNT,
    DATATYPE_D_OP,
    DATATYPE_D_CL,
    DATATYPE_D_CNT
};

Mngpksmncap* pksmncapCreateProcess( const char* const pDriverPath );
int pksmncapWrite( const int fds, const int nCmdID, char* const pData, const int nDataSize );
int pksmncapRead( const int fds, const int nCmdID, int* const pDataSize, char** const pResData );
void pksmncapClose( const Mngpksmncap* const pMngpksm );

#endif
