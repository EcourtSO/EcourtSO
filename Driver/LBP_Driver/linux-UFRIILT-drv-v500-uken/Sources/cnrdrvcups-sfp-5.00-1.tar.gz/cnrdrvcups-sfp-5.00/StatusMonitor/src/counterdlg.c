/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */



#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "uimain.h"
#include "widgets.h"
#include "interface.h"
#include "counterdlg.h"

#include "callbacks.h"
#include "support.h"
#include "id_defines.h"
#include "commandcontroller.h"
#include "value_defines.h"
#include "key_defines.h"

#define COUNTER_CTRL_TYPE_NUM 3
#define COUNTER_CTRL_TBL_NUM 13

CtrlTbl* PPDCtrlTbl[CTRL_LIST_MAXNUM];

static int InitCounterDlgWidgets( UIStatusWnd *wnd );
static void AddPPDCtrlTbl( void );

static CtrlTbl ctrlTbl[COUNTER_CTRL_TBL_NUM] =
{
	{ ID_COUNTER_DIALOG1, LABEL_TYPE_TITLE, NULL, N_("Counter Information"), NULL, 0 },
	{ ID_CTRLCOUNTERINFO, LABEL_TYPE_TEXT, "CounterDlg_CounterInfo_label", N_("Counter"), NULL, 0 },
	{ ID_CTRLCOLORPRINTED, LABEL_TYPE_TEXT, "CounterDlg_ColorPrintedPagesInfo_label", N_("Color Print Pages:"), "hbox69", ID110012 },
	{ ID_CTRLCOLORPRINTEDUNIT, LABEL_TYPE_TEXT, "CounterDlg_ColorPrintedPagesUnit_label", N_("pages"), NULL, 0 },
	{ ID_CTRLMONOPRINTED, LABEL_TYPE_TEXT, "CounterDlg_MonoPrintedPagesInfo_label", N_("B&W Print Pages:"), "hbox70", ID110022 },
	{ ID_CTRLMONOPRINTEDUNIT, LABEL_TYPE_TEXT, "CounterDlg_MonoPrintedPagesUnit_label", N_("pages"), NULL, 0 },
	{ ID_CTRLTOTALPRINTED, LABEL_TYPE_TEXT, "CounterDlg_TotalPrintedPagesInfo_label", N_("Total Printed Pages:"), "hbox68", 0 },
	{ ID_CTRLTOTALPRINTEDUNIT, LABEL_TYPE_TEXT, "CounterDlg_TotalPrintedPagesUnit_label", N_("pages"), NULL, 0 },
	{ ID_CTRLTWOSIDEDPRINTEDSHEETS, LABEL_TYPE_TEXT, "CounterDlg_TwoSidedPrintedSheetsInfo_label", N_("Number of 2-sided Printing Sheets:"), "CounterDlg_TwoSidedPrintedSheets_box", ID110082 },
	{ ID_CTRLTWOSIDEDPRINTEDSHEETSUNIT, LABEL_TYPE_TEXT, "CounterDlg_TwoSidedPrintedSheetsUnit_label", N_("piece"), NULL, 0 },
	{ ID_CTRLTOTALMONOPRINTED, LABEL_TYPE_TEXT, "CounterDlg_TotalMonoPrintedPagesInfo_label", N_("Total Printed Pages:"), "CounterDlg_TotalMonoPrintedPagesInfo_box", ID110022 },
	{ ID_CTRLTOTALMONOPRINTEDUNIT, LABEL_TYPE_TEXT, "CounterDlg_TotalMonoPrintedPagesUnit_label", N_("pages"), NULL, 0 },
	{ -1, -1, NULL, NULL, NULL, -1 }
};

UICounterDlg* CreateCounterDlg(UIDialog* const parent)
{
	UICounterDlg *pDialog;

	pDialog = (UICounterDlg *)CreateDialog(sizeof(UICounterDlg), parent);
	if( pDialog != NULL )
	{
		UI_DIALOG(pDialog)->window = create_Counter_dialog();
	}

	return pDialog;
}

void ShowCounterDlg( UIStatusWnd* const wnd )
{
	int nRet = 0;

	if( wnd == NULL )
	{
		return;
	}
	if( wnd->counter_dlg == NULL )
	{
		wnd->counter_dlg = CreateCounterDlg( UI_DIALOG( wnd ) );
	}

	SigDisable();
	nRet = InitCounterDlgWidgets( wnd );
	SigEnable();

	if( nRet == 0 )
	{
		ShowDialog( (UIDialog *)wnd->counter_dlg, NULL );
	}
	else
	{
		ShowMsgDlg( wnd, ID_COUNTERINFO_ERR_GET );
		if( wnd->counter_dlg != NULL )
		{
			if( wnd->counter_dlg->pDialogDict != NULL )
			{
				DeleteDict( wnd->counter_dlg->pDialogDict );
				wnd->counter_dlg->pDialogDict = NULL;
			}
			mem_free( wnd->counter_dlg );
			wnd->counter_dlg = NULL;
		}
	}
}

static int InitCounterDlgWidgets( UIStatusWnd* const wnd )
{
	GtkWidget *pWindow = NULL;
	GList *pGlist = NULL;
	int nColor = 0, nMono = 0;
	int i = 0;
	int nRet = 0;
	const char* const ctrl_type[COUNTER_CTRL_TYPE_NUM] = { "CNSUICounterDlg", "CNSUICtrlCounter", NULL };
	char cBuf[MAX_BUF_SIZE] = {0};
	gboolean isJP = FALSE;
	int nTwoSidedPrintedSheets = 0;

	if( wnd == NULL )
	{
		return -1;
	}

	if( wnd->counter_dlg == NULL )
	{
		return -1;
	}
	else
	{
		pWindow = wnd->counter_dlg->dialog.window;
	}

	CreatePPDCtrlTbl( wnd, ctrl_type, ctrlTbl, PPDCtrlTbl );

	AddPPDCtrlTbl();

	SetLabel_HideWidget( pWindow, PPDCtrlTbl, ctrlTbl );

	pGlist = CreateGlist_DbId( PPDCtrlTbl );

	if( wnd->counter_dlg->pDialogDict != NULL )
	{
		UI_DEBUG("pDialogDict no mem_free, from Func[%s] Line[%u] \n", __func__, __LINE__);
		DeleteDict( wnd->counter_dlg->pDialogDict );
	}

	wnd->counter_dlg->pDialogDict = CretateDict_GetData( pGlist );
	g_list_free_wrapper( pGlist );
	pGlist = NULL;

	if( wnd->counter_dlg->pDialogDict == NULL )
	{
		return -1;
	}

	nRet = CommunicatePrinterData( wnd, NULL, wnd->counter_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	if( nRet != 0 )
	{
		return -1;
	}

	isJP = isLocaleJapanese( wnd );
	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		switch( PPDCtrlTbl[i]->ctrlid )
		{
		case ID_CTRLCOLORPRINTED:
			GetItemValueType_int( wnd->counter_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, &nColor );
			sprintf( cBuf, "%d", nColor );
			SetTextToLabel( pWindow, "CounterDlg_ColorPrintedPages_label" , cBuf );
			if( !isJP )
			{
				SetTextToLabel( pWindow, "CounterDlg_ColorPrintedPagesUnit_label", " " );
			}
			break;
		case ID_CTRLMONOPRINTED:
			GetItemValueType_int( wnd->counter_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, &nMono );
			sprintf( cBuf, "%d", nMono );
			SetTextToLabel( pWindow, "CounterDlg_MonoPrintedPages_label" , cBuf );
			if( !isJP )
			{
				SetTextToLabel( pWindow, "CounterDlg_MonoPrintedPagesUnit_label", " " );
			}
			break;
		case ID_CTRLTOTALPRINTED:
			sprintf( cBuf, "%d", (nColor + nMono) );
			SetTextToLabel( pWindow, "CounterDlg_TotalPrintedPages_label", cBuf );
			if( !isJP )
			{
				SetTextToLabel( pWindow, "CounterDlg_TotalPrintedPagesUnit_label", " " );
			}
			break;
		case ID_CTRLTOTALMONOPRINTED:
			GetItemValueType_int( wnd->counter_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, &nMono );
			sprintf( cBuf, "%d", nMono );
			SetTextToLabel( pWindow, "CounterDlg_TotalMonoPrintedPages_label", cBuf );
			if( !isJP )
			{
				SetTextToLabel( pWindow, "CounterDlg_TotalMonoPrintedPagesUnit_label", " " );
			}
			break;
		case ID_CTRLTWOSIDEDPRINTEDSHEETS:
			GetItemValueType_int( wnd->counter_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, &nTwoSidedPrintedSheets );
			sprintf( cBuf, "%d", nTwoSidedPrintedSheets );
			SetTextToLabel( pWindow, "CounterDlg_TwoSidedPrintedSheets_label" , cBuf );
			if( !isJP )
			{
				SetTextToLabel( pWindow, "CounterDlg_TwoSidedPrintedSheetsUnit_label", " " );
			}
			break;
		default:
			break;
		}
		memset( cBuf, 0, sizeof(cBuf) );
	}

	return nRet;
}

static void AddPPDCtrlTbl( void )
{
	int i = 0;

	AddCtrlData( ID_CTRLCOUNTERINFO, ctrlTbl, PPDCtrlTbl );

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		switch( PPDCtrlTbl[i]->ctrlid )
		{
			case ID_CTRLTOTALPRINTED:
				AddCtrlData( ID_CTRLTOTALPRINTEDUNIT, ctrlTbl, PPDCtrlTbl );
				break;
			case ID_CTRLCOLORPRINTED:
				AddCtrlData( ID_CTRLCOLORPRINTEDUNIT, ctrlTbl, PPDCtrlTbl );
				break;
			case ID_CTRLMONOPRINTED:
				AddCtrlData( ID_CTRLMONOPRINTEDUNIT, ctrlTbl, PPDCtrlTbl );
				break;
			case ID_CTRLTOTALMONOPRINTED:
				AddCtrlData( ID_CTRLTOTALMONOPRINTEDUNIT, ctrlTbl, PPDCtrlTbl );
				break;
			case ID_CTRLTWOSIDEDPRINTEDSHEETS:
				AddCtrlData( ID_CTRLTWOSIDEDPRINTEDSHEETSUNIT, ctrlTbl, PPDCtrlTbl );
				break;
			default:
				break;
		}
	}
}


void DisposeCounterDlg( UIStatusWnd* const wnd )
{
	UICounterDlg* ui_counter_dlg = NULL;

	if(wnd == NULL)
	{
		return;
	}

	ui_counter_dlg = wnd->counter_dlg;
	if( ui_counter_dlg != NULL )
	{
		if( ui_counter_dlg->pDialogDict != NULL )
		{
			DeleteDict( ui_counter_dlg->pDialogDict );
			ui_counter_dlg->pDialogDict = NULL;
		}
		DisposeDialog( (UIDialog *)ui_counter_dlg );
		wnd->counter_dlg = NULL;
	}
}

