/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2015 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "uimain.h"
#include "widgets.h"
#include "interface.h"
#include "warningdetailsdlg.h"

#include "callbacks.h"
#include "support.h"
#include "id_defines.h"
#include "commandcontroller.h"
#include "value_defines.h"

static int InitWarningDetailsDlgWidgets( UIStatusWnd* const wnd );
static unsigned int SetItemValue_WarningDetailsDlgOK( const UIStatusWnd* const wnd );
static void AddPPDCtrlTbl( UIStatusWnd* const wnd );
int dlgType();

CtrlTbl* PPDCtrlTbl[CTRL_LIST_MAXNUM];

static CtrlTbl ctrlTbl[] =
{
	{ ID_WARNINGDETAILS_DIALOG1, LABEL_TYPE_TITLE, NULL, N_("Warning Display Details"), NULL, 0 },
	{ ID_CTRLCRGLOWTHRESHOLDCOMMENT, LABEL_TYPE_TEXT, "WarningDetailsDlg_CRGLowThresholdComment_label", N_("Set the Display Timing for the Cartridge Replacement Notice."), "WarningDetailsDlg_CRGLowThresholdComment_box", 0 },
	{ ID_CTRLCRGLOWTHRESHOLDVALUE, LABEL_TYPE_TEXT, "WarningDetailsDlg_CRGLowThresholdValue_label", N_("Notify When Amount Remaining Reaches:"), "WarningDetailsDlg_CRGLowThresholdValue_box", ID1422 },
	{ ID_CTRLCRGLOWTHRESHOLDUNIT, LABEL_TYPE_TEXT, "WarningDetailsDlg_CRGLowThresholdUnit_label", N_("% (1 to 99)"), "WarningDetailsDlg_CRGLowThresholdUnit_label", 0 },
	{ ID_CTRLWARNINGDETAILSDLG_TYPE1, LABEL_TYPE_BOX, NULL, NULL, "WarningDetailsDlg_Type1_box", 0 },
	{ ID_CTRLWARNINGDETAILSDLG_TYPE2, LABEL_TYPE_BOX, NULL, NULL, "WarningDetailsDlg_Type2_box", 0 },
	{ ID_CTRLWARNINGDETAILSDLG_TYPE3, LABEL_TYPE_BOX, NULL, NULL, "WarningDetailsDlg_Type3_box", 0 },
	{ ID_CTRLTONERSPIN, LABEL_TYPE_TEXT, "WarningDetailsDlg_TonerLowThresholdValue_label", N_("Toner:"), "WarningDetailsDlg_TonerLowThresholdValue_box", ID1422 },
	{ ID_CTRLDRUMRSPIN, LABEL_TYPE_TEXT, "WarningDetailsDlg_DrumLowThresholdValue_label", N_("Drum:"), "WarningDetailsDlg_DrumLowThresholdValue_box", ID122342 },
	{ ID_CTRLDRUMRSPIN2, LABEL_TYPE_TEXT, "WarningDetailsDlg_DrumLowThresholdValue_label2", N_("Drum:"), "WarningDetailsDlg_DrumLowThresholdValue_box2", ID122342 },

	{ -1, -1, NULL, NULL, NULL, -1 }
};

static const int warnDetailUIList[] =
{
		ID_CTRLWARNINGDETAILSDLG_TYPE1,
		ID_CTRLWARNINGDETAILSDLG_TYPE2,
		ID_CTRLWARNINGDETAILSDLG_TYPE3
};


UIWarningDetailsDlg* CreateWarningDetailsDlg(UIDialog* const parent)
{
	UIWarningDetailsDlg *pDialog = NULL;

	pDialog = (UIWarningDetailsDlg *)CreateDialog(sizeof(UIWarningDetailsDlg), parent);
	if( pDialog != NULL )
	{
		UI_DIALOG(pDialog)->window = create_WarningDetails_dialog();
	}
	return pDialog;
}

void ShowWarningDetailsDlg( UIStatusWnd* const wnd )
{
	int nRet = 0;

	if( wnd == NULL )
	{
		return;
	}
	if( wnd->warningdetails_dlg == NULL )
	{
		wnd->warningdetails_dlg = CreateWarningDetailsDlg( UI_DIALOG( wnd ) );
	}

	SigDisable();
	nRet = InitWarningDetailsDlgWidgets( wnd );
	SigEnable();

	if( nRet == 0 )
	{
		ShowDialog( (UIDialog *)wnd->warningdetails_dlg, NULL );
	}
	else
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_GET );
		if( wnd->warningdetails_dlg != NULL )
		{
			if( wnd->warningdetails_dlg->pDialogDict != NULL )
			{
				DeleteDict( wnd->warningdetails_dlg->pDialogDict );
				wnd->warningdetails_dlg->pDialogDict = NULL;
			}
			mem_free( wnd->warningdetails_dlg );
			wnd->warningdetails_dlg = NULL;
		}
	}
}

static unsigned int SetItemValue_WarningDetailsDlgOK( const UIStatusWnd* const wnd )
{
	int nValue = 0;
	unsigned int unRet = 0;
	GtkWidget *pWindow = NULL;

	if( wnd == NULL )
	{
		UI_DEBUG("SetItemValue_WarningDetailsDlgOK PPDCtrlTbl[%p] pWindow[%p]\n", PPDCtrlTbl, pWindow);
		return DICT_SET_RETURN_ERROR;
	}
	pWindow = wnd->warningdetails_dlg->dialog.window;

	int dlgID = dlgType();
	switch( dlgID )
	{
	case ID_CTRLWARNINGDETAILSDLG_TYPE1:
		nValue = GetSpinButtonValue( pWindow, "WarningDetailsDlg_CRGLowThresholdValue_spinbutton", 0 );
		unRet |= SetItemValuetype_int( wnd->warningdetails_dlg->pDialogDict, ID1422, nValue );
		UI_DEBUG("SetItemValue_WarningDetailsDlgOK unRet[%d]\n", unRet);
		break;
	case ID_CTRLWARNINGDETAILSDLG_TYPE2:
		nValue = GetSpinButtonValue( pWindow, "WarningDetailsDlg_TonerLowThresholdValue_spin", 0 );
		unRet |= SetItemValuetype_int( wnd->warningdetails_dlg->pDialogDict, ID1422, nValue );
		nValue = GetSpinButtonValue( pWindow, "WarningDetailsDlg_DrumLowThresholdValue_spin", 0 );
		unRet |= SetItemValuetype_int( wnd->warningdetails_dlg->pDialogDict, ID122342, nValue );
		UI_DEBUG("SetItemValue_WarningDetailsDlgOK unRet[%d]\n", unRet);
		break;
	case ID_CTRLWARNINGDETAILSDLG_TYPE3:
		nValue = GetSpinButtonValue( pWindow, "WarningDetailsDlg_DrumLowThresholdValue_spin2", 0 );
		unRet |= SetItemValuetype_int( wnd->warningdetails_dlg->pDialogDict, ID122342, nValue );
		UI_DEBUG("SetItemValue_WarningDetailsDlgOK unRet[%d]\n", unRet);
		break;
	default:
		break;
	}
	return unRet;
}

void WarningDetailsDlgOK( UIStatusWnd* const wnd )
{
	int nRet = 0;
	unsigned int unRet = 0;

	if( wnd == NULL )
	{
		return;
	}
	else
	{
		nRet = CreateDict_SetData( wnd->warningdetails_dlg->pDialogDict );
	}

	if( nRet == 0 )
	{
		unRet = SetItemValue_WarningDetailsDlgOK( wnd );
		if( (unRet & DICT_SET_RETURN_ERROR) == DICT_SET_RETURN_ERROR )
		{
			nRet = -1;
		}
	}

	if( ( nRet == 0 ) && ( unRet == DICT_SET_RETURN_CHANGE ) )
	{
		nRet = CommunicatePrinterData( wnd, (UIDialog *)wnd->warningdetails_dlg, wnd->warningdetails_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	}

	HideDialog( (UIDialog *)wnd->warningdetails_dlg );

	if( nRet != 0 )
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_SET );
	}

	return;
}

int dlgType()
{
	int returnCtrlID = 0;
	int count = 0;
	for(count = 0; count < sizeof(warnDetailUIList) / sizeof(warnDetailUIList[0]); count++)
	{
		if ( CheckControlEnabled(PPDCtrlTbl, warnDetailUIList[count]) )
		{
			returnCtrlID = warnDetailUIList[count];
		}
	}
	return returnCtrlID;
}

static void AddPPDCtrlTbl( UIStatusWnd* const wnd )
{
	gboolean isExist = FALSE;
	int count = 0;
	for(; count < sizeof(warnDetailUIList) / sizeof(warnDetailUIList[0]); count++)
	{
		if ( CheckControlEnabled(PPDCtrlTbl, warnDetailUIList[count]) )
		{
			isExist = TRUE;
			break;
		}
	}

	if (isExist == FALSE)
	{
		AddCtrlData(ID_CTRLWARNINGDETAILSDLG_TYPE1, ctrlTbl, PPDCtrlTbl);
	}
}

static int InitWarningDetailsDlgWidgets( UIStatusWnd* const wnd )
{
	GtkWidget *pWindow = NULL;
	GList *pGlist = NULL;
	int nValue = 1;
	int nRet = 0;

	if( wnd == NULL )
	{
		return -1;
	}

	if( wnd->warningdetails_dlg == NULL )
	{
		return -1;
	}
	else
	{
		pWindow = wnd->warningdetails_dlg->dialog.window;
	}

	GString *gsPpdKey = NULL;
	gsPpdKey = g_string_new_wrapper("CNSUICtrlCRGLowThreshold", __FILE__, __LINE__);

	if (isCrgTypeDevice(wnd))
	{
		char* pCartridgeType = NULL;
		getEquipmentCrgTypeFromCNSUICrgTypeList(wnd, &pCartridgeType);
		if (pCartridgeType == NULL)
		{
			return -1;
		}
		mem_free(pCartridgeType);

		GString *gsExtraStr = NULL;
		gsExtraStr = g_string_new_wrapper(NULL, __FILE__, __LINE__);
		createCrgTypeXStr(wnd, "CtrlCRGLowThreshold", NULL, gsExtraStr);

		g_string_append(gsPpdKey, gsExtraStr->str);
		g_string_free_wrapper(gsExtraStr, TRUE);
	}

	const char* const ctrl_type[] = { "CNSUIWarningDetailsDlg", gsPpdKey->str, NULL };

	CreatePPDCtrlTbl( wnd, ctrl_type, ctrlTbl, PPDCtrlTbl );

	g_string_free_wrapper(gsPpdKey, TRUE);
	AddPPDCtrlTbl(wnd);

	SetLabel_HideWidget( pWindow, PPDCtrlTbl, ctrlTbl );

	pGlist = CreateGlist_DbId( PPDCtrlTbl );

	if( wnd->warningdetails_dlg->pDialogDict != NULL )
	{
		UI_DEBUG("pDialogDict no mem_free, from Func[%s] Line[%u] \n", __func__, __LINE__);
		DeleteDict( wnd->warningdetails_dlg->pDialogDict );
	}
	wnd->warningdetails_dlg->pDialogDict = CretateDict_GetData( pGlist );
	g_list_free_wrapper( pGlist );
	pGlist = NULL;

	if( wnd->warningdetails_dlg->pDialogDict == NULL )
	{
		return -1;
	}

	nRet = CommunicatePrinterData( wnd, NULL, wnd->warningdetails_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	if( nRet != 0 )
	{
		return -1;
	}

	int dlgID = dlgType();
	switch( dlgID )
	{
	case ID_CTRLWARNINGDETAILSDLG_TYPE1:
		GetItemValueType_int( wnd->warningdetails_dlg->pDialogDict, ID1422, &nValue );
		SetSpinButtonFloat( pWindow, "WarningDetailsDlg_CRGLowThresholdValue_spinbutton", (float)nValue );
		break;
	case ID_CTRLWARNINGDETAILSDLG_TYPE2:
		GetItemValueType_int( wnd->warningdetails_dlg->pDialogDict, ID1422, &nValue );
		SetSpinButtonFloat( pWindow, "WarningDetailsDlg_TonerLowThresholdValue_spin", (float)nValue );
		GetItemValueType_int( wnd->warningdetails_dlg->pDialogDict, ID122342, &nValue );
		SetSpinButtonFloat( pWindow, "WarningDetailsDlg_DrumLowThresholdValue_spin", (float)nValue );
		break;
	case ID_CTRLWARNINGDETAILSDLG_TYPE3:
		GetItemValueType_int( wnd->warningdetails_dlg->pDialogDict, ID122342, &nValue );
		SetSpinButtonFloat( pWindow, "WarningDetailsDlg_DrumLowThresholdValue_spin2", (float)nValue );
		break;
	default:
		break;
	}

	return nRet;
}

void DisposeWarningDetailsDlg( UIStatusWnd* const wnd )
{
	UIWarningDetailsDlg* ui_dialog = NULL;

	if(wnd == NULL)
	{
		return;
	}

	ui_dialog = wnd->warningdetails_dlg;
	if( ui_dialog != NULL )
	{
		if( ui_dialog->pDialogDict != NULL )
		{
			DeleteDict( ui_dialog->pDialogDict );
			ui_dialog->pDialogDict = NULL;
		}
		DisposeDialog( (UIDialog *)ui_dialog );
		wnd->warningdetails_dlg = NULL;
	}
}

