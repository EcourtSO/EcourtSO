﻿=================================================================================
Canon MF/LBP Network Setup Tool Version 2.31

MERCI DE LIRE ATTENTIVEMENT CE DOCUMENT
=================================================================================

PRÉCAUTIONS

Veuillez noter les restrictions suivantes en ce qui concerne l'utilisation de ce logiciel.

1. Le logiciel peut détecter jusqu'à 10 points d'accès sans fil par recherche de points d'accès sans fil. 

2. Le logiciel ne peut pas détecter les points d'accès sans fil par recherche de points d'accès sans fil lorsque ceux-ci utilisent une fonction furtive. 

3. Lorsque le micrologiciel de l'imprimante est mis à jour,ou immédiatement après la mise sous ou hors tension de l'imprimante, ou lors d'une impression, il est impossible d'effectuer des réglages de configuration à l'aide ce logiciel. 

4. Selon l'environnement d'exploitation utilisé, il peut arriver que les "Conseils utiles" ne puissent pas être directement affichés depuis ce logiciel.
Si tel est le cas, suivez les instructions du message à l'écran pour afficher les "Conseils utiles" à partir du navigateur Web que vous utilisez.

=================================================================================
                                                        Copyright CANON INC. 2014

