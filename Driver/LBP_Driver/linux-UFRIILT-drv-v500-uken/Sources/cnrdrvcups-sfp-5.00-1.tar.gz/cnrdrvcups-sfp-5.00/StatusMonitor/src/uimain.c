/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */



#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "support.h"
#include "uimain.h"
#include "widgets.h"
#include "interface.h"
#include "key_defines.h"
#include "commandcontroller.h"
#include <cups/cups.h>

#define	MAX_WORD_SIZE	512

#define 	LOCALE_STRING_EN	"en_GB.UTF-8"
#define	STRING_CODE_UTF8	"UTF-8"

#define	LOCALE_JA		"ja"
#define	LOCALE_EN		"en"
#define	LOCALE_EN_US		"en_US"
#define	LOCALE_FR		"fr"
#define	LOCALE_IT		"it"
#define	LOCALE_DE		"de"
#define	LOCALE_ES		"es"

#define	CCPD_SKT_PORT	59787
#define SUPPORT_PDL_HB "HB"
#define SUPPORT_PDL_HCB "HCB"

static int cngplpModCreate( char* const printer_name, UIStatusWnd* const wnd );
static int ConvertPPDCtrlId(const char* const pValue );
static gboolean IsCtrlIdForPPD( const int nCtrlId, const int* const pCtrlList );
static gboolean IsCtrlIdForPPDCtrlTbl( const int ctrlID, CtrlTbl* const * const PPDCtrlTbl );
static void SetLocaleString(UIStatusWnd* const wnd);

static void SetLocaleString(UIStatusWnd* const wnd)
{
	char *lang = NULL;
	char* pWork = NULL;
	const struct
	{
		char* pSystemLang;
		char* pSetLang;
	} localeInfo[] = {
		{ LOCALE_JA,	LOCALE_JA		},
		{ LOCALE_EN,	LOCALE_EN_US	},
		{ LOCALE_FR,	LOCALE_FR		},
		{ LOCALE_IT,	LOCALE_IT		},
		{ LOCALE_DE,	LOCALE_DE		},
		{ LOCALE_ES,	LOCALE_ES		}
	};
	int nLoop = 0;

	if( wnd == NULL )
	{
		return;
	}

	lang = getenv("LC_CTYPE");
	if( lang == NULL ){
		lang = getenv("LANG");
	}
	UI_DEBUG("locale %s\n", lang);

	if(lang == NULL){
		lang = LOCALE_STRING_EN;
	}

	pWork = NULL;
	for( nLoop = 0; nLoop < (sizeof(localeInfo) / sizeof(localeInfo[0])); nLoop++ )
	{
		if( 0 == strncmp( lang, localeInfo[nLoop].pSystemLang, strlen(localeInfo[nLoop].pSystemLang) ) )
		{
			pWork = localeInfo[nLoop].pSetLang;
			break;
		}
	}

	if( NULL != pWork )
	{
		wnd->locale = mem_strudup( pWork, __FILE__, __LINE__ );
	}
	else
	{
		wnd->locale = mem_strudup( LOCALE_EN_US, __FILE__, __LINE__ );
	}


	wnd->encoding = mem_strudup(STRING_CODE_UTF8, __FILE__, __LINE__);
	UI_DEBUG("locale <%s> <%s>\n", lang, wnd->locale);
}

static int cngplpModCreate( char* const printer_name, UIStatusWnd* const wnd )
{
	int nComp = 0;

	if( ( wnd == NULL ) || ( printer_name == NULL ) )
	{
		return -1;
	}

	wnd->pModData = cngplpNew( NULL );
	if( wnd->pModData == NULL )
	{
		return -1;
	}

	wnd->pPrinterName = printer_name;
	char *const pTmp = cngplpSetData(wnd->pModData, ID_PRINTERNAME, wnd->pPrinterName);
	if( pTmp != NULL )
	{
		mem_free( pTmp );
	}

	nComp = strcmp( printer_name, wnd->pModData->curr_printer );
	if( nComp != 0 )
	{
		return -1;
	}

	char *const pData = cngplpGetData(wnd->pModData,ID_CNPDLTYPE);
	if( pData == NULL )
	{
		return -1;
	}
	else
	{
		nComp = strcmp( pData, SUPPORT_PDL_HB);
		if(nComp != 0)
		{
			nComp = strcmp( pData, SUPPORT_PDL_HCB);
		}
		if(nComp == 0){
			wnd->pPDLType = mem_strudup(pData, __FILE__, __LINE__);
		}
		mem_free( pData );
	}
	if( nComp != 0 )
	{
		return -1;
	}
	return 0;
}

char* cngplpGetValue_Wrapper(cngplpData * const data, const char * const key)
{
	char* pValue = NULL;
	char* pDupKey = NULL;

	if( (data == NULL) || (key == NULL) )
	{
		return NULL;
	}

	pDupKey = mem_strudup(key, __func__, __LINE__);

	if(pDupKey != NULL)
	{
		pValue = cngplpGetValue( data, pDupKey );
		mem_free( pDupKey );
	}

	return pValue;
}

int buftool_write_string_Wrapper(BufTool * const buf_tool, const char * const data, const int bytes)
{
	char* pDupStr = NULL;
	int nRet = -1;

	if( (buf_tool == NULL) || (data == NULL) )
	{
		return nRet;
	}

	pDupStr = mem_strudup( data, __func__, __LINE__ );

	if(pDupStr != NULL)
	{
		nRet = buftool_write(buf_tool, pDupStr, bytes);
		mem_free( pDupStr );
	}

	return nRet;
}

UIStatusWnd *CreateStatusWnd(char *printer_name, int mode)
{
	UIStatusWnd *wnd = NULL;
	int nRet = 0;

	wnd = (UIStatusWnd *)CreateDialog(sizeof(UIStatusWnd), NULL);

	memset(wnd, 0, sizeof(UIStatusWnd));
	UI_DIALOG(wnd)->window = create_StatusMonitorWnd();

	nRet = cngplpModCreate( printer_name, wnd );

	if( nRet == 0 )
	{
		SetLocaleString(wnd);
		nRet = CreateStatusWidgets( wnd );
	}

	wnd->mode = mode;
	if(wnd->mode == 0)
	{
		wnd->isHideNowWnd = TRUE;
	}

	if( nRet == 0 )
	{
		SetDialogTitle( UI_DIALOG(wnd)->window, printer_name );
	}

	if( nRet != 0 )
	{
		if( wnd != NULL )
		{
			DisposeStatusWnd( wnd );
			wnd = NULL;
		}
		fprintf(stderr, "*** ncapstatusui Error: No Specified Printer ***\n");
	}

	return wnd;
}

#define PMEMORY_MAX 10000

void* g_pGListarray[ PMEMORY_MAX ] = { NULL };
void* g_pGStringarray[ PMEMORY_MAX ] = { NULL };
void* g_pmemarray[ PMEMORY_MAX ] = { NULL };

GList* g_list_alloc_wrapper( const char* pFunc, unsigned int nLine )
{
	GList* plocalList = NULL;
	int i = 0;

	plocalList = g_list_alloc();

	for ( i = 0; i < PMEMORY_MAX; i ++ )
	{
		if ( g_pGListarray[i] == NULL ) {
			g_pGListarray[i] = plocalList;
			UI_DEBUG("%s memory alloc list pos[%d] pointer[%p], from Func[%s] Line[%u]\n", __func__, i, plocalList, pFunc, nLine);
			break;
		}
	}

	return plocalList;
}

GList* g_list_append_wrapper( GList* const pGList, void* const pValue, const char* pFunc, unsigned int nLine )
{
	int i = 0;
	GList* plocalList = pGList;
	gboolean bAdd = FALSE;

	if( plocalList == NULL )
	{
		bAdd = TRUE;
	}

	plocalList = g_list_append( plocalList, pValue );

	if( bAdd != FALSE )
	{
		for ( i = 0; i < PMEMORY_MAX; i ++ )
		{
			if ( g_pGListarray[i] == NULL ) {
				g_pGListarray[i] = plocalList;
				UI_DEBUG("%s memory alloc list pos[%d] pointer[%p], from Func[%s] Line[%u]\n", __func__, i, plocalList, pFunc, nLine);
				break;
			}
		}
	}
	return plocalList;
}

GList* g_list_concat_wrapper( GList* pGList1, GList* const pGList2, const char* pFunc, unsigned int nLine )
{
	int i = 0;

	if( pGList1 != NULL )
	{
		for ( i = 0; i < PMEMORY_MAX; i ++ )
		{
			if ( g_pGListarray[i] == pGList2 )
			{
				g_pGListarray[i] = NULL;
				UI_DEBUG("%s concat list pos[%d] pointer[%p]\n", __func__, i, pGList2);
				break;
			}
		}
	}
	else
	{
		UI_DEBUG("%s concat list List1 == NULL\n", __func__);
	}

	pGList1 = g_list_concat(pGList1, pGList2);
	if( pGList1 == NULL )
	{
		UI_DEBUG("%s concat list List1[%p]\n", __func__, pGList1);
	}
	return pGList1;
}

GList* g_list_delete_link_wrapper( GList* pBaseGList, GList* const pDeleteGList, const char* pFunc, unsigned int nLine )
{
	int i = 0;

	for ( i = 0; i < PMEMORY_MAX; i ++ )
	{
		if ( g_pGListarray[i] == pDeleteGList )
		{
			g_pGListarray[i] = NULL;
			UI_DEBUG("%s delete_link list pos[%d] pointer[%p]\n", __func__, i, pDeleteGList);
			break;
		}
	}

	pBaseGList = g_list_delete_link( pBaseGList, pDeleteGList );
	if(pBaseGList != NULL)
	{
		for ( i = 0; i < PMEMORY_MAX; i ++ )
		{
			if ( g_pGListarray[i] == pBaseGList )
			{
				UI_DEBUG("%s Already list pos[%d] pointer[%p]\n", __func__, i, pBaseGList);
				break;
			}
		}

		if( i >= PMEMORY_MAX )
		{
			for ( i = 0; i < PMEMORY_MAX; i ++ )
			{
				if ( g_pGListarray[i] == NULL ) {
					g_pGListarray[i] = pBaseGList;
					UI_DEBUG("%s delete_link new memory pointer list pos[%d] pointer[%p], from Func[%s] Line[%u]\n", __func__, i, pBaseGList, pFunc, nLine);
					break;
				}
			}
		}
	}
	return pBaseGList;
}

GList* g_list_copy_wrapper( GList* const pGList, const char* pFunc, unsigned int nLine )
{
	GList* plocalList = NULL;
	int i = 0;

	plocalList = g_list_copy( pGList );
	for ( i = 0; i < PMEMORY_MAX; i ++ )
	{
		if ( g_pGListarray[i] == NULL ) {
			g_pGListarray[i] = plocalList;
			UI_DEBUG("%s memory alloc list pos[%d] pointer[%p], from Func[%s] Line[%u]\n", __func__, i, plocalList, pFunc, nLine);
			break;
		}
	}
	return plocalList;
}

void g_list_free_wrapper( GList* const pGList )
{
	int i = 0;

	for ( i = 0; i < PMEMORY_MAX; i ++ )
	{
		if ( g_pGListarray[i] == pGList )
		{
			g_pGListarray[i] = NULL;
			UI_DEBUG("g_list_free_wrapper free list pos[%d] pointer[%p]\n", i, pGList);
			break;
		}
	}
	g_list_free(pGList);
}

void g_list_quit_alloc()
{
	int i = 0;
	for( i = 0; i < PMEMORY_MAX; i++ )
	{
		if( g_pGListarray[i] != NULL )
		{
			UI_DEBUG("check_g_list_quit_alloc memory list pos[%d] do not free[%p]\n", i, g_pGListarray[i]);
			g_list_free(g_pGListarray[i]);
			g_pGListarray[i] = NULL;
		}
	}
}

GString* g_string_new_wrapper( const char* const pStr, const char* pFunc, unsigned int nLine )
{
	int i = 0;

	GString* const glocalString = g_string_new(pStr);

	for ( i = 0; i < PMEMORY_MAX; i ++ )
	{
		if ( g_pGStringarray[i] == NULL ) {
			g_pGStringarray[i] = glocalString;
			UI_DEBUG("g_string_new_wrapper memory alloc string pos[%d] pointer[%p], from Func[%s] Line[%u]\n", i, glocalString, pFunc, nLine);
			break;
		}
	}
	return glocalString;
}

void g_string_free_wrapper( GString* const pGString, const gboolean bSegmentFree )
{
	int i = 0;

	for ( i = 0; i < PMEMORY_MAX; i ++ )
	{
		if ( g_pGStringarray[i] == pGString )
		{
			g_pGStringarray[i] = NULL;
			UI_DEBUG("g_string_free_wrapper string pos[%d] free pointer[%p]\n", i, pGString);
			break;
		}
	}
	g_string_free( pGString, bSegmentFree );
}

void g_string_quit_alloc()
{
	int i = 0;
	for( i = 0; i < PMEMORY_MAX; i++ )
	{
		if( g_pGStringarray[i] != NULL )
		{
			UI_DEBUG("check_g_string_quit_alloc memory string pos[%d] do not free[%p]\n", i, g_pGStringarray[i]);
			g_string_free( g_pGStringarray[i], TRUE );
			g_pGStringarray[i] = NULL;
		}
	}
}

void* mem_alloc(const size_t size, const char* pFunc, unsigned int nLine)
{
	void* pointer = NULL;
	int i = 0;

	pointer = g_malloc0(size);
	for ( i = 0; i < PMEMORY_MAX; i ++ )
	{
		if ( g_pmemarray[i] == NULL ) {
			g_pmemarray[i] = pointer;
			UI_DEBUG("mem_alloc memory alloc memory pos[%d] pointer[%p], from Func[%s] Line[%u]\n", i, pointer, pFunc, nLine);
			break;
		}
	}
	return pointer;
}

char* mem_strudup( const char* const pointer, const char* pFunc, unsigned int nLine )
{
	char* retStr = NULL;
	int i = 0;

	retStr = g_strdup(pointer);
	for ( i = 0; i < PMEMORY_MAX; i ++ )
	{
		if ( g_pmemarray[i] == NULL ) {
			g_pmemarray[i] = retStr;
			UI_DEBUG("mem_strudup memory alloc strudup memory pos[%d] pointer[%p], from Func[%s] Line[%u]\n", i, retStr, pFunc, nLine);
			break;
		}
	}
	return retStr;
}

void mem_free(void* const pointer)
{
	int i = 0;
	for ( i = 0; i < PMEMORY_MAX; i ++ )
	{
		if ( g_pmemarray[i] == pointer )
		{
			g_pmemarray[i] = NULL;
			UI_DEBUG("mem_free free memory pos[%d] pointer[%p]\n", i, pointer);
			break;
		}
	}
	g_free(pointer);
}

void mem_free_list(char** const pointer)
{
	int i;
	if( ( pointer != NULL ) && ( *pointer != NULL ) )
	{
		for( i=0; pointer[i] != NULL; i++ )
		{
			mem_free( pointer[i] );
		}
		mem_free( pointer );
	}
}

void mem_quit_alloc()
{
	int i = 0;
	for( i = 0; i < PMEMORY_MAX; i++ )
	{
		if( g_pmemarray[i] != NULL )
		{
			UI_DEBUG("check_mem_alloc memory memory pos[%d] do not free[%p]\n", i, g_pmemarray[i]);
			g_free(g_pmemarray[i]);
			g_pmemarray[i] = NULL;
		}
	}
}

void InitializeCriticalSection( CRITICAL_SECTION* const section )
{
    pthread_mutexattr_t mutexattr;
    pthread_mutexattr_init(&mutexattr);
    pthread_mutexattr_settype(&mutexattr, PTHREAD_MUTEX_ERRORCHECK_NP);
    pthread_mutex_init(section, &mutexattr);
    pthread_mutexattr_destroy(&mutexattr);
}

int EnterCriticalSection( CRITICAL_SECTION* const section )
{
	int nRet = 0;

    nRet =  pthread_mutex_lock(section);

    if(nRet != 0)
    {
    	UI_DEBUG("EnterCriticalSection failed  nRet[%d]\n", nRet);
    }
    return nRet;
}

int LeaveCriticalSection( CRITICAL_SECTION* const section )
{
	int nRet = 0;

    nRet = pthread_mutex_unlock(section);

    if(nRet != 0)
    {
    	UI_DEBUG("LeaveCriticalSection failed  nRet[%d]\n", nRet);
    }
    return nRet;
}

int DeleteCriticalSection( CRITICAL_SECTION* const section )
{
    return pthread_mutex_destroy( section );
}

SMXmlContext *xmlContextCreate( const char* const pXmlPath )
{
	SMXmlContext *pXmlContext = NULL;

	if( pXmlPath == NULL )
	{
		return NULL;
	}

	pXmlContext = mem_alloc(sizeof(SMXmlContext), __FILE__, __LINE__);
	if( pXmlContext != NULL )
	{
		pXmlContext->pDocPtr = xmlParseFile( pXmlPath );
		if( pXmlContext->pDocPtr != NULL )
		{
			pXmlContext->pRootNodePtr = xmlDocGetRootElement( pXmlContext->pDocPtr );
		}

		if( (pXmlContext->pDocPtr == NULL) || (pXmlContext->pRootNodePtr == NULL) )
		{
			UI_DEBUG("%s Make SMXmlContext Error, from Line[%u] \n", __func__, __LINE__);
			xmlContextDestory( &pXmlContext );
		}
	}

	return pXmlContext;
}

char* xmlGetString( const SMXmlContext* const pXmlContext, const char* const pKeyName )
{
	xmlNodePtr curNode = NULL;
	char *pValStr = NULL;

	if( (pXmlContext == NULL) || (pXmlContext->pDocPtr == NULL) || (pXmlContext->pRootNodePtr == NULL) || (pKeyName == NULL) )
	{
		return NULL;
	}

	curNode = pXmlContext->pRootNodePtr->children;
	while( curNode != NULL )
	{
		if( xmlStrcmp( curNode->name, (const xmlChar*)pKeyName) == 0 )
		{
			pValStr = (char *)xmlNodeListGetString( pXmlContext->pDocPtr, curNode->children, XMLGETSTRINGINLINE );
			break;
		}
		curNode = curNode->next;
	}

	return pValStr;
}

void xmlContextDestory( SMXmlContext** const ppXmlContext )
{
	SMXmlContext *pXmlContext = NULL;

	if( (ppXmlContext == NULL) || (*ppXmlContext == NULL) )
	{
		return;
	}

	pXmlContext = (SMXmlContext*)*ppXmlContext;
	if( pXmlContext->pDocPtr != NULL )
	{
		xmlFreeDoc( pXmlContext->pDocPtr );
		pXmlContext->pDocPtr = NULL;
	}
	xmlCleanupParser();

	mem_free( *ppXmlContext );
	*ppXmlContext = NULL;
}

void DisposeStatusWnd(UIStatusWnd* const wnd)
{
	if( g_status_window == NULL )
	{
		g_status_window = wnd;
	}
	if( g_status_window == NULL )
	{
		return;
	}
	if( g_status_window->pModData != NULL )
	{
		cngplpDestroy( g_status_window->pModData );
		g_status_window->pModData = NULL;
	}

	ClearAreaInfo(wnd);

	mem_free(g_status_window->locale);
	mem_free(g_status_window->encoding);
	mem_free(g_status_window->pDriverPath);
	mem_free(g_status_window->pPDLType);
	if( g_status_window->pMngpksmncap != NULL )
	{
		pksmncapClose( g_status_window->pMngpksmncap );
	}
	mem_free(g_status_window->pMngpksmncap);
	DeleteDict(g_status_window->pStatusDict);
}


static int ConvertPPDCtrlId(const char* const pValue )
{
	int nRet = 0;
	int i = 0;

	struct _ID_COVERT_LIST
	{
		char *ppdValue;
		int  ctrl_id;
	}
	const id_convert_list[ID_CONVERT_LIST_NUM]=
	{
		{ "Zero_Based", ID_ZERO_BASED },
		{ "Dummy1", ID_USBWAIT_MSGDLG1 },
		{ "Dummy2", ID_CTRLTONERCARTRIDGEINFO },
		{ "Dummy3", ID_CTRLCOUNTERINFO },
		{ "Dummy4", ID_CTRLTOTALPRINTEDUNIT },
		{ "Dummy5", ID_CTRLCOLORPRINTEDUNIT },
		{ "Dummy6", ID_CTRLMONOPRINTEDUNIT },
		{ "Dummy7", ID_CTRLTWOSIDEDPRINTEDSHEETSUNIT },
		{ "Dummy8", ID_CTRLTOTALMONOPRINTEDUNIT },
		{ "Calibration_msgdlg1", ID_CALIBRATION_MSGDLG1 },
		{ "ColorMismatchCorrection_msgdlg1", ID_COLORMISMATCHCORRECTION_MSGDLG1 },
        { "Cleaning_msgdlg", ID_CLEANING_MSGDLG },
		{ "Cleaning_msgdlgmptray", ID_CLEANING_MSGDLGMPTRAY },
		{ "Cleaning_msgdlg1", ID_CLEANING_MSGDLG1 },
		{ "Cleaning_msgdlg2", ID_CLEANING_MSGDLG2 },
		{ "UserDataList_msgdlg", ID_USERDATALIST_MSGDLG1 },
		{ "PCLFontList_msgdlg", ID_PCLFONTLIST_MSGDLG1 },
		{ "UpdatingFirmwareMode_msgdlg", ID_UPDATINGFIRMWAREMODE_MSGDLG1 },
		{ "SleepSetting_dialog1", ID_SLEEPSETTING_DIALOG1 },
		{ "JobCancelSetting_dialog1", ID_JOBCANCELSETTING_DIALOG1 },
		{ "Override_dialog1", ID_OVERRIDE_DIALOG1 },
		{ "DisablwWiFi_dialog1", ID_DISABLEWIFI_DIALOG1 },
		{ "AssistSetting_dialog1", ID_ASSISTSETTING_DIALOG1 },
		{ "Consumables_dialog1", ID_CONSUMABLES_DIALOG1 },
		{ "Counter_dialog1", ID_COUNTER_DIALOG1 },
		{ "WLanStatus_dialog1", ID_WLANSTATUS_DIALOG1 },
		{ "AutoShutdown_dialog1", ID_AUTOSHUTDOWN_DIALOG1 },
		{ "ImgAdjust_dialog1", ID_IMGADJUST_DIALOG1 },
		{ "PfeedUnit_dialog1", ID_PFEEDUNIT_DIALOG1},
		{ "CtrlJobCancelEnable", ID_CTRLJOBCANCELENABLE },
		{ "CtrlSleepEnable", ID_CTRLSLEEPENABLE },
		{ "CtrlSleepTime", ID_CTRLSLEEPTIME },
		{ "CtrlSleepTimeMin", ID_CTRLSLEEPTIME_MIN },
		{ "CtrlOverrideEnable", ID_CTRLOVERRIDEENABLE },
		{ "CtrlWiFiDisable", ID_CTRLWIFIDISABLE },
		{ "CtrlWiFiDisable_Comment", ID_CTRLWIFIDISABLE_COMMENT },
		{ "CtrlCurlCorrectEnable", ID_CTRLCURLCORRECTENABLE },
		{ "CtrlPreventQltyEnable", ID_CTRLPREVENTQLTYENABLE },
		{ "CtrlPreventClingEnable", ID_CTRLPREVENTCLINGENABLE },
		{ "CtrlReductWrinkleEnable", ID_CTRLREDUCTWRINKLEENABLE },
		{ "CtrlSPModeV", ID_CTRLSPECIALPRINTADJUSTMENT_V },
		{ "CtrlSPMode", ID_CTRLSPECIALPRINTADJUSTMENT },
		{ "CtrlSPModeB", ID_CTRLSPECIALPRINTADJUSTMENT_B },
		{ "CtrlSPModeSeparator", ID_CTRLSPECIALPRINTADJUSTMENT_SEPARATOR },
		{ "CtrlSPModeD", ID_CTRLSPECIALPRINTADJUSTMENT_D },
		{ "CtrlSPModeU", ID_CTRLSPECIALPRINTADJUSTMENT_U },
		{ "CtrlSPModeI", ID_CTRLSPECIALPRINTADJUSTMENT_I },
		{ "CtrlSPModeJ", ID_CTRLSPECIALPRINTADJUSTMENT_J },
		{ "CtrlSPModeK", ID_CTRLSPECIALPRINTADJUSTMENT_K },
		{ "CtrlPrintQuietMode", ID_CTRLPRINTQUIETMODE },
		{ "CtrlSelectLineWidth", ID_CTRLSELECTLINEWIDTH },
		{ "CtrlSPModeG", ID_CTRLSPECIALPRINTADJUSTMENT_G },
		{ "CtrlSPModeQ", ID_CTRLSPECIALPRINTADJUSTMENT_Q },
		{ "CtrlSPModeT", ID_CTRLSPECIALPRINTADJUSTMENT_T },
		{ "CtrlSPModeL", ID_CTRLSPECIALPRINTADJUSTMENT_L },
		{ "CtrlConsumablesType1", ID_CTRLCONSUMABLESDLG_TYPE1 },
		{ "CtrlConsumablesType2", ID_CTRLCONSUMABLESDLG_TYPE2 },
		{ "CtrlTonerB", ID_CTRLBLACKTONERINFO },
		{ "CtrlCrgB", ID_CTRLBLACKCARTRIDGEINFO },
		{ "CtrlConsumablesType3", ID_CTRLCONSUMABLESDLG_TYPE3 },
		{ "CtrlCT3Toner", ID_CTRLCT3TONERINFO },
		{ "CtrlCT3Drum", ID_CTRLCT3DRUMINFO },
		{ "CtrlCT3TonerCrg", ID_CTRLCT3TONERCARTRIDGEINFO },
		{ "CtrlCT3DrumCrg", ID_CTRLCT3DRUMCARTRIDGEINFO },
		{ "CtrlConsumablesType4", ID_CTRLCONSUMABLESDLG_TYPE4 },
		{ "CtrlCT4Toner", ID_CTRLCT4TONERINFO },
		{ "CtrlCT4Drum", ID_CTRLCT4DRUMINFO },
		{ "CtrlCT4TonerCrg", ID_CTRLCT4TONERCARTRIDGEINFO },
		{ "CtrlCT4DrumCrg", ID_CTRLCT4DRUMCARTRIDGEINFO },
		{ "CtrlCyanInfo", ID_CTRLCYANINFO },
		{ "CtrlMagentaInfo", ID_CTRLMAGENTAINFO },
		{ "CtrlYellowInfo", ID_CTRLYELLOWINFO },
		{ "CtrlBlackInfo", ID_CTRLBLACKINFO },
		{ "CtrlTotalPrinted", ID_CTRLTOTALPRINTED },
		{ "CtrlColorPrinted", ID_CTRLCOLORPRINTED },
		{ "CtrlMonoPrinted", ID_CTRLMONOPRINTED },
		{ "CtrlTwoSidedPrintedSheets", ID_CTRLTWOSIDEDPRINTEDSHEETS },
		{ "CtrlTotalMonoPrinted", ID_CTRLTOTALMONOPRINTED },
		{ "CtrlWLANStatus", ID_CTRLWLANSTATUS },
		{ "CtrlAutoShutdownEnable", ID_CTRLAUTOSHUTDOWNENABLE },
		{ "CtrlAutoShutdownTime", ID_CTRLAUTOSHUTDOWNTIME },
		{ "CtrlAutoShutdownTimeHr", ID_CTRLAUTOSHUTDOWNTIME_HR },
		{ "CtrlCalibEnable", ID_CTRLCALIBENABLE },
		{ "CtrlCalibTime", ID_CTRLCALIBTIME },
		{ "CtrlCalibTimeColon", ID_CTRLCALIBTIMECOLON },
		{ "CtrlCalibStartup", ID_CTRLCALIBSTARTUP },
		{ "CtrlFUCS1", ID_CTRLCS1FRAME_TEXT },
		{ "CtrlFUCS1PSW", ID_CTRLCS1PSWFRAME_TEXT },
		{ "CtrlFUCS2PSW", ID_CTRLCS2PSWFRAME_TEXT },
		{ "CtrlFUCS3PSW", ID_CTRLCS3PSWFRAME_TEXT },
		{ "CtrlFUCS4PSW", ID_CTRLCS4PSWFRAME_TEXT },
		{ "CtrlFUMPTray", ID_CTRLMPTRAYFRAME_TEXT },
		{ "CtrlFUAutoSelect", ID_CTRLASFRAME_TEXT },
		{ "CtrlFUHelp", ID_CTRLPFEEDHELPFRAME_TEXT },
		{ "CtrlFUSize", ID_CTRLSIZE_TEXT },
		{ "CtrlFUType", ID_CTRLTYPE_TEXT },
		{ "CtrlFUFeed", ID_CTRLFEED_TEXT },
		{ "CtrlFURough", ID_CTRLROUGH },
		{ "CtrlFUSourceMPT", ID_CTRLSOURCE_MPT},
		{ "CtrlFUSourceCS1", ID_CTRLSOURCE_CS1},
		{ "CtrlFUSourceCS2", ID_CTRLSOURCE_CS2},
		{ "CtrlFUSourceCS3", ID_CTRLSOURCE_CS3},
		{ "CtrlFUSourceCS4", ID_CTRLSOURCE_CS4},
		{ "WarningDisplay_dialog1", ID_WARNINGDISPLAY_DIALOG1 },
		{ "CtrlDisplayTonerLow", ID_CTRLDISPLAYTONERLOW },
		{ "WarningDetails_dialog1", ID_WARNINGDETAILS_DIALOG1 },
		{ "CtrlCRGLowThresholdComment", ID_CTRLCRGLOWTHRESHOLDCOMMENT },
		{ "CtrlCRGLowThresholdValue", ID_CTRLCRGLOWTHRESHOLDVALUE },
		{ "CtrlCRGLowThresholdUnit", ID_CTRLCRGLOWTHRESHOLDUNIT },
		{ "CtrlWarningDetailsType1", ID_CTRLWARNINGDETAILSDLG_TYPE1 },
		{ "CtrlWarningDetailsType2", ID_CTRLWARNINGDETAILSDLG_TYPE2 },
		{ "CtrlWarningDetailsType3", ID_CTRLWARNINGDETAILSDLG_TYPE3 },
		{ "CtrlTonerSpin", ID_CTRLTONERSPIN },
		{ "CtrlDrumSpin", ID_CTRLDRUMRSPIN },
		{ "CtrlDrumSpin2", ID_CTRLDRUMRSPIN2 },
		{ "MobilePrint_dialog1", ID_MOBILEPRINT_DIALOG1 },
		{ "CtrlMobilePrintHalftones", ID_CTRLMOBILEPRINTHALFTONES },
		{ "PaperSizeCheck_dialog1", ID_PAPERSIZECHECK_DIALOG1 },
		{ "CtrlPaperSizeMismatchAction", ID_CTRLPAPERSIZEMISMATCHACTION },
		{ "ReportPrint_dialog1", ID_REPORTPRINT_DIALOG1 },
		{ "CtrlReportPrintLang", ID_CTRLREPORTPRINTLANG },
		{ "SwitchPaperFeed_dialog1", ID_SWITCHPAPERFEED_DIALOG1 },
		{ "CtrlSwitchPaperFeedManualTray", ID_CTRLSWITCHPAPERFEEDMANUALTRAY },
		{ "CtrlSwitchPaperFeedCassette1", ID_CTRLSWITCHPAPERFEEDCASSETTE1 },
		{ "PC_scr_dialog1", ID_PC_SCR_DIALOG1 },
		{ "CtrlPC_scr_dialog_label", ID_CTRLPC_SCR_DIALOG_LABEL },
		{ NULL, ID_NULL_TERMINATE }
	};
	for( i = 0; id_convert_list[i].ppdValue != NULL; i++ )
	{
		if( strcmp( id_convert_list[i].ppdValue, pValue ) == 0 )
		{
			nRet = id_convert_list[i].ctrl_id;
			break;
		}
	}
	return nRet;
}

int GetMsgId( const UIStatusWnd* const wnd, const char* const key, const int default_id )
{
	int nRet = 0;
	char *pValue = NULL;
	char **pValueList = NULL;

	if( ( wnd != NULL ) && ( key != NULL ) )
	{
		pValue = cngplpGetValue_Wrapper( wnd->pModData, key );
		if( pValue != NULL )
		{
			pValueList = SeparateString( pValue, CHARACTER_COMMA);
			if( (pValueList != NULL) && (*pValueList != NULL) )
			{
				nRet = ConvertPPDCtrlId( pValueList[0] );
			}
		}
	}
	if( pValue != NULL )
	{
		mem_free( pValue );
	}
	if( pValueList != NULL )
	{
		mem_free_list( pValueList );
	}
	if( nRet == 0 )
	{
		nRet = default_id;
	}
	return nRet;
}

int GetCtrlIdList( const UIStatusWnd* const wnd, const char* const key, int* const pCtrlList )
{
	int i = 0;
	char *pValue = NULL;
	char **pValueList = NULL;

	if( ( wnd != NULL ) && ( pCtrlList != NULL ) )
	{
		pValue = cngplpGetValue_Wrapper( wnd->pModData, key );
		if( pValue != NULL )
		{
			pValueList = SeparateString( pValue, CHARACTER_COMMA);
			if( (pValueList != NULL) && (*pValueList != NULL) )
			{
				for( i = 0; pValueList[i] != NULL; i++ )
				{
					if( i < (CTRL_LIST_MAXNUM - 1) )
					{
						pCtrlList[i] = ConvertPPDCtrlId( pValueList[i] );
					}
				}
			}
		}
	}
	if( pValue != NULL )
	{
		mem_free( pValue );
	}
	if( pValueList != NULL )
	{
		mem_free_list( pValueList );
	}
	return i;
}

static
gboolean IsCtrlIdForPPD( const int nCtrlId, const int* const pCtrlList )
{
	int i = 0;
	gboolean bRet = FALSE;

	if( pCtrlList != NULL )
	{
		for( i = 0; i < (CTRL_LIST_MAXNUM - 1); i++ )
		{
			if( pCtrlList[i] == nCtrlId )
			{
				bRet = TRUE;
				break;
			}
		}
	}
	return bRet;
}

char* GetStrText(const CtrlTbl* const list, const int ctrlid)
{
	int loop = 0;

	if(list == NULL)
	{
		return NULL;
	}

	for( loop = 0; list[loop].ctrlid != -1 ; loop++ )
	{
		if( ctrlid == list[loop].ctrlid )
		{
			break;
		}
	}
	return _(list[loop].labeltext);
}

gboolean GetJobID( const UIStatusWnd* const wnd, int* const nJobId )
{
	gboolean bRet = TRUE;

	if( (wnd == NULL) || (nJobId == NULL ) )
	{
		return FALSE;
	}

	Dict *pJobIdDict = NULL;

	EnterCriticalSection( &g_StatusSection );

	pJobIdDict = GetDict_forkey( wnd->pStatusDict, KEY_JOB_ID );
	if( pJobIdDict == NULL )
	{
		bRet = FALSE;
	}

	if( bRet == TRUE )
	{
		bRet = GetDictValuetype_int( pJobIdDict, nJobId );
	}

	LeaveCriticalSection( &g_StatusSection );

	return bRet;
}

void CreatePPDCtrlTbl( const UIStatusWnd* const wnd, const char* const * const ctrl_type, CtrlTbl* const ctrlTbl, CtrlTbl** const PPDCtrlTbl )
{
	int i = 0, j = 0;
	int nCtrlList[CTRL_LIST_MAXNUM];

	if( (wnd == NULL ) || (ctrl_type == NULL) || (ctrlTbl == NULL) || (PPDCtrlTbl == NULL ) )
	{
		return;
	}

	memset( nCtrlList, 0x00, sizeof(nCtrlList) );

	if( ctrl_type[0] != NULL )
	{
		nCtrlList[0] = GetMsgId( wnd, ctrl_type[0], ctrlTbl[0].ctrlid );
		for( i = 1, j = 1; ctrl_type[i] != NULL; i++ )
		{
			j += GetCtrlIdList( wnd, ctrl_type[i], &nCtrlList[j] );
		}
	}

	for( i = 0; i < CTRL_LIST_MAXNUM; i++ )
	{
		PPDCtrlTbl[i] = NULL;
	}

	for( i = 0, j = 0; ctrlTbl[i].ctrlid != -1; i++ )
	{
		if( IsCtrlIdForPPD( ctrlTbl[i].ctrlid, nCtrlList ) == TRUE )
		{
			if( j < CTRL_LIST_MAXNUM )
			{
				PPDCtrlTbl[j] = &ctrlTbl[i];
			}
			j++;
		}
	}
}


GList* CreateGlist_DbId( CtrlTbl* const * const PPDCtrlTbl )
{
	GList *pGlist = NULL;
	int i = 0;

	if( PPDCtrlTbl == NULL )
	{
		return pGlist;
	}

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		if( PPDCtrlTbl[i]->dbid != 0 )
		{
			pGlist = g_list_append( pGlist, &PPDCtrlTbl[i]->dbid );
		}
	}
	return pGlist;
}

static gboolean IsCtrlIdForPPDCtrlTbl( const int ctrlID, CtrlTbl* const * const PPDCtrlTbl )
{
	int i = 0;
	gboolean bRet = FALSE;

	if( PPDCtrlTbl != NULL )
	{
		for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
		{
			if( PPDCtrlTbl[i]->ctrlid == ctrlID )
			{
				bRet = TRUE;
				break;
			}
		}
	}
	return bRet;
}

void SetLabel_HideWidget( GtkWidget* const window, CtrlTbl** const PPDCtrlTbl, const CtrlTbl* const ctrlTbl )
{
	int i = 0;

	if( (window == NULL) || (PPDCtrlTbl == NULL) || (ctrlTbl == NULL) )
	{
		return;
	}

	for( i = 0; ctrlTbl[i].ctrlid != -1; i++ )
	{
		if( IsCtrlIdForPPDCtrlTbl( ctrlTbl[i].ctrlid, PPDCtrlTbl ) == TRUE )
		{
			char* pText  = GetStrText( ctrlTbl, ctrlTbl[i].ctrlid );
			switch( ctrlTbl[i].labeltype )
			{
			case LABEL_TYPE_TITLE:
				SetDialogTitle( window, _(pText) );
				break;
			case LABEL_TYPE_TEXT:
				SetTextToLabel( window, ctrlTbl[i].labelname, pText );
				break;
			case LABEL_TYPE_BUTTON:
				SetButtonLabel( window, ctrlTbl[i].labelname, pText );
				break;
			case LABEL_TYPE_BOX:
				break;
			default:
				break;
			}
		}
		else
		{
			if( ctrlTbl[i].ctrlbox != NULL )
			{
				HideWidget( window, ctrlTbl[i].ctrlbox );
			}
		}
	}
}

void SetAreaInfo(UIStatusWnd* const wnd, const char *pAareaInfo)
{
	if (wnd != NULL)
	{
		ClearAreaInfo(wnd);
		wnd->pAreaInfo = mem_strudup(pAareaInfo, __FILE__, (unsigned int)__LINE__);
	}
}

const char *GetAreaInfo(const UIStatusWnd* const wnd)
{
	const char *pAreaInfo = NULL;

	if (wnd != NULL)
	{
		pAreaInfo = wnd->pAreaInfo;
	}

	return pAreaInfo;
}

void ClearAreaInfo(UIStatusWnd* const wnd)
{
	if (wnd != NULL)
	{
		if (wnd->pAreaInfo != NULL)
		{
			mem_free(wnd->pAreaInfo);
			wnd->pAreaInfo = NULL;
		}
	}
}

void AddCtrlData( const int id, CtrlTbl* const ctrlTbl, CtrlTbl** const ppdCtrlTbl )
{
	int i = 0, j = 0;

	if( (ppdCtrlTbl != NULL) && (ctrlTbl != NULL) )
	{
		for( i = 0; ppdCtrlTbl[i] != NULL; i++ )
		{
			;
		}

		for( j = 0; ctrlTbl[j].ctrlid != -1; j++ )
		{
			if( id == ctrlTbl[j].ctrlid )
			{
				ppdCtrlTbl[i] = &ctrlTbl[j];
				break;
			}
		}
	}
}

gboolean isLocaleJapanese( const UIStatusWnd* const wnd )
{
	gboolean isJP = FALSE;
	if( wnd != NULL)
	{
		const unsigned int nLocaleJa = strlen(LOCALE_JA);
		const int nComp = strncmp( wnd->locale, LOCALE_JA, nLocaleJa);
		if( nComp == 0 )
		{
			isJP = TRUE;
		}
	}
	return isJP;
}
