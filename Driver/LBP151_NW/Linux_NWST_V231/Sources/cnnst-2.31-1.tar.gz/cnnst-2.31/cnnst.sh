#!/bin/sh

DIR=/usr/lib/Canon/cnan1st
PROG=cnnst

exec ${DIR}/${PROG}
