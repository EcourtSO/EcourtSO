/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "widgets.h"
#include "statusinfo.h"
#include "commandcontroller.h"
#include "key_defines.h"
#include "value_defines.h"

static gboolean isCOMMError(const UIStatusWnd* const wnd);
static gboolean isCheckSupportedPrinter(const UIStatusWnd* const wnd, const char* const pSupportedKey);
static GList* CreateTonerGlist_ExceptBaseGlist(GList* const srcGlist, GList* const dstGlist);
static GList* sortCartridgeGlist(GList* const inDrumTonerGlist, gboolean inFlg);
static char* catTonerStrCreateFromGlist(const UIStatusWnd* const wnd, GList* const strGlist, gboolean isDrum);
static void catOpeFlagStrFromPpd(const UIStatusWnd* const wnd, GString* const gsPpdKeyStr, const char* const detailStatus);
static void CreateMsgFromSubstitutionStrWithPpdKey(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus, GList* const glCompositionStr, const char* const ppdKey);
static void CreateMsgFromSubstitutionStr(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus, GList* const glCompositionStr);
static void connectWarningMessage(char** const ppSubMessage, const char* const pConnectMsg);
static void deviceStatusAnalysis(UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage);
static void analysisCommonFuncWithPpdKey(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus, const char* const ppdKey);
static void analysisCommonFunc(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisPausePrinter(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisNicCommError(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisLocalCommError(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisUnSupportedPrinter(UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage);
static void analysisShutDown(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisUpdatingFirmware(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisServiceError(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisPaperJam(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisShippingLockError(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisCoverOpen(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisDuplexConnectionError(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisCassetteConnectionError(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisSetDuplexUnit(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisOuttrayOpen(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisOuttrayFull(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisPaperOver(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisCassetteOpen(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisMisPlacedToner(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisNoCrg(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus, gboolean isDrum);
static void analysisSealedTonerCrg(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisCrgMemError(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus, gboolean isDrum);
static void analysisCrgOut2(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisCrgOut1(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus, gboolean isDrum);
static void analysisCrgOut3(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus, gboolean isDrum);
static void analysisMisPrint(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisPaperMismatch(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisChangePaper(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisAddPaper(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisSetCleaningPage(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisSetRemovePaper(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisSetMemoryFull(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisWait(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisCleaning(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisCooling(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisCleaningJob(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisPrinting(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisAborting(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisAnyCrgOut(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisAnyCrgOut2(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus, gboolean isDrum);
static void analysisSleep(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisStandby(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisErrorPaperInfoFromPPDKey(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus);
static void analysisCrgInfoCommonFunc(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus, const char* const dictKey, gboolean isDrum);
static void analysisPaperSourceInfoCommonFunc(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus, char* const paperInfoStr);
static void commSingleSubstitutionSubMessage(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage,
	const char* const detailStatus, const char* const pSearchKey, char* const pSubstitutionInfo, const char* const pPunctuationStr);
static void analysisWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage, const char* const detailStatus);
static void drummemoryTagWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage, GList** const glWarningDrumList);
static void drumLifeReachedWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage, GList** const glWarningDrumList);
static void drumExceedUseFunc(const UIStatusWnd* const wnd, char** const ppSubMessage, GList** const glWarningDrumList);
static void drumLifeReached1WarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage, GList** const glWarningDrumList);
static void drumLifeNoticeWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage, GList** const glWarningDrumList);
static void memoryTagWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage);
static void tonerLifeReachedWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage, GList** const glWarningTonerList);
static void tonerExceedUseFunc(const UIStatusWnd* const wnd, char** const ppSubMessage, GList** const glWarningTonerList);
static void tonerLifeReached1WarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage, GList** const glWarningTonerList);
static void tonerLifeNoticeWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage, GList** const glWarningTonerList);
static void calibrationFailWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage);
static void regAdjustFailWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage);
static void regAdjustFailWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage);
static void regSendorWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage);
static void fdTrayWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage);

static void noPaperWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage);
static void overPaperWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage);
static void beltCleaningWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage);
static void fuserLifeReachedWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage);
static void cartridgeAccessingWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage);
static void commCrgWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage, GList** const warningTonerGlist, const char* const dictKey, const char* const warningKey, gboolean isDrum);
static void commWarningFuncWithKeyValue(const UIStatusWnd* const wnd, char** const ppSubMessage, const char* const warningKey, const char* const warningValue, const char* const ppdKey);
static void commOtherWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage, const char* const warningValue);
static void commPaperWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage, const char* const warningValue);


void* threadStatus(void* arg )
{
	UIStatusWnd* const statusWnd = (UIStatusWnd*)arg;
	if( statusWnd == NULL )
	{
		return NULL;
	}

	gboolean bShouldGetAreaInfo = FALSE;
	gboolean bGetAreaInfo = FALSE;

	{
		int nGetAreaInfo = (int)GETAREAINFO_NONE;

		if (GetPPDValue_Integer(statusWnd->pModData, "CNSUIGetAreaInfo", &nGetAreaInfo))
		{
			if ((GetAreaInfoType)nGetAreaInfo == GETAREAINFO_GET)
			{
				bShouldGetAreaInfo = TRUE;
			}
		}

		if (bShouldGetAreaInfo)
		{
			bGetAreaInfo = TRUE;
		}
	}

	while( statusWnd->bPoollingStop == FALSE )
	{
		Dict *tmpStatusDict = NULL;
		int nRet = COMM_HOST_ERROR;
		GetAreaInfoType getAreaInfoType = GETAREAINFO_NONE;

		if( statusWnd->pauseGetStatus != FALSE)
		{
			sleep(statusWnd->nStatusThreadSleepTime);
			continue;
		}

		if (bGetAreaInfo)
		{
			getAreaInfoType = GETAREAINFO_GET;
		}

		tmpStatusDict = CreateDict_GetStatus(getAreaInfoType);
		if( tmpStatusDict != NULL )
		{
			nRet = CommunicatePrinterData(statusWnd, NULL, tmpStatusDict, CODE_COMMAND_ANALYZE, FALSE);
			if( nRet == COMM_HOST_NO_ERROR )
			{
				EnterCriticalSection(&g_StatusSection);
				UI_DEBUG("%s CommunicatePrinterData success, from Line[%u] \n", __func__, __LINE__);
				DeleteDict(statusWnd->pStatusDict);
				statusWnd->pStatusDict = tmpStatusDict;

				gboolean bCOMMError = isCOMMError(statusWnd);

				if (bCOMMError)
				{
					ClearAreaInfo(statusWnd);
					if (bShouldGetAreaInfo)
					{
						bGetAreaInfo = TRUE;
					}
				}
				else
				{
					if (bGetAreaInfo)
					{
						const char *pAareaInfo = GetDictValueString_forKey(statusWnd->pStatusDict, KEY_AREAINFO);
						if (pAareaInfo == NULL)
						{
							ClearAreaInfo(statusWnd);
						}
						else
						{
							SetAreaInfo(statusWnd, pAareaInfo);
							bGetAreaInfo = FALSE;
						}
					}
					else if (bShouldGetAreaInfo && (GetAreaInfo(statusWnd) == NULL))
					{
						bGetAreaInfo = TRUE;
					}
				}

				LeaveCriticalSection(&g_StatusSection);
			}
			else
			{
				EnterCriticalSection(&g_StatusSection);
				ClearAreaInfo(statusWnd);
				LeaveCriticalSection(&g_StatusSection);
				if (bShouldGetAreaInfo)
				{
					bGetAreaInfo = TRUE;
				}
				DeleteDict(tmpStatusDict);
				UI_DEBUG("%s CommunicatePrinterData error, from Line[%u] \n", __func__, __LINE__);
			}

#ifdef _XML_DEBUG
			statusWnd->pauseGetStatus = TRUE;
#endif
		}

		sleep(statusWnd->nStatusThreadSleepTime);
	}

	EnterCriticalSection(&g_StatusSection);
	ClearAreaInfo(statusWnd);
	LeaveCriticalSection(&g_StatusSection);
	return NULL;
}

gboolean pollingGetStatus(gpointer user_data)
{
	UIStatusWnd* const statusWnd = g_status_window;
	char *pMainMessage = NULL;
	char *pSubMessage = NULL;

	if( statusWnd == NULL )
	{
		return TRUE;
	}


	EnterCriticalSection(&g_StatusSection);

    deviceStatusAnalysis(statusWnd, &pMainMessage, &pSubMessage);
    if(pMainMessage != NULL)
    {
        UpdateMainWindow(statusWnd, pMainMessage, pSubMessage);
    }
    else
    {
        UI_DEBUG("%s MainMessage Make Error, from Line[%u] \n", __func__, __LINE__);
    }

    LeaveCriticalSection(&g_StatusSection);

	if( pMainMessage != NULL)
	{
		mem_free( pMainMessage );
	}
	if( pSubMessage != NULL)
	{
		mem_free( pSubMessage );
	}
	return TRUE;
}

int msgXmlContextCreate(UIStatusWnd* const wnd)
{
	int		ret = -1;
	unsigned int	msgPathSize = 0;
	char		*msgPathBuf = NULL;

	if( (wnd == NULL) || (wnd->locale == NULL) )
	{
		return -1;
	}

	msgPathSize = strlen(STATUSMSG_FOLDER) + strlen(wnd->locale) + strlen(STATUSMSG_FILE) + 1u;
	msgPathBuf = (char*)mem_alloc(msgPathSize, __FILE__, __LINE__);
	if( msgPathBuf != NULL )
	{
		unsigned int strLength = strlen(STATUSMSG_FOLDER);
		strncpy(msgPathBuf, STATUSMSG_FOLDER, strLength);
		strLength = strlen(wnd->locale);
		strncat(msgPathBuf, wnd->locale, strLength);
		strLength = strlen(STATUSMSG_FILE);
		strncat(msgPathBuf, STATUSMSG_FILE, strLength);
		wnd->pMsgXmlContext = xmlContextCreate(msgPathBuf);
		if(wnd->pMsgXmlContext != NULL)
		{
			ret = 0;
		}
		mem_free(msgPathBuf);
	}
	return ret;
}

char* msgXmlGetString(const UIStatusWnd* const wnd, const char* const pKeyName)
{
	char* msgStr = NULL;

	if( (wnd == NULL) || (pKeyName == NULL) )
	{
		return NULL;
	}

	msgStr = xmlGetString(wnd->pMsgXmlContext, pKeyName);

	return msgStr;
}

void msgXmlContextDestory(UIStatusWnd* const wnd)
{
	if( (wnd == NULL) || (wnd->pMsgXmlContext == NULL) )
	{
		return;
	}

	xmlContextDestory(&(wnd->pMsgXmlContext));
}

gboolean isEnableJobCancel(const UIStatusWnd* const wnd)
{
	gboolean bEnableJobCancel = FALSE;
	gboolean bEnableJob = FALSE;
	int procJobId = 0;

	if(wnd == NULL)
	{
		return FALSE;
	}

	bEnableJob = GetDictValueInt_forKey(wnd->pStatusDict, KEY_JOB_ID, &procJobId);
	if(bEnableJob == TRUE)
	{
		char* const detailStatus = GetDictValueString_forKey(wnd->pStatusDict, KEY_STATUS);
		if( detailStatus != NULL )
		{
			UI_DEBUG("%s detailStatus[%s], from Line[%u] \n", __func__, detailStatus, __LINE__);
			if( strcmp(detailStatus, SCODE_ABORTING) != 0 )
			{
				bEnableJobCancel = TRUE;
			}
		}
	}

	return bEnableJobCancel;
}

gboolean isOperationEnable(const UIStatusWnd* const wnd, const char* const pOperation)
{
	GList *glOperationList = NULL;
	gboolean bEnableOperation = FALSE;

	if( (wnd == NULL) || (pOperation == NULL) )
	{
		return FALSE;
	}

	glOperationList = GetDictValueGList_forKey(wnd->pStatusDict, KEY_OPERATION);
	if(glOperationList != NULL)
	{
		if( g_list_find_custom(glOperationList, pOperation, (GCompareFunc)strcmp) != NULL )
		{
			bEnableOperation = TRUE;
		}
	}

	return bEnableOperation;
}

gboolean isHideMainWindow(const UIStatusWnd* const wnd)
{
	gboolean bHideWindow = TRUE;
	gboolean bEnableJob = FALSE;
	int procJobId = 0;

	if(wnd == NULL)
	{
		return bHideWindow;
	}

	bEnableJob = GetDictValueInt_forKey(wnd->pStatusDict, KEY_JOB_ID, &procJobId);
	if(bEnableJob == TRUE)
	{
		char* const pStatusGroup = GetDictValueString_forKey(wnd->pStatusDict, KEY_STATUS_GRP);
		if( pStatusGroup != NULL )
		{
			unsigned int compStatusGroup = (unsigned int)!(strcmp(pStatusGroup, SGROUP_WAIT));
			compStatusGroup |= (unsigned int)!(strcmp(pStatusGroup, SGROUP_IDLE));
			compStatusGroup |= (unsigned int)!(strcmp(pStatusGroup, SGROUP_PRINTING));
			if( compStatusGroup == 0u )
			{
				bHideWindow = FALSE;
			}
		}
	}

	return bHideWindow;
}

gboolean isWlanModel(const UIStatusWnd* const wnd)
{
	gboolean bWlanModel = FALSE;

	if(wnd == NULL)
	{
		return FALSE;
	}

	bWlanModel = isCheckSupportedPrinter(wnd, WLANMODEL_KEY);

	return bWlanModel;
}

gboolean isSupportedPrinter(const UIStatusWnd* const wnd)
{
	gboolean bSupportPrinter = FALSE;

	if(wnd == NULL)
	{
		return FALSE;
	}

	bSupportPrinter = isCheckSupportedPrinter(wnd, SUPPORTEDPRINTER_KEY);

	return bSupportPrinter;
}

static gboolean isCOMMError(const UIStatusWnd* const wnd)
{
	gboolean bCOMMError = FALSE;

	if (wnd != NULL)
	{
		const char *pStatusGroup = GetDictValueString_forKey(wnd->pStatusDict, KEY_STATUS_GRP);

		if (pStatusGroup != NULL)
		{
			if (strcmp(pStatusGroup, SGROUP_COMMERROR) == 0)
			{
				bCOMMError = TRUE;
			}
		}
	}

	return bCOMMError;
}

static gboolean isCheckSupportedPrinter(const UIStatusWnd* const wnd, const char* const pSupportedKey)
{
	gboolean bRetVal = FALSE;
	char *pDeviceModelStr = NULL;
	char *pSupportedInfoStr = NULL;
	char **ppSeparateStr = NULL;

	if( (wnd == NULL) || (pSupportedKey == NULL) )
	{
		return FALSE;
	}

	pDeviceModelStr = GetDictValueString_forKey(wnd->pStatusDict, KEY_MODEL_CODE);
	if(pDeviceModelStr == NULL)
	{
		UI_DEBUG("%s [%s] GetDict Error, from Line[%u] \n", __func__, KEY_MODEL_CODE, __LINE__);
		return FALSE;
	}

	pSupportedInfoStr = CngplpGetValue_AddPrefix(wnd, pSupportedKey);
	if(pSupportedInfoStr != NULL)
	{
		UI_DEBUG("%s pDeviceModelStr[%s], pSupportedInfoStr[%s], from Line[%u] \n", __func__, pDeviceModelStr, pSupportedInfoStr, __LINE__);
		ppSeparateStr = SeparateString(pSupportedInfoStr, CHARACTER_COMMA);
		mem_free(pSupportedInfoStr);
	}

	if(ppSeparateStr != NULL)
	{
		int idx = 0;
		for(idx = 0; ppSeparateStr[idx] != NULL; idx++)
		{
			if( strcmp(pDeviceModelStr, ppSeparateStr[idx]) == 0 )
			{
				bRetVal = TRUE;
				break;
			}
		}
		mem_free_list(ppSeparateStr);
	}

	return bRetVal;
}

static GList* CreateTonerGlist_ExceptBaseGlist(GList* const srcGlist, GList* const dstGlist)
{
	GList *glTonerInfo = NULL;

	if(dstGlist == NULL)
	{
		return NULL;
	}

	glTonerInfo = CreateGlist_ExceptBaseGlist(srcGlist, dstGlist);
	if(glTonerInfo != NULL)
	{
		GList* const glOpcElement = g_list_find_custom(glTonerInfo, OPC_STR, (GCompareFunc)strcmp);
		if(glOpcElement != NULL)
		{
			glTonerInfo = g_list_delete_link_wrapper(glTonerInfo, glOpcElement, __FILE__, __LINE__);
		}
	}

	return glTonerInfo;
}

#define PRIORITY_DRUM_NUM 5
#define PRIORITY_TONER_NUM 5

static GList* sortCartridgeGlist(GList* const inCartridgeGlist, gboolean inFlg)
{
	if(inCartridgeGlist == NULL)
	{
		return NULL;
	}

	GList *dstCrgGlist = NULL;
	if(inFlg)
	{
		const char* const priorityDrum[PRIORITY_DRUM_NUM] = {DRUM_C_STR, DRUM_M_STR, DRUM_Y_STR, DRUM_K_STR, NULL};
		int idx = 0;
		for(idx = 0; priorityDrum[idx] != NULL; idx++)
		{
			if( g_list_find_custom(inCartridgeGlist, (gpointer)priorityDrum[idx], (GCompareFunc)strcmp) != NULL)
			{
				dstCrgGlist = g_list_append_wrapper(dstCrgGlist, (gpointer)priorityDrum[idx], __FILE__, __LINE__);
			}
		}
	}
	else
	{
		const char* const priorityToner[PRIORITY_TONER_NUM] = {TONER_C_STR, TONER_M_STR, TONER_Y_STR, TONER_K_STR, NULL};
		int idx = 0;
		for(idx = 0; priorityToner[idx] != NULL; idx++)
		{
			if( g_list_find_custom(inCartridgeGlist, (gpointer)priorityToner[idx], (GCompareFunc)strcmp) != NULL)
			{
				dstCrgGlist = g_list_append_wrapper(dstCrgGlist, (gpointer)priorityToner[idx], __FILE__, __LINE__);
			}
		}
	}

	return dstCrgGlist;
}

static char* catTonerStrCreateFromGlist(const UIStatusWnd* const wnd, GList* const strGlist, gboolean isDrum)
{
	char *pTonerMessage = NULL;
	char *pCommaStr = NULL;
	GString *gsConnectMessage = NULL;
	gboolean gsFreeSegment = TRUE;

	if( (wnd == NULL) || (strGlist == NULL) )
	{
		return NULL;
	}

	gsConnectMessage = g_string_new_wrapper(NULL, __FILE__, __LINE__);
	if(gsConnectMessage == NULL)
	{
		return NULL;
	}

	pCommaStr = msgXmlGetString(wnd, STATUSCOMMA_XMLKEY);
	if(pCommaStr != NULL)
	{
		char *pTonerColor = NULL;
		GList *tmpCartridgeGlist = NULL;
		tmpCartridgeGlist = sortCartridgeGlist(strGlist, isDrum);
		GList* const topGlist = tmpCartridgeGlist;
		while(tmpCartridgeGlist != NULL)
		{
			if(tmpCartridgeGlist->data != NULL)
			{
				pTonerColor = msgXmlGetString(wnd, (const char*)tmpCartridgeGlist->data);
				if(pTonerColor != NULL)
				{
					UI_DEBUG("%s gsConnectMessage->str[%s], Add pTonerColor[%s], from Line[%u] \n", __func__, gsConnectMessage->str, pTonerColor, __LINE__);
					CatStrWithPunctuation(gsConnectMessage, pTonerColor, pCommaStr);
					mem_free(pTonerColor);
				}
			}

			tmpCartridgeGlist = g_list_next(tmpCartridgeGlist);
		}

		if(strcmp(gsConnectMessage->str, BLANK_MESSAGE) != 0)
		{
			pTonerMessage = gsConnectMessage->str;
			gsFreeSegment = FALSE;
		}
		g_string_free_wrapper(gsConnectMessage, gsFreeSegment);
		mem_free(pCommaStr);
		if(topGlist != NULL)
		{
			g_list_free_wrapper(topGlist);
		}
	}

	return pTonerMessage;
}

static void catOpeFlagStrFromPpd(const UIStatusWnd* const wnd, GString* const gsPpdKeyStr, const char* const detailStatus)
{
	char *pPpdOpeFlags = NULL;
	char **ppSeparateStr = NULL;

	if( (wnd == NULL) || (gsPpdKeyStr == NULL) || (detailStatus == NULL) )
	{
		return;
	}

	pPpdOpeFlags = CngplpGetValue_AddKeyStr(wnd, detailStatus, OPERATIONFLAG_ADDKEY);
	if(pPpdOpeFlags != NULL)
	{
		ppSeparateStr = SeparateString(pPpdOpeFlags, CHARACTER_COMMA);
		mem_free(pPpdOpeFlags);
	}

	if(ppSeparateStr != NULL)
	{
		int idx = 0;
		gboolean bEnableOperation = FALSE;

		g_string_append(gsPpdKeyStr, detailStatus);
		for(idx = 0; ppSeparateStr[idx] != NULL; idx++)
		{
			bEnableOperation = isOperationEnable(wnd, ppSeparateStr[idx]);
			if(bEnableOperation == TRUE)
			{
				CatStrWithPunctuation(gsPpdKeyStr, ppSeparateStr[idx], STRING_UNDERLINE);
			}
		}
		mem_free_list(ppSeparateStr);
	}
}

static void CreateMsgFromSubstitutionStrWithPpdKey(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus, GList* const glCompositionStr, const char* const ppdKey)
{
	char *pTmpSubMessage = NULL;

	if( (wnd == NULL) || (ppMainMessage == NULL) || (ppSubMessage == NULL) || (detailStatus == NULL) || (glCompositionStr == NULL) )
	{
		return;
	}

	analysisCommonFuncWithPpdKey(wnd, ppMainMessage, &pTmpSubMessage, detailStatus, ppdKey);
	if(pTmpSubMessage != NULL)
	{
		*ppSubMessage = CompositionString(glCompositionStr, pTmpSubMessage, COMPOSITONKEY_STRING);
		if(*ppSubMessage == NULL)
		{
			*ppSubMessage = mem_strudup(pTmpSubMessage, __FILE__, __LINE__);
		}
		mem_free(pTmpSubMessage);
	}
}

static void CreateMsgFromSubstitutionStr(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus, GList* const glCompositionStr)
{
	CreateMsgFromSubstitutionStrWithPpdKey(wnd, ppMainMessage, ppSubMessage, detailStatus, glCompositionStr, NULL);
}

static void connectWarningMessage(char** const ppSubMessage, const char* const pConnectMsg)
{
	GString *gsConnectedSubMessage = NULL;

	if( (ppSubMessage == NULL) || (pConnectMsg == NULL) )
	{
		return;
	}

	gsConnectedSubMessage = g_string_new_wrapper(*ppSubMessage, __FILE__, __LINE__);
	if(gsConnectedSubMessage != NULL)
	{
		if(*ppSubMessage != NULL)
		{
			mem_free(*ppSubMessage);
		}
		CatStrWithPunctuation(gsConnectedSubMessage, pConnectMsg, STRING_NEWLINE);
		*ppSubMessage = gsConnectedSubMessage->str;
		g_string_free_wrapper(gsConnectedSubMessage, FALSE);
	}
}

static void deviceStatusAnalysis(UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage)
{
	char *detailStatus = NULL;
	char *modelCode = NULL;
	gboolean isSupportPrinter = FALSE;

	if( (wnd == NULL) || (ppMainMessage == NULL) || (ppSubMessage == NULL) )
	{
		return;
	}

	modelCode = GetDictValueString_forKey(wnd->pStatusDict, KEY_MODEL_CODE);
	if( modelCode != NULL )
	{
		isSupportPrinter = isSupportedPrinter(wnd);
	}

	detailStatus = GetDictValueString_forKey(wnd->pStatusDict, KEY_STATUS);
	if( detailStatus != NULL ){
		UI_DEBUG("%s detailStatus[%s], from Line[%u] \n", __func__, detailStatus, __LINE__);
		if( strcmp(detailStatus, SCODE_PAUSEPRINTER) == 0 )
		{
			analysisPausePrinter(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_NICCOMMERROR) == 0 )
		{
			analysisNicCommError(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_LOCALCOMMERROR) == 0 )
		{
			analysisLocalCommError(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( isSupportPrinter == FALSE )
		{
			analysisUnSupportedPrinter(wnd, ppMainMessage, ppSubMessage);
		}
		else if( strcmp(detailStatus, SCODE_SHUTDOWN) == 0 )
		{
			analysisShutDown(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_UPDATINGFIRMWARE) == 0 )
		{
			analysisUpdatingFirmware(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_UPDATINGFIRMWAREMODE) == 0 )
		{
			analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_SERVICEERROR) == 0 )
		{
			analysisServiceError(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_PAPERJAM) == 0 )
		{
			analysisPaperJam(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_SHIPPINGLOCKERROR) == 0 )
		{
			analysisShippingLockError(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_COVEROPEN) == 0 )
		{
			analysisCoverOpen(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_DUPLEXCONNECTIONERROR) == 0 )
		{
			analysisDuplexConnectionError(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_CASSETTECONNECTIONERROR) == 0 )
		{
			analysisCassetteConnectionError(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_SETDUPLEXUNIT) == 0 )
		{
			analysisSetDuplexUnit(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_OUTTRAYOPEN) == 0 )
		{
			analysisOuttrayOpen(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_OUTTRAYFULL) == 0 )
		{
			analysisOuttrayFull(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_PAPEROVER) == 0 )
		{
			analysisPaperOver(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_CASSETTEOPEN) == 0 )
		{
			analysisCassetteOpen(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_MISPLACEDTONER) == 0 )
		{
			analysisMisPlacedToner(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_NODRUMCRG) == 0 )
		{
			analysisNoCrg(wnd, ppMainMessage, ppSubMessage, detailStatus, TRUE);
		}
		else if( strcmp(detailStatus, SCODE_NOTONERCRG) == 0 )
		{
			analysisNoCrg(wnd, ppMainMessage, ppSubMessage, detailStatus, FALSE);
		}
		else if( strcmp(detailStatus, SCODE_SEALEDTONERCRG) == 0 )
		{
			analysisSealedTonerCrg(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_DRUMMEMERROR) == 0 )
		{
			analysisCrgMemError(wnd, ppMainMessage, ppSubMessage, detailStatus, TRUE);
		}
		else if( strcmp(detailStatus, SCODE_TONERMEMERROR) == 0 )
		{
			analysisCrgMemError(wnd, ppMainMessage, ppSubMessage, detailStatus, FALSE);
		}
		else if( strcmp(detailStatus, SCODE_DRUMOUT2) == 0 )
		{
			analysisCrgOut2(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_TONEROUT2) == 0 )
		{
			analysisCrgOut2(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_DRUMOUT3) == 0 )
		{
			analysisCrgOut3(wnd, ppMainMessage, ppSubMessage, detailStatus, TRUE);
		}
		else if( strcmp(detailStatus, SCODE_TONEROUT1) == 0 )
		{
			analysisCrgOut1(wnd, ppMainMessage, ppSubMessage, detailStatus, FALSE);
		}
		else if( strcmp(detailStatus, SCODE_DRUMOUT1) == 0 )
		{
			analysisCrgOut1(wnd, ppMainMessage, ppSubMessage, detailStatus, TRUE);
		}
		else if( strcmp(detailStatus, SCODE_TONEROUT3) == 0 )
		{
			analysisCrgOut3(wnd, ppMainMessage, ppSubMessage, detailStatus, FALSE);
		}
		else if( strcmp(detailStatus, SCODE_MISPRINT) == 0 )
		{
			analysisMisPrint(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_PAPERMISMATCH) == 0 )
		{
			analysisPaperMismatch(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_CHANGEPAPER) == 0 )
		{
			analysisChangePaper(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_ADDPAPER) == 0 )
		{
			analysisAddPaper(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_SETCLEANINGPAGE) == 0 )
		{
			analysisSetCleaningPage(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_REMOVEPAPER) == 0 )
		{
			analysisSetRemovePaper(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_MEMORYFULL) == 0 )
		{
			analysisSetMemoryFull(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_WAIT) == 0 )
		{
			analysisWait(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_CLEANING) == 0 )
		{
			analysisCleaning(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_COOLING) == 0 )
		{
			analysisCooling(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_CLEANINGJOB) == 0 )
		{
			analysisCleaningJob(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_PRINTING) == 0 )
		{
			analysisPrinting(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_ABORTING) == 0 )
		{
			analysisAborting(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_ANYDRUMOUT) == 0 )
		{
			analysisAnyCrgOut(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_ANYTONEROUT) == 0 )
		{
			analysisAnyCrgOut(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_ANYDRUMOUT2) == 0 )
		{
			analysisAnyCrgOut2(wnd, ppMainMessage, ppSubMessage, detailStatus, FALSE);
		}
		else if( strcmp(detailStatus, SCODE_ANYTONEROUT2) == 0 )
		{
			analysisAnyCrgOut2(wnd, ppMainMessage, ppSubMessage, detailStatus, FALSE);
		}
		else if( strcmp(detailStatus, SCODE_SLEEP) == 0 )
		{
			analysisSleep(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else if( strcmp(detailStatus, SCODE_STANDBY) == 0 )
		{
			analysisStandby(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else
		{
			UI_DEBUG("%s not support type, detailStatus[%s], from Line[%u] \n", __func__, detailStatus, __LINE__);
		}
	}
}

static void analysisCommonFuncWithPpdKey(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus, const char* const ppdKey)
{
	char *statusGroup = NULL;
	const char *messagePpdKey = detailStatus;

	if( (wnd == NULL) || (ppMainMessage == NULL) || (ppSubMessage == NULL) || (detailStatus == NULL) )
	{
		return;
	}

	statusGroup = GetDictValueString_forKey(wnd->pStatusDict, KEY_STATUS_GRP);
	if(statusGroup == NULL)
	{
		UI_DEBUG("%s statusGroup is NULL, from Line[%u] \n", __func__, __LINE__);
		return;
	}

	if(ppdKey != NULL)
	{
		const unsigned int nPpdKeyLen = strlen(ppdKey);
		if(nPpdKeyLen > 0u)
		{
			messagePpdKey = ppdKey;
		}
	}

	UI_DEBUG("%s messagePpdKey[%s], from Line[%u] \n", __func__, messagePpdKey, __LINE__);

	*ppMainMessage = getMessageFromPPDKey(wnd, messagePpdKey, NULL);
	*ppSubMessage = getMessageFromPPDKey(wnd, messagePpdKey, SUBMESSAGE_ADDKEY);
	if(*ppMainMessage != NULL)
	{
		UI_DEBUG("%s *ppMainMessage[%s], *ppSubMessage[%s], statusGroup[%s], from Line[%u] \n", __func__, *ppMainMessage, *ppSubMessage, statusGroup, __LINE__);
		unsigned int compStatusGroup = (unsigned int)!(strcmp(statusGroup, SGROUP_IDLE));
		compStatusGroup |= (unsigned int)!(strcmp(statusGroup, SGROUP_PRINTING));
		if(compStatusGroup == 1u)
		{
			UI_DEBUG("%s Call analysisWarningFunc, from Line[%u] \n", __func__, __LINE__);
			analysisWarningFunc(wnd, ppSubMessage, detailStatus);
		}
	}
}

static void analysisCommonFunc(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCommonFuncWithPpdKey(wnd, ppMainMessage, ppSubMessage, detailStatus, NULL);
}

static void analysisPausePrinter(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisNicCommError(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisLocalCommError(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisUnSupportedPrinter(UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage)
{
	Dict *pUnSupportedDict = NULL;

	if( (wnd == NULL) || (ppMainMessage == NULL) || (ppSubMessage == NULL) )
	{
		return;
	}

	pUnSupportedDict = CreateDict_GetStatus(GETAREAINFO_NONE);
	if(pUnSupportedDict != NULL)
	{
		CreateDict_String_Value(pUnSupportedDict, KEY_STATUS_GRP, SGROUP_COMMERROR);
		CreateDict_String_Value(pUnSupportedDict, KEY_STATUS, SCODE_UNSUPPORTEDPRINTER);

		DeleteDict(wnd->pStatusDict);
		wnd->pStatusDict = pUnSupportedDict;

		analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, SCODE_UNSUPPORTEDPRINTER);
	}
}

static void analysisShutDown(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisUpdatingFirmware(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisServiceError(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	GList *glErrorCode = NULL;
	GString *gsConnectMessage = NULL;

	if( (wnd == NULL) || (ppMainMessage == NULL) || (ppSubMessage == NULL) || (detailStatus == NULL) )
	{
		return;
	}

	gsConnectMessage = g_string_new_wrapper(NULL, __FILE__, __LINE__);
	if(gsConnectMessage == NULL)
	{
		return;
	}

	glErrorCode = GetDictValueGList_forKey(wnd->pStatusDict, KEY_SERVICE_ERROR_CODE);
	if(glErrorCode != NULL)
	{
		while(glErrorCode != NULL)
		{
			char* const pErrorCode = GetDictValuetype_char((Dict*)glErrorCode->data);
			if(pErrorCode != NULL)
			{
				CatStrWithPunctuation(gsConnectMessage, pErrorCode, STRING_NEWLINE_TAB);
			}

			glErrorCode = g_list_next(glErrorCode);
		}
	}

	if(strcmp(gsConnectMessage->str, BLANK_MESSAGE) == 0)
	{
		char* const pDefaultErrorCode = msgXmlGetString(wnd, SERVICEERROR_DEFAULTKEY);
		if(pDefaultErrorCode != NULL)
		{
			CatStrWithPunctuation(gsConnectMessage, pDefaultErrorCode, NULL);
			mem_free(pDefaultErrorCode);
		}
	}

	if(strcmp(gsConnectMessage->str, BLANK_MESSAGE) == 0)
	{
		analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
	}
	else
	{
		GList *glCompositionStr = NULL;
		glCompositionStr = g_list_append_wrapper(glCompositionStr, (gpointer)gsConnectMessage->str, __FILE__, __LINE__);
		if(glCompositionStr != NULL)
		{
			CreateMsgFromSubstitutionStr(wnd, ppMainMessage, ppSubMessage, detailStatus, glCompositionStr);
			g_list_free_wrapper(glCompositionStr);
		}
	}

	g_string_free_wrapper(gsConnectMessage, TRUE);
}

static void analysisPaperJam(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	char *pSubStitutaionInfo = NULL;

	if( (wnd == NULL) || (ppMainMessage == NULL) || (ppSubMessage == NULL) || (detailStatus == NULL) )
	{
		return;
	}

	pSubStitutaionInfo = CngplpGetValue_AddKeyStr(wnd, detailStatus, JAMPOINT_ADDKEY);
	if(pSubStitutaionInfo == NULL)
	{
		pSubStitutaionInfo = mem_strudup(JAMPOINT_DEFAULT, __FILE__, __LINE__);
	}

	if(pSubStitutaionInfo != NULL)
	{
		if( strcmp(pSubStitutaionInfo, PPDVALUE_BLANK) == 0)
		{
			analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else
		{
			commSingleSubstitutionSubMessage(wnd, ppMainMessage, ppSubMessage, detailStatus, KEY_JAM_ACCESS, pSubStitutaionInfo, STRING_NEWLINE);
		}
		mem_free(pSubStitutaionInfo);
	}
}

static void analysisShippingLockError(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisCoverOpen(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	char *pSubStitutaionInfo = NULL;

	if( (wnd == NULL) || (ppMainMessage == NULL) || (ppSubMessage == NULL) || (detailStatus == NULL) )
	{
		return;
	}

	pSubStitutaionInfo = CngplpGetValue_AddKeyStr(wnd, detailStatus, COVEROPENOPINT_ADDKEY);
	if(pSubStitutaionInfo == NULL)
	{
		pSubStitutaionInfo = mem_strudup(COVEROPENOPINT_DEFAULT, __FILE__, __LINE__);
	}

	if(pSubStitutaionInfo != NULL)
	{
		commSingleSubstitutionSubMessage(wnd, ppMainMessage, ppSubMessage, detailStatus, KEY_COVER_POS, pSubStitutaionInfo, STRING_NEWLINE);
		mem_free(pSubStitutaionInfo);
	}
}

static void analysisDuplexConnectionError(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisCassetteConnectionError(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisSetDuplexUnit(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisOuttrayOpen(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisOuttrayFull(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisPaperOver(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	char *pSubStitutaionInfo = NULL;

	if( (wnd == NULL) || (ppMainMessage == NULL) || (ppSubMessage == NULL) || (detailStatus == NULL) )
	{
		return;
	}

	pSubStitutaionInfo = CngplpGetValue_AddKeyStr(wnd, detailStatus, PAPEROVERPOINT_ADDKEY);
	if(pSubStitutaionInfo == NULL)
	{
		pSubStitutaionInfo = mem_strudup(PAPEROVERPOINT_DEFAULT, __FILE__, __LINE__);
	}

	if(pSubStitutaionInfo != NULL)
	{
		if( strcmp(pSubStitutaionInfo, PPDVALUE_BLANK) == 0)
		{
			analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else
		{
			commSingleSubstitutionSubMessage(wnd, ppMainMessage, ppSubMessage, detailStatus, KEY_PAPER_WARNING, pSubStitutaionInfo, STRING_NEWLINE);
		}
		mem_free(pSubStitutaionInfo);
	}
}

static void analysisCassetteOpen(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisMisPlacedToner(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCrgInfoCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus, KEY_CONSUMABLE_ERROR, FALSE);
}

static void analysisNoCrg(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus, gboolean isDrum)
{
	analysisCrgInfoCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus, KEY_CONSUMABLE_ERROR, isDrum);
}

static void analysisSealedTonerCrg(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCrgInfoCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus, KEY_CONSUMABLE_ERROR, FALSE);
}

static void analysisCrgMemError(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus, gboolean isDrum)
{
	analysisCrgInfoCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus, KEY_CONSUMABLE_ERROR, isDrum);
}

static void analysisCrgOut2(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisCrgOut1(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus, gboolean isDrum)
{
	analysisCrgInfoCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus, KEY_CONSUMABLE_ERROR, isDrum);
}

static void analysisCrgOut3(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus, gboolean isDrum)
{
	analysisCrgInfoCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus, KEY_CONSUMABLE_ERROR, isDrum);
}

static void analysisMisPrint(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisPaperMismatch(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisErrorPaperInfoFromPPDKey(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisChangePaper(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisErrorPaperInfoFromPPDKey(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisAddPaper(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisErrorPaperInfoFromPPDKey(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisSetCleaningPage(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisSetRemovePaper(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisSetMemoryFull(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	GString *gsPpdKeyStr = NULL;

	gsPpdKeyStr = g_string_new_wrapper(NULL, __FILE__, __LINE__);
	if(gsPpdKeyStr == NULL)
	{
		return;
	}

	catOpeFlagStrFromPpd(wnd, gsPpdKeyStr, detailStatus);
	analysisCommonFuncWithPpdKey(wnd, ppMainMessage, ppSubMessage, detailStatus, gsPpdKeyStr->str);

	g_string_free_wrapper(gsPpdKeyStr, TRUE);
}

static void analysisWait(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	char *pSubStitutaionInfo = NULL;

	if( (wnd == NULL) || (ppMainMessage == NULL) || (ppSubMessage == NULL) || (detailStatus == NULL) )
	{
		return;
	}

	pSubStitutaionInfo = CngplpGetValue_AddKeyStr(wnd, detailStatus, WAITLIST_ADDKEY);
	if(pSubStitutaionInfo == NULL)
	{
		pSubStitutaionInfo = mem_strudup(WAITLIST_DEFAULT, __FILE__, __LINE__);
	}

	if(pSubStitutaionInfo != NULL)
	{
		commSingleSubstitutionSubMessage(wnd, ppMainMessage, ppSubMessage, detailStatus, KEY_WAIT_DETAIL, pSubStitutaionInfo, STRING_NEWLINE);
		mem_free(pSubStitutaionInfo);
	}
}

static void analysisCleaning(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisCooling(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisCleaningJob(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisPrinting(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisAborting(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisAnyCrgOut(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisAnyCrgOut2(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus, gboolean isDrum)
{
	analysisCrgInfoCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus, KEY_TONEROUT1_WARNING, isDrum);
}

static void analysisSleep(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisStandby(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
}

static void analysisCrgInfoCommonFunc(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus, const char* const dictKey, gboolean isDrum)
{
	GList *glErrTonerList = NULL;
	char *errTonerStr = NULL;

	if( (wnd == NULL) || (ppMainMessage == NULL) || (ppSubMessage == NULL) || (detailStatus == NULL) || (dictKey == NULL) )
	{
		return;
	}

	glErrTonerList = GetDictValueGList_forKey(wnd->pStatusDict, dictKey);

	UI_DEBUG("%s detailStatus[%s], dictKey[%s], isDrum[%d], from Line[%u] \n", __func__, detailStatus, dictKey, isDrum, __LINE__);

	if(glErrTonerList != NULL)
	{
		int i;
		for( i = 0; i < g_list_length( glErrTonerList ); i++ )
		{
			gchar *tmpStr = (gchar*)g_list_nth_data( glErrTonerList, i );
			UI_DEBUG("%s glErrTonerList[%d] = %s, from Line[%u] \n", __func__, i, tmpStr, __LINE__);
		}

		errTonerStr = catTonerStrCreateFromGlist(wnd, glErrTonerList, isDrum);
	}
	else
	{
		UI_DEBUG("%s glErrTonerList is NULL, from Line[%u] \n", __func__, __LINE__);
	}

	if(errTonerStr == NULL)
	{
		UI_DEBUG("%s errTonerStr is NULL, from Line[%u] \n", __func__, __LINE__);
		errTonerStr = mem_strudup(BLANK_MESSAGE, __FILE__, __LINE__);
	}

	if(errTonerStr != NULL)
	{
		UI_DEBUG("%s errTonerStr[%s], from Line[%u] \n", __func__, errTonerStr, __LINE__);
		if(strcmp(errTonerStr, BLANK_MESSAGE) == 0)
		{
			analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else
		{
			GList *glCompositionStr = NULL;
			glCompositionStr = g_list_append_wrapper(glCompositionStr, (gpointer)errTonerStr, __FILE__, __LINE__);
			if(glCompositionStr != NULL)
			{
				CreateMsgFromSubstitutionStr(wnd, ppMainMessage, ppSubMessage, detailStatus, glCompositionStr);
				g_list_free_wrapper(glCompositionStr);
			}
		}
		mem_free(errTonerStr);
	}
}

static
GString*
zAppendSystemLocaleString(
	const UIStatusWnd* const	pWnd,
	const char*					pBaseString
)
{
	GString*					pReturnString = NULL;

	if( ( pWnd != NULL ) && ( pWnd->locale != NULL ) && ( pBaseString != NULL ) )
	{
		pReturnString = g_string_new(pBaseString);
		if( pReturnString != NULL )
		{
			g_string_append(pReturnString, "_");
			g_string_append(pReturnString, pWnd->locale);
		}
	}

	return	pReturnString;
}

static
char*
zGetMessageInfoBySystemLocale(
	const UIStatusWnd* const	pWnd,
	const char*					pDetailStatus,
	const char*					pMessageInfoPrefix
)
{
	char*						pMessageInfoValue = NULL;
	if( ( pWnd != NULL ) && ( pDetailStatus != NULL ) && ( pMessageInfoPrefix != NULL ) )
	{
		GString*				pMessageInfoValueName = zAppendSystemLocaleString(pWnd, pMessageInfoPrefix);
		if( pMessageInfoValueName != NULL )
		{
			pMessageInfoValue = CngplpGetValue_AddKeyStr(pWnd, pDetailStatus, pMessageInfoValueName->str);
			if( pMessageInfoValue == NULL )
			{
				pMessageInfoValue = CngplpGetValue_AddKeyStr(pWnd, pDetailStatus, pMessageInfoPrefix);
			}
			g_string_free(pMessageInfoValueName, TRUE);
			pMessageInfoValueName = NULL;
		}
	}

	return	pMessageInfoValue;
}

static
char*
zGetErrorPaperInfoValue(
	const UIStatusWnd* const	pWnd,
	const char*					pDetailStatus
)
{
	char*						pErrorPaperInfoValue = NULL;
	if( ( pWnd != NULL ) && ( pDetailStatus != NULL ) )
	{
		char*					pErrorPaperInfoValuNamePrefix = ERRORPAPERINFO_ADDKEY;
		pErrorPaperInfoValue = zGetMessageInfoBySystemLocale(pWnd, pDetailStatus, pErrorPaperInfoValuNamePrefix);
		if( pErrorPaperInfoValue == NULL )
		{
			char*				pDefaultErrorPaperInfo = ERRORPAPERINFO_EN_DEFAULT;
			if( isLocaleJapanese(pWnd) != FALSE )
			{
				pDefaultErrorPaperInfo = ERRORPAPERINFO_JP_DEFAULT;
			}
			pErrorPaperInfoValue = mem_strudup(pDefaultErrorPaperInfo, __FILE__, __LINE__);
		}
	}

	return	pErrorPaperInfoValue;
}

static void analysisErrorPaperInfoFromPPDKey(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus)
{
	char *pPaperInfoValue = NULL;

	if( (wnd == NULL) || (ppMainMessage == NULL) || (ppSubMessage == NULL) || (detailStatus == NULL) )
	{
		return;
	}

	pPaperInfoValue = zGetErrorPaperInfoValue(wnd, detailStatus);
	if(pPaperInfoValue != NULL)
	{
		analysisPaperSourceInfoCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus, pPaperInfoValue);
		mem_free(pPaperInfoValue);
	}
}

static void analysisPaperSourceInfoCommonFunc(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage, const char* const detailStatus, char* const paperInfoStr)
{
	Dict *pErrPaperDict = NULL;
	char **ppSeparateStr = NULL;
	GString *gsPpdKeyStr = NULL;

	if( (wnd == NULL) || (ppMainMessage == NULL) || (ppSubMessage == NULL) || (paperInfoStr == NULL) || (detailStatus == NULL) )
	{
		return;
	}

	pErrPaperDict = GetDictValueDict_forKey(wnd->pStatusDict, KEY_ERROR_PAPER_STATUS);
	if(pErrPaperDict ==  NULL)
	{
		UI_DEBUG("%s pErrPaperDict is NULL, from Line[%u] \n", __func__, __LINE__);
		return;
	}

	gsPpdKeyStr = g_string_new_wrapper(NULL, __FILE__, __LINE__);
	if(gsPpdKeyStr == NULL)
	{
		return;
	}

	ppSeparateStr = SeparateString(paperInfoStr, CHARACTER_COMMA);
	if(ppSeparateStr != NULL)
	{
		GList *glCompositionStr = NULL;
		char *pDispPaperInfo = NULL;
		char *pDispPaperInfoStr = NULL;
		int idx = 0;
		int compValPaperSourceMPTray = 1;


		for(idx = 0; ppSeparateStr[idx] != NULL; idx++)
		{
			pDispPaperInfo = GetDictValueString_forKey(pErrPaperDict, ppSeparateStr[idx]);
			if(pDispPaperInfo != NULL)
			{
				int compKeyPaperSize = strcmp(ppSeparateStr[idx], KEY_PAPER_SIZE);
				int compKeyOrientation = strcmp(ppSeparateStr[idx], KEY_ORIENTATION);
				int compValUserSettingPaper = strcmp(pDispPaperInfo, PAPER_SIZE_USER_PAPER);
				if(compValPaperSourceMPTray != 0)
				{
					compValPaperSourceMPTray = strcmp(pDispPaperInfo, MPTRAY_STR);
				}
				if( (compKeyPaperSize == 0) && (compValUserSettingPaper == 0) )
				{
					pDispPaperInfo = ERRORPAPER_PAPERSIZE_USERSETTINGPAPER;
				}
				else if(compKeyOrientation == 0)
				{
					int compValOrientationShortEdge = strcmp(pDispPaperInfo, ORIENTATION_SHORT_EDGE);
					if(compValOrientationShortEdge == 0)
					{
						pDispPaperInfo = ORIENTATION_SHORT_EDGE_FORSTATUSMSG;
					}
					else
					{
						pDispPaperInfo = ORIENTATION_LONG_EDGE_FORSTATUSMSG;
					}
				}
			}

			if( pDispPaperInfo != NULL )
			{
				pDispPaperInfoStr = getMessageFromPPDKey(wnd, pDispPaperInfo, NULL);
			}

			if(pDispPaperInfoStr != NULL)
			{
				glCompositionStr = g_list_append_wrapper(glCompositionStr, (gpointer)pDispPaperInfoStr, __FILE__, __LINE__);
				if(glCompositionStr == NULL)
				{
					UI_DEBUG("%s glCompositionStr Append Error, from Line[%u] \n", __func__, __LINE__);
					mem_free(pDispPaperInfoStr);
					break;
				}
				pDispPaperInfoStr = NULL;
			}
		}

		catOpeFlagStrFromPpd(wnd, gsPpdKeyStr, detailStatus);

		if(compValPaperSourceMPTray == 0)
		{
			if(strcmp(detailStatus, SCODE_ADDPAPER) == 0 ||
				strcmp(detailStatus, SCODE_PAPERMISMATCH) == 0)
			{
				char *pTmpStr = NULL;

				pTmpStr = CngplpGetValue_AddKeyStr(wnd, detailStatus, MPTRAY_ADDKEY);
				if(pTmpStr != NULL)
				{
					if(gsPpdKeyStr->len == 0)
					{
						g_string_append(gsPpdKeyStr, detailStatus);
					}
					g_string_append(gsPpdKeyStr, MPTRAY_ADDKEY);

					mem_free(pTmpStr);
				}
			}
		}

		if(glCompositionStr == NULL)
		{
			analysisCommonFuncWithPpdKey(wnd, ppMainMessage, ppSubMessage, detailStatus, gsPpdKeyStr->str);
		}
		else
		{
			CreateMsgFromSubstitutionStrWithPpdKey(wnd, ppMainMessage, ppSubMessage, detailStatus, glCompositionStr, gsPpdKeyStr->str);

			g_list_foreach(glCompositionStr, (GFunc)mem_free, NULL);
			g_list_free_wrapper(glCompositionStr);
		}

		mem_free_list(ppSeparateStr);
	}
	g_string_free_wrapper(gsPpdKeyStr, TRUE);
}

static void commSingleSubstitutionSubMessage(const UIStatusWnd* const wnd, char** const ppMainMessage, char** const ppSubMessage,
	const char* const detailStatus, const char* const pSearchKey, char* const pSubstitutionInfo, const char* const pPunctuationStr)
{
	GList *glSearchedValue = NULL;
	char **ppSeparateStr = NULL;
	GString *gsConnectMessage = NULL;

	if( (wnd == NULL) || (ppMainMessage == NULL) || (ppSubMessage == NULL) || (detailStatus == NULL) ||
	    (pSearchKey == NULL) || (pSubstitutionInfo == NULL) || (pPunctuationStr == NULL) )
	{
		return;
	}

	gsConnectMessage = g_string_new_wrapper(NULL, __FILE__, __LINE__);
	if(gsConnectMessage == NULL)
	{
		return;
	}

	glSearchedValue = GetDictValueGList_forKey(wnd->pStatusDict, pSearchKey);
	if(glSearchedValue == NULL)
	{
		UI_DEBUG("%s glSearchedValue is NULL, from Line[%u] \n", __func__, __LINE__);
		return;
	}

	ppSeparateStr = SeparateString(pSubstitutionInfo, CHARACTER_COMMA);
	if(ppSeparateStr != NULL)
	{
		char *pDispOneMsgStr = NULL;
		int idx = 0;

		for(idx = 0; ppSeparateStr[idx] != NULL; idx++)
		{
			if( g_list_find_custom(glSearchedValue, (gpointer)ppSeparateStr[idx], (GCompareFunc)strcmp) != NULL )
			{
				pDispOneMsgStr = getMessageFromPPDKey(wnd, ppSeparateStr[idx], NULL);
				if(pDispOneMsgStr != NULL)
				{
					CatStrWithPunctuation(gsConnectMessage, pDispOneMsgStr, pPunctuationStr);
					mem_free(pDispOneMsgStr);
				}
			}
		}

		if(strcmp(gsConnectMessage->str, BLANK_MESSAGE) == 0)
		{
			analysisCommonFunc(wnd, ppMainMessage, ppSubMessage, detailStatus);
		}
		else
		{
			GList *glCompositionStr = NULL;
			glCompositionStr = g_list_append_wrapper(glCompositionStr, (gpointer)gsConnectMessage->str, __FILE__, __LINE__);
			if(glCompositionStr != NULL)
			{
				CreateMsgFromSubstitutionStr(wnd, ppMainMessage, ppSubMessage, detailStatus, glCompositionStr);
				g_list_free_wrapper(glCompositionStr);
			}
		}

		g_string_free_wrapper(gsConnectMessage, TRUE);
		mem_free_list(ppSeparateStr);
	}
}

static void analysisWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage, const char* const detailStatus)
{
	unsigned int compDetailStatus = 0u;

	if( (wnd == NULL) || (ppSubMessage == NULL)  || (detailStatus == NULL))
	{
		return;
	}

	if( *ppSubMessage != NULL )
	{
		const unsigned int nSubMessageLen = strlen(*ppSubMessage);
		if(nSubMessageLen > 0u)
		{
			AddNewLine(ppSubMessage);
		}
	}

	GList *glWarningDrumList = NULL;
	drummemoryTagWarningFunc(wnd, ppSubMessage, &glWarningDrumList);

	compDetailStatus = (unsigned int)!(strcmp(detailStatus, SCODE_ANYDRUMOUT));
	compDetailStatus |= (unsigned int)!(strcmp(detailStatus, SCODE_ANYDRUMOUT2));
	if (compDetailStatus == 0U)
	{
		drumLifeReachedWarningFunc(wnd, ppSubMessage, &glWarningDrumList);
		drumExceedUseFunc(wnd, ppSubMessage, &glWarningDrumList);
		drumLifeReached1WarningFunc(wnd, ppSubMessage, &glWarningDrumList);
		drumLifeNoticeWarningFunc(wnd, ppSubMessage, &glWarningDrumList);
		if(glWarningDrumList != NULL)
		{
			g_list_free_wrapper(glWarningDrumList);
		}
	}

	memoryTagWarningFunc(wnd, ppSubMessage);

	compDetailStatus = (unsigned int)!(strcmp(detailStatus, SCODE_ANYTONEROUT));
	compDetailStatus |= (unsigned int)!(strcmp(detailStatus, SCODE_ANYTONEROUT2));
	if(compDetailStatus == 0u){
		GList *glWarningTonerList = NULL;
		tonerLifeReachedWarningFunc(wnd, ppSubMessage, &glWarningTonerList);
		tonerExceedUseFunc(wnd, ppSubMessage, &glWarningTonerList);
		tonerLifeReached1WarningFunc(wnd, ppSubMessage, &glWarningTonerList);
		tonerLifeNoticeWarningFunc(wnd, ppSubMessage, &glWarningTonerList);
		if(glWarningTonerList != NULL)
		{
			g_list_free_wrapper(glWarningTonerList);
		}
	}

	calibrationFailWarningFunc(wnd, ppSubMessage);
	regAdjustFailWarningFunc(wnd, ppSubMessage);
	regSendorWarningFunc(wnd, ppSubMessage);
	fdTrayWarningFunc(wnd, ppSubMessage);
	noPaperWarningFunc(wnd, ppSubMessage);
	overPaperWarningFunc(wnd, ppSubMessage);
	beltCleaningWarningFunc(wnd, ppSubMessage);
	fuserLifeReachedWarningFunc(wnd, ppSubMessage);
	cartridgeAccessingWarningFunc(wnd, ppSubMessage);
}

static void drummemoryTagWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage, GList** const glWarningDrumList)
{
	commCrgWarningFunc(wnd, ppSubMessage, glWarningDrumList, KEY_TONER_MEMORY_WARNING, KEY_DRUM_MEMORY_WARNING, TRUE);
}

static void drumLifeReachedWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage, GList** const glWarningDrumList)
{
	commCrgWarningFunc(wnd, ppSubMessage, glWarningDrumList, KEY_TONEROUT1_WARNING, KEY_DRUMOUT1_WARNING, TRUE);
}

static void drumExceedUseFunc(const UIStatusWnd* const wnd, char** const ppSubMessage, GList** const glWarningDrumList)
{
	commCrgWarningFunc(wnd, ppSubMessage, glWarningDrumList, KEY_TONEROUT3_WARNING, KEY_DRUMOUT3_WARNING, TRUE);
}

static void drumLifeReached1WarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage, GList** const glWarningDrumList)
{
	commCrgWarningFunc(wnd, ppSubMessage, glWarningDrumList, KEY_TONEROUT2_WARNING, KEY_DRUMOUT2_WARNING, TRUE);
}

static void drumLifeNoticeWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage, GList** const glWarningDrumList)
{
	commCrgWarningFunc(wnd, ppSubMessage, glWarningDrumList, KEY_TONER_LIFETIME_WARNING, KEY_DRUM_LIFETIME_WARNING, TRUE);
}
static void memoryTagWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage)
{
	commWarningFuncWithKeyValue(wnd, ppSubMessage, KEY_TONER_MEMORY_WARNING, TONER_K_STR, KEY_TONER_MEMORY_WARNING);
}

static void tonerLifeReachedWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage, GList** const glWarningTonerList)
{
	commCrgWarningFunc(wnd, ppSubMessage, glWarningTonerList, KEY_TONEROUT1_WARNING, KEY_TONEROUT1_WARNING, FALSE);
}

static void tonerExceedUseFunc(const UIStatusWnd* const wnd, char** const ppSubMessage, GList** const glWarningTonerList)
{
	commCrgWarningFunc(wnd, ppSubMessage, glWarningTonerList, KEY_TONEROUT3_WARNING, KEY_TONEROUT3_WARNING, FALSE);
}

static void tonerLifeReached1WarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage, GList** const glWarningTonerList)
{
	commCrgWarningFunc(wnd, ppSubMessage, glWarningTonerList, KEY_TONEROUT2_WARNING, KEY_TONEROUT2_WARNING, FALSE);
}

static void tonerLifeNoticeWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage, GList** const glWarningTonerList)
{
	commCrgWarningFunc(wnd, ppSubMessage, glWarningTonerList, KEY_TONER_LIFETIME_WARNING, KEY_TONER_LIFETIME_WARNING, FALSE);
}

static void calibrationFailWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage)
{
	commOtherWarningFunc(wnd, ppSubMessage, OW_CALIB_FAIL_STR);
}

static void regAdjustFailWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage)
{
	commOtherWarningFunc(wnd, ppSubMessage, OW_REGI_FAIL_STR);
}

static void regSendorWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage)
{
	commOtherWarningFunc(wnd, ppSubMessage, OW_CIS_SENSOR_NG_STR);
}

static void fdTrayWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage)
{
	commPaperWarningFunc(wnd, ppSubMessage, FDTRAY_STR);
}

static void noPaperWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage)
{
	GList *glSearchedValue = NULL;
	Dict *pWarnPaperSourceInfoDict = NULL;
	char *pSubstitutionInfo = NULL;
	char *pOrgMessage = NULL;
	char **ppSeparateStr = NULL;
	GString *gsConnectMessage = NULL;
	char *pSourceInfo = NULL;
	char **ppSourceStr = NULL;

	if( (wnd == NULL) || (ppSubMessage == NULL) )
	{
		return;
	}

	glSearchedValue = GetDictValueGList_forKey(wnd->pStatusDict, KEY_PAPER_WARNING);
	pOrgMessage = getMessageFromPPDKey(wnd, KEY_PAPER_WARNING, NULL);
	if( (glSearchedValue == NULL) || (pOrgMessage == NULL) )
	{
		UI_DEBUG("%s glSearchedValue or pOrgMessage is NULL, from Line[%u] \n", __func__, __LINE__);
		if(pOrgMessage != NULL)
		{
			mem_free(pOrgMessage);
		}
		return;
	}

	pSubstitutionInfo = CngplpGetValue_AddPrefix(wnd, PAPERWARNINGINFO_KEY);
	if(pSubstitutionInfo == NULL)
	{
		const gboolean isJP = isLocaleJapanese(wnd);
		if(isJP == TRUE)
		{
			pSubstitutionInfo = mem_strudup(PAPERWARNINFO_JP_DEFAULT, __FILE__, __LINE__);
		}
		else
		{
			pSubstitutionInfo = mem_strudup(PAPERWARNINFO_EN_DEFAULT, __FILE__, __LINE__);
		}
		UI_DEBUG("%s Not Get PPD, Set DefaultValue[%s], isJP[%d], from Line[%u] \n", __func__, pSubstitutionInfo, isJP, __LINE__);
	}

	if(pSubstitutionInfo != NULL)
	{
		ppSeparateStr = SeparateString(pSubstitutionInfo, CHARACTER_COMMA);
		mem_free(pSubstitutionInfo);
	}

	pSourceInfo = CngplpGetValue_AddPrefix(wnd, PAPERWARNINGSOURCEINFO_KEY);
	if(pSourceInfo == NULL)
	{
		pSourceInfo = mem_strudup(PAPERWARNSOURCEINFO_DEFAULT, __FILE__, __LINE__);
		UI_DEBUG("%s Not Get PPD, Set DefaultValue[%s], from Line[%u] \n", __func__, pSourceInfo, __LINE__);
	}

	if(pSourceInfo != NULL)
	{
		ppSourceStr = SeparateString(pSourceInfo, CHARACTER_COMMA);
		mem_free(pSourceInfo);
	}

	gsConnectMessage = g_string_new_wrapper(NULL, __FILE__, __LINE__);
	if(gsConnectMessage == NULL)
	{
		return;
	}

	if( (ppSeparateStr != NULL) && (ppSourceStr != NULL))
	{
		GList *glCompositionStr = NULL;
		char *pTmpMessage = NULL;
		char *pWarnMessage = NULL;
		char *pDictPaparInfoVal = NULL;
		char *pDictPaparInfoStr = NULL;
		int idx = 0;
		int nSource = 0;
		char *pFoundSrc = NULL;

		while(glSearchedValue != NULL)
		{
			pFoundSrc = NULL;
			for(nSource = 0; ppSourceStr[nSource] != NULL; nSource++)
			{
				if( 0 == strcmp( (char*)glSearchedValue->data, ppSourceStr[nSource] ) )
				{
					pFoundSrc = ppSourceStr[nSource];
					break;
				}
			}
			if( NULL == pFoundSrc )
			{
				glSearchedValue = g_list_next(glSearchedValue);
				continue;
			}

			pTmpMessage = mem_strudup(pOrgMessage, __FILE__, __LINE__);
			if(pTmpMessage == NULL)
			{
				UI_DEBUG("%s pTmpMessage is NULL, from Line[%u] \n", __func__, __LINE__);
				break;
			}

			pWarnPaperSourceInfoDict = GetPaperInfoDict(wnd->pStatusDict, (char*)glSearchedValue->data);
			if(pWarnPaperSourceInfoDict != NULL)
			{
				for(idx = 0; ppSeparateStr[idx] != NULL; idx++)
				{
					pDictPaparInfoVal = GetDictValueString_forKey(pWarnPaperSourceInfoDict, ppSeparateStr[idx]);
					if(pDictPaparInfoVal != NULL)
					{
						int compKeyPaperSize = strcmp(ppSeparateStr[idx], KEY_PAPER_SIZE);
						if( compKeyPaperSize == 0)
						{
							int compUserSettingPaper = strcmp(pDictPaparInfoVal, PAPER_SIZE_USER_PAPER);
							int compFreePaper = strcmp(pDictPaparInfoVal, PAPER_SIZE_FREE);
							if(compUserSettingPaper == 0)
							{
								pDictPaparInfoVal = PAPARWARN_PAPERSIZE_USERSETTINGPAPER;
							}
							else if(compFreePaper == 0)
							{
								pDictPaparInfoVal = PAPARWARN_PAPERSIZE_FREE;
							}
							else
							{
								;
							}
						}
					}

					if( pDictPaparInfoVal != NULL )
					{
						pDictPaparInfoStr = getMessageFromPPDKey(wnd, pDictPaparInfoVal, NULL);
					}

					if(pDictPaparInfoStr != NULL)
					{
						glCompositionStr = g_list_append_wrapper(glCompositionStr, (gpointer)pDictPaparInfoStr, __FILE__, __LINE__);
						if(glCompositionStr == NULL)
						{
							UI_DEBUG("%s Appned Error glCompositionStr, Free pDictPaparInfoStr[%s], from Line[%u] \n", __func__, pDictPaparInfoStr, __LINE__);
							mem_free(pDictPaparInfoStr);
							break;
						}
					}

					pDictPaparInfoStr = NULL;
				}
			}

			if(glCompositionStr == NULL)
			{
				CatStrWithPunctuation(gsConnectMessage, pTmpMessage, STRING_NEWLINE);
			}
			else
			{
				pWarnMessage = CompositionString(glCompositionStr, pTmpMessage, COMPOSITONKEY_STRING);
				if(pWarnMessage != NULL)
				{
					CatStrWithPunctuation(gsConnectMessage, pWarnMessage, STRING_NEWLINE);
					mem_free(pWarnMessage);
				}
				else
				{
					CatStrWithPunctuation(gsConnectMessage, pTmpMessage, STRING_NEWLINE);
				}

				g_list_foreach(glCompositionStr, (GFunc)mem_free, NULL);
				g_list_free_wrapper(glCompositionStr);
				glCompositionStr = NULL;
			}

			mem_free(pTmpMessage);
			glSearchedValue = g_list_next(glSearchedValue);
		}

		mem_free_list(ppSeparateStr);
		mem_free_list(ppSourceStr);
	}

	if(strcmp(gsConnectMessage->str, BLANK_MESSAGE) != 0)
	{
		connectWarningMessage(ppSubMessage, gsConnectMessage->str);
		AddNewLine(ppSubMessage);
	}
	g_string_free_wrapper(gsConnectMessage, TRUE);
	mem_free(pOrgMessage);
}

static void overPaperWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage)
{
	GList *glSearchedValue = NULL;
	char *pSubstitutionInfo = NULL;
	char *pOrgMessage = NULL;
	char **ppSeparateStr = NULL;
	GString *gsConnectMessage = NULL;

	if( (wnd == NULL) || (ppSubMessage == NULL) )
	{
		return;
	}

	glSearchedValue = GetDictValueGList_forKey(wnd->pStatusDict, KEY_PAPER_WARNING);
	pOrgMessage = getMessageFromPPDKey(wnd, PAPEROVERCASSETTE_KEY, NULL);
	if( (glSearchedValue == NULL) || (pOrgMessage == NULL) )
	{
		UI_DEBUG("%s glSearchedValue or pOrgMessage is NULL, from Line[%u] \n", __func__, __LINE__);
		if(pOrgMessage != NULL)
		{
			mem_free(pOrgMessage);
		}
		return;
	}

	pSubstitutionInfo = CngplpGetValue_AddPrefix(wnd, PAPEROVERCASSETTEINFO_KEY);
	if(pSubstitutionInfo == NULL)
	{
		pSubstitutionInfo = mem_strudup(PAPEROVERWARNINFO_DEFAULT, __FILE__, __LINE__);
		UI_DEBUG("%s Not Get PPD, Set DefaultValue[%s], from Line[%u] \n", __func__, pSubstitutionInfo, __LINE__);
	}

	if(pSubstitutionInfo != NULL)
	{
		ppSeparateStr = SeparateString(pSubstitutionInfo, CHARACTER_COMMA);
		mem_free(pSubstitutionInfo);
	}

	gsConnectMessage = g_string_new_wrapper(NULL, __FILE__, __LINE__);
	if(gsConnectMessage == NULL)
	{
		return;
	}

	if(ppSeparateStr != NULL)
	{
		GList *glCompositionStr = NULL;
		char *pTmpMessage = NULL;
		char *pWarnMessage = NULL;
		char *pDictPaparInfoVal = NULL;
		char *pDictPaparInfoStr = NULL;
		int idx = 0;

		while(glSearchedValue != NULL)
		{
			pTmpMessage = mem_strudup(pOrgMessage, __FILE__, __LINE__);
			if(pTmpMessage == NULL)
			{
				UI_DEBUG("%s pTmpMessage is NULL, from Line[%u] \n", __func__, __LINE__);
				break;
			}

				for(idx = 0; ppSeparateStr[idx] != NULL; idx++)
				{
					int compKey = strcmp(ppSeparateStr[idx], (char*)glSearchedValue->data);
					if( compKey == 0)
					{
						pDictPaparInfoVal = ppSeparateStr[idx];
					}
					else
					{
						pDictPaparInfoVal = NULL;
					}

					if(pDictPaparInfoVal != NULL)
					{
						pDictPaparInfoStr = msgXmlGetString(wnd, pDictPaparInfoVal);
					}

					if(pDictPaparInfoStr != NULL)
					{
						glCompositionStr = g_list_append_wrapper(glCompositionStr, (gpointer)pDictPaparInfoStr, __FILE__, __LINE__);
						if(glCompositionStr == NULL)
						{
							UI_DEBUG("%s Appned Error glCompositionStr, Free pDictPaparInfoStr[%s], from Line[%u] \n", __func__, pDictPaparInfoStr, __LINE__);
							mem_free(pDictPaparInfoStr);
							break;
						}
					}

					pDictPaparInfoStr = NULL;
				}

			if(glCompositionStr != NULL)
			{
				pWarnMessage = CompositionString(glCompositionStr, pTmpMessage, COMPOSITONKEY_STRING);
				if(pWarnMessage != NULL)
				{
					CatStrWithPunctuation(gsConnectMessage, pWarnMessage, STRING_NEWLINE);
					mem_free(pWarnMessage);
				}

				g_list_foreach(glCompositionStr, (GFunc)mem_free, NULL);
				g_list_free_wrapper(glCompositionStr);
				glCompositionStr = NULL;
			}

			mem_free(pTmpMessage);
			glSearchedValue = g_list_next(glSearchedValue);
		}

		mem_free_list(ppSeparateStr);
	}

	if(strcmp(gsConnectMessage->str, BLANK_MESSAGE) != 0)
	{
		connectWarningMessage(ppSubMessage, gsConnectMessage->str);
		AddNewLine(ppSubMessage);
	}
	g_string_free_wrapper(gsConnectMessage, TRUE);
	mem_free(pOrgMessage);
}

static void beltCleaningWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage)
{
	commOtherWarningFunc(wnd, ppSubMessage, OW_BELT_CLEANING_STR);
}

static void fuserLifeReachedWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage)
{
	commOtherWarningFunc(wnd, ppSubMessage, OW_FUSER_LIFE_WARN_STR);
}

static void cartridgeAccessingWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage)
{
	commOtherWarningFunc(wnd, ppSubMessage, OW_CRG_ACCESS_STR);
}

static void commCrgWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage, GList** const warningTonerGlist, const char* const dictKey, const char* const warningKey, gboolean isDrum)
{
	GList *glSearchedValue = NULL;
	GList *glNotDispToner = NULL;
	char *pWarnMessage = NULL;
	char *pDispMsgStr = NULL;

	if( (wnd == NULL) || (ppSubMessage == NULL) || (warningTonerGlist == NULL) || (dictKey == NULL) )
	{
		return;
	}

	glSearchedValue = GetDictValueGList_forKey(wnd->pStatusDict, dictKey);
	if(glSearchedValue == NULL)
	{
		UI_DEBUG("%s dictKey[%s] Value is NULL, from Line[%u] \n", __func__, dictKey, __LINE__);
		return;
	}

	glNotDispToner = CreateTonerGlist_ExceptBaseGlist(*warningTonerGlist, glSearchedValue);
	if(glNotDispToner != NULL)
	{
		pDispMsgStr = catTonerStrCreateFromGlist(wnd, glNotDispToner, isDrum);
	}

	if(pDispMsgStr != NULL)
	{
		UI_DEBUG("%s Display Toner[%s], from Line[%u] \n", __func__, pDispMsgStr, __LINE__);
		GList *glCompositionStr = NULL;
		glCompositionStr = g_list_append_wrapper(glCompositionStr, (gpointer)pDispMsgStr, __FILE__, __LINE__);
		if(glCompositionStr != NULL)
		{
			char* const pTmpWarnMessage = getMessageFromPPDKey(wnd, warningKey, NULL);
			if(pTmpWarnMessage != NULL)
			{
				UI_DEBUG("%s Base WarningMessage[%s], from Line[%u] \n", __func__, pTmpWarnMessage, __LINE__);
				pWarnMessage = CompositionString(glCompositionStr, pTmpWarnMessage, COMPOSITONKEY_STRING);
				if(pWarnMessage == NULL)
				{
					pWarnMessage = mem_strudup(pTmpWarnMessage, __FILE__, __LINE__);
				}
				mem_free(pTmpWarnMessage);
			}
			g_list_free_wrapper(glCompositionStr);
		}
		mem_free(pDispMsgStr);
	}

	if(pWarnMessage != NULL)
	{
		connectWarningMessage(ppSubMessage, pWarnMessage);
		mem_free(pWarnMessage);

		*warningTonerGlist = g_list_concat_wrapper(*warningTonerGlist, glNotDispToner, __FILE__, __LINE__);
	}
	else
	{
		if( glNotDispToner != NULL )
		{
			g_list_free_wrapper(glNotDispToner);
			UI_DEBUG("%s pWarnMessage is NULL, from Line[%u] n", __func__, __LINE__);
		}
	}
}

static void commWarningFuncWithKeyValue(const UIStatusWnd* const wnd, char** const ppSubMessage, const char* const warningKey, const char* const warningValue, const char* const ppdKey)
{
	GList *glSearchedValue = NULL;
	const char *messagePpdKey = warningValue;

	if( (wnd == NULL) || (ppSubMessage == NULL) || (warningKey == NULL) || (warningValue == NULL) )
	{
		return;
	}

	glSearchedValue = GetDictValueGList_forKey(wnd->pStatusDict, warningKey);
	if(glSearchedValue == NULL)
	{
		UI_DEBUG("%s [%s] Value is NULL, from Line[%u] \n", __func__, warningKey, __LINE__);
		return;
	}

	if( g_list_find_custom(glSearchedValue, warningValue, (GCompareFunc)strcmp) != NULL )
	{
		if(ppdKey != NULL)
		{
			const unsigned int nPpdKeyLen = strlen(ppdKey);
			if(nPpdKeyLen > 0u)
			{
				messagePpdKey = ppdKey;
			}
		}

		char* const pWarnMessage = getMessageFromPPDKey(wnd, messagePpdKey, NULL);
		if(pWarnMessage != NULL)
		{
			connectWarningMessage(ppSubMessage, pWarnMessage);
			mem_free(pWarnMessage);
		}
	}
}

static void commOtherWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage, const char* const warningValue)
{
	commWarningFuncWithKeyValue(wnd, ppSubMessage, KEY_OTHER_WAR, warningValue, NULL);
}


static void commPaperWarningFunc(const UIStatusWnd* const wnd, char** const ppSubMessage, const char* const warningValue)
{
	commWarningFuncWithKeyValue(wnd, ppSubMessage, KEY_PAPER_WARNING, warningValue, NULL);
}

