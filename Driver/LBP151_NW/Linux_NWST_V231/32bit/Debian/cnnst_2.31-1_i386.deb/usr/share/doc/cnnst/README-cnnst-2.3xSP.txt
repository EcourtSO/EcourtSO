﻿=================================================================================
Canon MF/LBP Network Setup Tool Versión 2.31

LEA ESTE DOCUMENTO CON ATENCIÓN
=================================================================================

PRECAUCIONES

Tenga en cuenta las siguientes restricciones cuando use este software.

1. El software puede detectar hasta 10 puntos de acceso de LAN inalámbrica en la búsqueda de puntos de acceso de LAN inalámbrica. 

2. El software no puede detectar puntos de acceso de LAN inalámbrica en la búsqueda de puntos de acceso de LAN inalámbrica cuando los puntos de acceso de LAN inalámbrica usan una función en modo sigiloso. 

3. No es posible configurar ajustes con este software durante la actualización del firmware de la impresora, inmediatamente después de encender o apagar el interruptor de alimentación, ni cuando la impresora está imprimiendo. 

4. En función del entorno de funcionamiento, no es posible mostrar las "Sugerencias útiles" directamente desde este software.
En tal caso, siga el mensaje en pantalla para mostrar las "Sugerencias útiles" desde el navegador web que esté usando.

=================================================================================
                                                        Copyright CANON INC. 2014

