/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "uimain.h"
#include "widgets.h"
#include "interface.h"
#include "autoshutdowndlg.h"
#include "callbacks.h"
#include "support.h"
#include "id_defines.h"
#include "commandcontroller.h"
#include "value_defines.h"


#define AUTO_SHUTDOWN_TIME_CNT 32
#define AUTO_SHUTDOWN_CTRL_TYPE_NUM 3
#define AUTO_SHUTDOWN_TIME_TBL_NUM 9
#define AUTO_SHUTDOWN_CTRL_TBL_NUM 5

static int InitAutoShutdownDlgWidgets( UIStatusWnd * const wnd );
static unsigned int SetItemValue_AutoShutdownDlgOK( const UIStatusWnd * const wnd );

CtrlTbl* PPDCtrlTbl[CTRL_LIST_MAXNUM];

static char * AutoShutdownTimeTbl[AUTO_SHUTDOWN_TIME_TBL_NUM] =
{
	"1", "2", "3", "4", "5", "6", "7", "8", NULL
};

static CtrlTbl ctrlTbl[AUTO_SHUTDOWN_CTRL_TBL_NUM] =
{
	{ ID_AUTOSHUTDOWN_DIALOG1, LABEL_TYPE_TITLE, NULL, N_("Auto Shutdown Settings"), NULL, 0 },
	{ ID_CTRLAUTOSHUTDOWNENABLE, LABEL_TYPE_BUTTON, "AutoShutdownDlg_Use_checkbutton", N_("Auto Shutdown after Fixed Period"), "AutoShutdownDlg_Use_checkbutton", ID1062 },
	{ ID_CTRLAUTOSHUTDOWNTIME, LABEL_TYPE_TEXT, "AutoShutdown_Time_Label", N_("Auto Shutdown After:"), "AutoShutdown_combo_area", ID772 },
	{ ID_CTRLAUTOSHUTDOWNTIME_HR, LABEL_TYPE_TEXT, "AutoShutdown_Time_Hr_Label", N_("hr."), NULL, 0 },
	{ -1, -1, NULL, NULL, NULL, -1 }
};

UIAutoShutdownDlg* CreateAutoShutdownDlg(UIDialog * const parent)
{
	UIAutoShutdownDlg *pDialog;

	pDialog = (UIAutoShutdownDlg *)CreateDialog(sizeof(UIAutoShutdownDlg), parent);

	if( pDialog != NULL )
	{
		UI_DIALOG(pDialog)->window = create_AutoShutdown_dialog();
	}
	return pDialog;
}

void ShowAutoShutdownDlg( UIStatusWnd * const wnd )
{
	int nRet = 0;

	if( wnd == NULL )
	{
		return;
	}
	if( wnd->autoshutdown_dlg == NULL )
	{
		wnd->autoshutdown_dlg = CreateAutoShutdownDlg( UI_DIALOG( wnd ) );
	}

	SigDisable();
	nRet = InitAutoShutdownDlgWidgets( wnd );
	SigEnable();

	if( nRet == 0 )
	{
		ShowDialog( (UIDialog *)wnd->autoshutdown_dlg, NULL );
	}
	else
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_GET );
		if( wnd->autoshutdown_dlg != NULL )
		{
			if( wnd->autoshutdown_dlg->pDialogDict != NULL )
			{
				DeleteDict( wnd->autoshutdown_dlg->pDialogDict );
				wnd->autoshutdown_dlg->pDialogDict = NULL;
			}
			mem_free( wnd->autoshutdown_dlg );
			wnd->autoshutdown_dlg = NULL;
		}
	}
}

static unsigned int SetItemValue_AutoShutdownDlgOK( const UIStatusWnd * const wnd )
{
	int i = 0;
	int nValue = 0;
	char *pValue = NULL;
	unsigned int unRet = 0;
	GtkWidget *pWindow = NULL;

	if( wnd == NULL )
	{
		return DICT_SET_RETURN_ERROR;
	}
	pWindow = wnd->autoshutdown_dlg->dialog.window;

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		switch( PPDCtrlTbl[i]->dbid )
		{
		case ID1062:
			nValue = GetToggleButtonActive( pWindow, "AutoShutdownDlg_Use_checkbutton", FALSE );
			unRet |= SetItemValuetype_int( wnd->autoshutdown_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, nValue );
			break;
		case ID772:
			pValue = GetCurrComboBoxText( pWindow, "AutoShutdownDlg_Time_combo" );
			if( pValue == NULL )
			{
				unRet |= DICT_SET_RETURN_ERROR;
			}
			else
			{
				nValue = atoi(pValue);
				mem_free(pValue);
				unRet |= SetItemValuetype_int( wnd->autoshutdown_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, nValue );
			}
			break;
		default:
			break;
		}
		if( (unRet & DICT_SET_RETURN_ERROR) == DICT_SET_RETURN_ERROR )
		{
			break;
		}
	}
	return unRet;
}

void AutoShutdownDlgOK( UIStatusWnd * const wnd )
{
	int nRet = 0;
	unsigned int unRet = 0;

	if( wnd == NULL )
	{
		return;
	}

	nRet = CreateDict_SetData( wnd->autoshutdown_dlg->pDialogDict );

	if( nRet == 0 )
	{
		unRet = SetItemValue_AutoShutdownDlgOK( wnd );
		if( (unRet & DICT_SET_RETURN_ERROR) == DICT_SET_RETURN_ERROR )
		{
			nRet = -1;
		}
	}

	if( ( nRet == 0 ) && ( unRet == DICT_SET_RETURN_CHANGE ) )
	{
		nRet = CommunicatePrinterData( wnd, (UIDialog *)wnd->autoshutdown_dlg, wnd->autoshutdown_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	}

	HideDialog( (UIDialog *)wnd->autoshutdown_dlg );

	if( nRet != 0 )
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_SET );
	}

	return;
}

void UpdateAutoShutdownDlgWidgets( const UIStatusWnd * const wnd, const int use_autoshutdown )
{
	if( wnd == NULL )
	{
		return;
	}
	GtkWidget * const pWindow = UI_DIALOG(wnd->autoshutdown_dlg)->window;
	if( pWindow != NULL )
	{
		SetWidgetSensitive( pWindow, "AutoShutdown_combo_area", use_autoshutdown );
	}
}

static int InitAutoShutdownDlgWidgets( UIStatusWnd * const wnd )
{
	GtkWidget *pWindow = NULL;
	GList *pGlist = NULL;
	char strValue[AUTO_SHUTDOWN_TIME_CNT];
	int nValue = 0;
	int i = 0;
	int nRet = 0;
	const char* const ctrl_type[AUTO_SHUTDOWN_CTRL_TYPE_NUM] = { "CNSUIAutoShutDlg", "CNSUICtrlAutoShutdown", NULL };

	if( wnd == NULL )
	{
		return -1;
	}

	if( wnd->autoshutdown_dlg == NULL )
	{
		return -1;
	}
	else
	{
		pWindow = wnd->autoshutdown_dlg->dialog.window;
	}
	memset( strValue, 0, sizeof(strValue) );

	CreatePPDCtrlTbl( wnd, ctrl_type, ctrlTbl, PPDCtrlTbl );

	SetLabel_HideWidget( pWindow, PPDCtrlTbl, ctrlTbl );

	pGlist = CreateGlist_DbId( PPDCtrlTbl );

	if( wnd->autoshutdown_dlg->pDialogDict != NULL )
	{
		UI_DEBUG("pDialogDict no mem_free, from Func[%s] Line[%u] \n", __func__, __LINE__);
		DeleteDict( wnd->autoshutdown_dlg->pDialogDict );
	}
	wnd->autoshutdown_dlg->pDialogDict = CretateDict_GetData( pGlist );
	g_list_free_wrapper( pGlist );

	if( wnd->autoshutdown_dlg->pDialogDict == NULL )
	{
		return -1;
	}

	nRet = CommunicatePrinterData( wnd, NULL, wnd->autoshutdown_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	if( nRet != 0 )
	{
		return -1;
	}

	if( wnd->autoshutdown_dlg->pAutoShutdownTimeList == NULL )
	{
		char * const pTmp = cngplpGetValue_Wrapper( wnd->pModData, "CNSUIAutoShutdownTimeList" );
		if( pTmp != NULL )
		{
			wnd->autoshutdown_dlg->pAutoShutdownTimeList = SeparateString( pTmp, CHARACTER_COMMA );
			mem_free( pTmp );
		}
	}

	if( wnd->autoshutdown_dlg->pAutoShutdownTimeList != NULL )
	{
		pGlist = CreateGlist_ComboList( wnd->autoshutdown_dlg->pAutoShutdownTimeList );
	}
	else
	{
		pGlist = CreateGlist_ComboList( AutoShutdownTimeTbl );
	}

	if(pGlist != NULL)
	{
		SetGListToComboBox( pWindow, "AutoShutdownDlg_Time_combo", pGlist );
		g_list_free_wrapper( pGlist );
	}

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		switch( PPDCtrlTbl[i]->dbid )
		{
		case ID1062:
			GetItemValueType_int( wnd->autoshutdown_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, &nValue );
			SetActiveCheckButton( pWindow, "AutoShutdownDlg_Use_checkbutton", nValue, FALSE );
			SetWidgetSensitive( pWindow, "AutoShutdown_combo_area", nValue );
			break;
		case ID772:
			GetItemValueType_int( wnd->autoshutdown_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, &nValue );
			if( nValue < 0 )
			{
				nRet = -1;
			}
			else
			{
				snprintf( strValue, (sizeof(strValue)-1), "%d", nValue );
				SetCurrComboBoxText(pWindow, "AutoShutdownDlg_Time_combo", strValue);
			}
			break;
		default:
			break;
		}
		if( nRet != 0 )
		{
			break;
		}
	}
	return nRet;
}

void DisposeAutoShutdownDlg( UIStatusWnd* const wnd )
{
	UIAutoShutdownDlg* ui_autoshutdown_dlg = NULL;

	if(wnd == NULL)
	{
		return;
	}

	ui_autoshutdown_dlg = wnd->autoshutdown_dlg;
	if( ui_autoshutdown_dlg != NULL)
	{
		if( ui_autoshutdown_dlg->pAutoShutdownTimeList != NULL )
		{
			mem_free_list( ui_autoshutdown_dlg->pAutoShutdownTimeList );
			ui_autoshutdown_dlg->pAutoShutdownTimeList = NULL;
		}
		if( ui_autoshutdown_dlg->pDialogDict != NULL )
		{
			DeleteDict( ui_autoshutdown_dlg->pDialogDict );
			ui_autoshutdown_dlg->pDialogDict = NULL;
		}
		DisposeDialog( (UIDialog *)ui_autoshutdown_dlg );
		wnd->autoshutdown_dlg = NULL;
	}
}

