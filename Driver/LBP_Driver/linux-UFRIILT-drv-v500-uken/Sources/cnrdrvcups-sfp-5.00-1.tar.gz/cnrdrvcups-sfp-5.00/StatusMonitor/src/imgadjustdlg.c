/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "uimain.h"
#include "widgets.h"
#include "interface.h"
#include "imgadjustdlg.h"

#include "callbacks.h"
#include "support.h"
#include "id_defines.h"
#include "commandcontroller.h"
#include "value_defines.h"

#define IMG_ADJUST_CTRL_TYPE_NUM 3
#define IMG_ADJUST_CALIB_STARTUP_TBL_NUM 4
#define IMG_ADJUST_CTRL_TBL_NUM 6

static int InitImgAdjustDlgWidgets( UIStatusWnd * const wnd );
static unsigned int SetItemValue_ImgAdjustDlgOK( const UIStatusWnd * const wnd );

struct calibstartup_conv_t
{
	gchar *dispstr;
	int nIDCalibState;
	int nIDColorCorrectState;
};

static struct calibstartup_conv_t CalibStartupTbl[IMG_ADJUST_CALIB_STARTUP_TBL_NUM] =
{
	{ N_("Execute Later"), 0, 0 },
	{ N_("Execute Immediately (Level 1)"), 0, 1 },
	{ N_("Execute Immediately (Level 2)"), 1, 1 },
	{ NULL, -1, -1 }
};

CtrlTbl* PPDCtrlTbl[CTRL_LIST_MAXNUM];

static CtrlTbl ctrlTbl[IMG_ADJUST_CTRL_TBL_NUM] =
{
	{ ID_IMGADJUST_DIALOG1, LABEL_TYPE_TITLE, NULL, N_("Image Quality Adjustment Settings"), NULL, 0 },
	{ ID_CTRLCALIBENABLE, LABEL_TYPE_BUTTON, "ImgAdjustDlg_CalibEnable_checkbutton", N_("Use Periodical Calibration Timer"), "ImgAdjustDlg_Calib_vbox", ID722 },
	{ ID_CTRLCALIBTIME, LABEL_TYPE_TEXT, "ImgAdjustDlg_Time_Label", N_("Time:"), "ImgAdjustDlg_Calib_vbox", ID732 },
	{ ID_CTRLCALIBTIMECOLON, LABEL_TYPE_TEXT, "ImgAdjustDlg_Time_Colon_Label", N_(":"), "ImgAdjustDlg_Calib_vbox", ID742 },
	{ ID_CTRLCALIBSTARTUP, LABEL_TYPE_TEXT, "ImgAdjustDlg_CalibStartup_Label", N_("Image Quality Adjustment at Startup:"), "ImgAdjustDlg_CalibStartup_hvox", 0 },
	{ -1, -1, NULL, NULL, NULL, -1 }
};

UIImgAdjustDlg* CreateImgAdjustDlg(UIDialog * const parent)
{
	UIImgAdjustDlg *pDialog;

	pDialog = (UIImgAdjustDlg *)CreateDialog(sizeof(UIImgAdjustDlg), parent);

	if(pDialog != NULL)
	{
		UI_DIALOG(pDialog)->window = create_ImgAdjust_dialog();
	}

	return pDialog;
}

void ShowImgAdjustDlg( UIStatusWnd * const wnd )
{
	int nRet = 0;

	if( wnd == NULL )
	{
		return;
	}
	if( wnd->imgadjust_dlg == NULL )
	{
		wnd->imgadjust_dlg = CreateImgAdjustDlg( UI_DIALOG( wnd ) );
	}

	SigDisable();
	nRet = InitImgAdjustDlgWidgets( wnd );
	SigEnable();


	if( nRet == 0 )
	{
		ShowDialog( (UIDialog *)wnd->imgadjust_dlg, NULL );
	}
	else
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_GET );
		if( wnd->imgadjust_dlg != NULL)
		{
			if( wnd->imgadjust_dlg->pDialogDict != NULL )
			{
				DeleteDict( wnd->imgadjust_dlg->pDialogDict );
				wnd->imgadjust_dlg->pDialogDict = NULL;
			}
			if( wnd->imgadjust_dlg->glist_appendId != NULL )
			{
				g_list_foreach(wnd->imgadjust_dlg->glist_appendId, (GFunc)mem_free, NULL);
				g_list_free_wrapper( wnd->imgadjust_dlg->glist_appendId );
				wnd->imgadjust_dlg->glist_appendId = NULL;
			}

			if( wnd->imgadjust_dlg->glist != NULL )
			{
				g_list_free_wrapper( wnd->imgadjust_dlg->glist );
				wnd->imgadjust_dlg->glist = NULL;
			}
			mem_free( wnd->imgadjust_dlg );
			wnd->imgadjust_dlg = NULL;
		}
	}
}

static unsigned int SetItemValue_ImgAdjustDlgOK( const UIStatusWnd * const wnd )
{
	unsigned int i = 0;
	int j = 0;
	int nValue = 0;
	unsigned int unRet = 0;
	GtkWidget *pWindow = NULL;

	int *pnId = NULL;
	gchar *pValue = NULL;

	gboolean bSet = TRUE;
	gboolean bUnknownId = FALSE;

	if( wnd == NULL )
	{
		return DICT_SET_RETURN_ERROR;
	}

	pWindow = wnd->imgadjust_dlg->dialog.window;

	for( i = 0; i < g_list_length(wnd->imgadjust_dlg->glist); i++ )
	{

		pnId = (int*)g_list_nth_data(wnd->imgadjust_dlg->glist, i);

		bSet = TRUE;
		bUnknownId = FALSE;

		if(pnId == NULL)
		{
			continue;
		}

		switch( *pnId )
		{
		case ID722:
			nValue = GetToggleButtonActive( pWindow, "ImgAdjustDlg_CalibEnable_checkbutton", FALSE );
			break;
		case ID732:
			nValue = GetSpinButtonValue( pWindow, "ImgAdjustDlg_TimeHour_spinbutton", 0);
			break;
		case ID742:
			nValue = GetSpinButtonValue( pWindow, "ImgAdjustDlg_TimeMin_spinbutton", 0);
			break;
		case ID122:
			pValue = GetCurrComboBoxText( pWindow, "ImgAdjustDlg_CalibStartup_combo" );
			bSet = FALSE;

			if( pValue != NULL )
			{
				for(j = 0; CalibStartupTbl[j].dispstr != NULL; j++)
				{
					if(strcmp(pValue, _(CalibStartupTbl[j].dispstr)) == 0)
					{
						bSet = TRUE;
						nValue = CalibStartupTbl[j].nIDCalibState;
						break;
					}
				}

				mem_free(pValue);
			}
			break;
		case ID362:
			pValue = GetCurrComboBoxText( pWindow, "ImgAdjustDlg_CalibStartup_combo" );
			bSet = FALSE;

			if( pValue != NULL )
			{
				for(j = 0; CalibStartupTbl[j].dispstr != NULL; j++)
				{
					if(strcmp(pValue, _(CalibStartupTbl[j].dispstr)) == 0)
					{
						bSet = TRUE;
						nValue = CalibStartupTbl[j].nIDColorCorrectState;
						break;
					}
				}

				mem_free(pValue);
			}
			break;
		default:
			UI_DEBUG("SetItemValue_ImgAdjustDlgOK Unknown ID[%d]\n", *pnId);
			bUnknownId = TRUE;
			break;
		}

		if( (bSet == TRUE) && (bUnknownId == FALSE) )
		{
			unRet |= SetItemValuetype_int( wnd->imgadjust_dlg->pDialogDict, *pnId, nValue );
			UI_DEBUG("SetItemValue_ImgAdjustDlgOK ID[%d] unRet[%d]\n", *pnId, unRet);
		}
		else
		{
			unRet = DICT_SET_RETURN_ERROR;
		}

		if( (unRet & DICT_SET_RETURN_ERROR) == DICT_SET_RETURN_ERROR )
		{
			break;
		}
	}
	return unRet;
}

void ImgAdjustDlgOK( UIStatusWnd * const wnd )
{
	int nRet = 0;
	unsigned int unRet = 0;

	if( wnd == NULL )
	{
		return;
	}

	nRet = CreateDict_SetData( wnd->imgadjust_dlg->pDialogDict );

	if( nRet == 0 )
	{
		unRet = SetItemValue_ImgAdjustDlgOK( wnd );
		if( (unRet & DICT_SET_RETURN_ERROR) == DICT_SET_RETURN_ERROR )
		{
			nRet = -1;
		}
	}

	if( ( nRet == 0 ) && ( unRet == DICT_SET_RETURN_CHANGE ) )
	{
		nRet = CommunicatePrinterData( wnd, (UIDialog *)wnd->imgadjust_dlg, wnd->imgadjust_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	}

	HideDialog( (UIDialog *)wnd->imgadjust_dlg );

	if( nRet != 0 )
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_SET );
	}

	return;
}

void UpdateImgAdjustDlgWidgets(const UIStatusWnd * const wnd, const int enable_calibration)
{
	if( wnd == NULL )
	{
		return;
	}

	GtkWidget * const pWindow = UI_DIALOG(wnd->imgadjust_dlg)->window;

	if( pWindow != NULL )
	{
		SetWidgetSensitive( pWindow, "ImgAdjustDlg_Time_hbox", enable_calibration );
	}
}

static int InitImgAdjustDlgWidgets( UIStatusWnd * const wnd )
{
	GtkWidget *pWindow = NULL;
	GList *pGlist = NULL;

	int nValue = 1;
	unsigned int i = 0;
	int nRet = 0;
	const char * const ctrl_type[IMG_ADJUST_CTRL_TYPE_NUM] = { "CNSUIImgAdjustDlg", "CNSUICtrlImgAdjust", NULL };

	int nIDCalibValue = -1;
	int nIDColorCorrectValue = -1;

	int *pnId = NULL;
	gchar *combostr = NULL;

	gboolean isCalibStartup = FALSE;

	if( wnd == NULL )
	{
		UI_DEBUG("wnd is NULL, from Func[%s] Line[%u] \n", __func__, __LINE__);
		return -1;
	}

	if( wnd->imgadjust_dlg == NULL )
	{
		UI_DEBUG("wnd->imgadjust_dlg is NULL, from Func[%s] Line[%u] \n", __func__, __LINE__);
		return -1;
	}
	else
	{
		pWindow = wnd->imgadjust_dlg->dialog.window;
	}

	CreatePPDCtrlTbl( wnd, ctrl_type, ctrlTbl, PPDCtrlTbl );

	SetLabel_HideWidget( pWindow, PPDCtrlTbl, ctrlTbl );

	if(wnd->imgadjust_dlg->glist == NULL)
	{
		wnd->imgadjust_dlg->glist = CreateGlist_DbId( PPDCtrlTbl );
	}

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		if( PPDCtrlTbl[i]->ctrlid == ID_CTRLCALIBSTARTUP )
		{
			isCalibStartup = TRUE;
			break;
		}
	}

	if( isCalibStartup == TRUE)
	{
	 	if(wnd->imgadjust_dlg->glist_appendId == NULL )
		{
			gboolean bGetId = FALSE;
			char *pTmp = cngplpGetValue_Wrapper( wnd->pModData, "CNSUIImgAdjustCalibStartupIdList" );
			if( pTmp != NULL )
			{
				wnd->imgadjust_dlg->glist_appendId = CreateIntGlistFromString( pTmp, CHARACTER_COMMA );
				mem_free( pTmp );
				pTmp = NULL;

				if(wnd->imgadjust_dlg->glist_appendId != NULL)
				{
					bGetId = TRUE;

					for( i = 0; i < g_list_length(wnd->imgadjust_dlg->glist_appendId); i++ )
					{
						pnId = (int*)g_list_nth_data(wnd->imgadjust_dlg->glist_appendId, i);

						if(pnId != NULL)
						{
							wnd->imgadjust_dlg->glist = g_list_append_wrapper(wnd->imgadjust_dlg->glist, pnId, __FILE__, __LINE__);
						}
					}
				}
			}

			if( bGetId != TRUE )
			{
				isCalibStartup = FALSE;
				HideWidget( pWindow, "ImgAdjustDlg_CalibStartup_hvox" );
			}
		}
	}

	if( wnd->imgadjust_dlg->pDialogDict != NULL )
	{
		UI_DEBUG("pDialogDict no mem_free, from Func[%s] Line[%u] \n", __func__, __LINE__);
		DeleteDict( wnd->imgadjust_dlg->pDialogDict );
	}

	wnd->imgadjust_dlg->pDialogDict = CretateDict_GetData( wnd->imgadjust_dlg->glist );
	if( wnd->imgadjust_dlg->pDialogDict == NULL )
	{
		UI_DEBUG("pDialogDict == NULL, from Func[%s] Line[%u] \n", __func__, __LINE__);
		return -1;
	}

	nRet = CommunicatePrinterData( wnd, NULL, wnd->imgadjust_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	if( nRet != 0 )
	{
		UI_DEBUG("CommunicatePrinterData failed, from Func[%s] Line[%u] \n", __func__, __LINE__);
		return -1;
	}

	for( i = 0; i < g_list_length(wnd->imgadjust_dlg->glist); i++ )
	{
		pnId = (int*)g_list_nth_data(wnd->imgadjust_dlg->glist, i);

		if(pnId == NULL)
		{
			continue;
		}

		switch( *pnId )
		{
		case ID722:
			GetItemValueType_int( wnd->imgadjust_dlg->pDialogDict, *pnId, &nValue );
			SetActiveCheckButton( pWindow, "ImgAdjustDlg_CalibEnable_checkbutton" , nValue, FALSE );
			SetWidgetSensitive( pWindow, "ImgAdjustDlg_Time_hbox", nValue );
			break;
		case ID732:
			GetItemValueType_int( wnd->imgadjust_dlg->pDialogDict, *pnId, &nValue );
			SetSpinButtonFloat( pWindow, "ImgAdjustDlg_TimeHour_spinbutton", (float)nValue );
			break;
		case ID742:
			GetItemValueType_int( wnd->imgadjust_dlg->pDialogDict, *pnId, &nValue );
			SetSpinButtonFloat( pWindow, "ImgAdjustDlg_TimeMin_spinbutton", (float)nValue );
			break;
		case ID122:
			GetItemValueType_int( wnd->imgadjust_dlg->pDialogDict, *pnId, &nIDCalibValue );
			break;
		case ID362:
			GetItemValueType_int( wnd->imgadjust_dlg->pDialogDict, *pnId, &nIDColorCorrectValue );
			break;
		default:
			break;
		}

	}

	if(isCalibStartup == TRUE)
	{
		for(i = 0; CalibStartupTbl[i].dispstr != NULL; i++)
		{
			pGlist = g_list_append_wrapper( pGlist, _(CalibStartupTbl[i].dispstr), __FILE__, __LINE__);

			if( (nIDCalibValue == CalibStartupTbl[i].nIDCalibState) &&
			    (nIDColorCorrectValue == CalibStartupTbl[i].nIDColorCorrectState) )
			{
				combostr = _(CalibStartupTbl[i].dispstr);
			}
		}

		SetGListToComboBox( pWindow, "ImgAdjustDlg_CalibStartup_combo", pGlist );

		g_list_free_wrapper( pGlist );

		SetCurrComboBoxText( pWindow, "ImgAdjustDlg_CalibStartup_combo", combostr );
	}

	return nRet;
}

void DisposeImgAdjustDlg( UIStatusWnd* const wnd )
{
	UIImgAdjustDlg * ui_imgadjust_dlg = NULL;

	if(wnd == NULL)
	{
		return;
	}

	ui_imgadjust_dlg = wnd->imgadjust_dlg;
	if( ui_imgadjust_dlg != NULL)
	{
		if( ui_imgadjust_dlg->glist != NULL )
		{
			g_list_free_wrapper( ui_imgadjust_dlg->glist );
			ui_imgadjust_dlg->glist = NULL;
		}

		if( ui_imgadjust_dlg->glist_appendId != NULL )
		{
			g_list_foreach(ui_imgadjust_dlg->glist_appendId, (GFunc)mem_free, NULL);
			g_list_free_wrapper( ui_imgadjust_dlg->glist_appendId );
			ui_imgadjust_dlg->glist_appendId = NULL;
		}

		if( ui_imgadjust_dlg->pDialogDict != NULL )
		{
			DeleteDict( ui_imgadjust_dlg->pDialogDict );
			ui_imgadjust_dlg->pDialogDict = NULL;
		}
		DisposeDialog( (UIDialog *)ui_imgadjust_dlg );
		wnd->imgadjust_dlg = NULL;
	}
}
