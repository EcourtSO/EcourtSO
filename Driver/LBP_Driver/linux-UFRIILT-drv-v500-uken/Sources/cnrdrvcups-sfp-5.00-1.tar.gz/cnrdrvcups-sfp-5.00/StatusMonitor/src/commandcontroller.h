/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#ifndef _COMMNANDCONTROLLER
#define _COMMNANDCONTROLLER

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>

#include "uimain.h"
#include "dictcontroller.h"

typedef enum
{
	GETAREAINFO_NONE = 0,
	GETAREAINFO_GET,
} GetAreaInfoType;

#define CODE_COMMAND_ANALYZE 0x0001be01

Dict* Find_ItemDict_FormItemList( Dict* Dict, int nID );
Dict* CretateDict_GetData(GList* const IDList);
int GetItemValueType_int(Dict* const GetDataDict, const int nID, int* const pValue);
const char* GetItemValueType_char(Dict* const GetDataDict, const int nID);
Dict* GetItemValueType_dict(Dict* const GetDataDict, const int nID);
Dict* GetPaperInfoDict(Dict* const statusDict, const char* const paperSource);
int CreateDict_SetData(Dict* const dict);
unsigned int SetItemValuetype_int(Dict* const SetDataDict, const int nID, const int Value);
unsigned int SetItemValuetype_char(Dict* const SetDataDict, const int nID, const char* const Value);
int SetData_ItemDelete( Dict* const SetDataDict, const int nID );
Dict* CreateDict_DeviceOperation(int nOperation);
Dict* CreateDict_DeviceOperationIntParam( int nOperation, int nParam );
Dict* CreateDict_JobOperation(int nOperation, int nJobID);
Dict* CreateDict_GetConsumable();
Dict* CreateDict_GetStatus(const GetAreaInfoType getAreaInfo);
int CommunicatePrinterData( UIStatusWnd* const wnd, UIDialog* const parent, Dict* const dict, const int code, const gboolean bRetry );
int CommunicatePrinterDataAndControlMsgDlg( UIStatusWnd* const wnd, UIDialog* const parent, Dict* const dict, const int code, const int msgId, const gboolean bRetry );
int SendData( const UIStatusWnd* const wnd, const int nCode, const gboolean bRetry );

#endif
