/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2015 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "uimain.h"
#include "widgets.h"
#include "interface.h"
#include "reportprintdlg.h"

#include "callbacks.h"
#include "support.h"
#include "id_defines.h"
#include "commandcontroller.h"
#include "value_defines.h"
#include "key_defines.h"


CtrlTbl* PPDCtrlTbl[CTRL_LIST_MAXNUM];

static ComboBoxContent languageContents[] =
{
	{ N_("English"), NCAP_VALUE_LANGENGLISH, },
	{ N_("French"), NCAP_VALUE_LANGFRENCH, },
	{ N_("Spanish"), NCAP_VALUE_LANGSPANISH, },
	{ N_("German"), NCAP_VALUE_LANGGERMAN, },
	{ N_("Italian"), NCAP_VALUE_LANGITALIAN, },
	{ N_("Dutch"), NCAP_VALUE_LANGDUTCH, },
	{ N_("Portuguese"), NCAP_VALUE_LANGPORTUGUESE, },
	{ N_("Russian"), NCAP_VALUE_LANGRUSSIAN, },
	{ N_("Norwegian"), NCAP_VALUE_LANGNORWEGIAN, },
	{ N_("Finnish"), NCAP_VALUE_LANGFINNISH, },
	{ N_("Swedish"), NCAP_VALUE_LANGSWEDISH, },
	{ N_("Danish"), NCAP_VALUE_LANGDANISH, },
	{ N_("Polish"), NCAP_VALUE_LANGPOLISH, },
	{ N_("Czech"), NCAP_VALUE_LANGCZECH, },
	{ N_("Hungarian"), NCAP_VALUE_LANGHUNGARIAN, },
	{ N_("Turkish"), NCAP_VALUE_LANGTURKISH, },
	{ N_("Chinese (Simplified)"), NCAP_VALUE_LANGCHNSIMPLIFIED, },
	{ N_("Korean"), NCAP_VALUE_LANGKOREAN, },
	{ N_("Thai"), NCAP_VALUE_LANGTHAI, },
	{ N_("Vietnamese"), NCAP_VALUE_LANGVIETNAMESE, },
	{ N_("Malay"), NCAP_VALUE_LANGMALAY, },
	{ N_("Arabic"), NCAP_VALUE_LANGARABIC, },
	{ N_("Basque"), NCAP_VALUE_LANGBASQUE, },
	{ N_("Catalan"), NCAP_VALUE_LANGCATALAN, },
	{ NULL, NULL, }
};

static const char *AreaInfoKeyAsia = "CNSUIReportPrintLangAsia";
static const char *AreaInfoKeyChina = "CNSUIReportPrintLangChina";
static const char *AreaInfoKeyEurope = "CNSUIReportPrintLangEurope";
static const char *AreaInfoKeyNorthAmerica = "CNSUIReportPrintLangNorthAmerica";

static CtrlTbl ctrlTbl[] =
{
	{ ID_REPORTPRINT_DIALOG1, LABEL_TYPE_TITLE, NULL,
		N_("Select Language for User Data List"), NULL, 0 },

	{ ID_CTRLREPORTPRINTLANG, LABEL_TYPE_TEXT, "ReportPrintDlg_Language_label",
		N_("Language:"), "ReportPrintDlg_Language_box", ID1833 },

	{ -1, -1, NULL, NULL, NULL, -1 }
};

static int InitReportPrintDlgWidgets( UIStatusWnd* const wnd );
static const char *GetAreaInfoKey( UIStatusWnd* const wnd );
static unsigned int SetItemValue_ReportPrintDlgOK( const UIStatusWnd* const wnd );

UIReportPrintDlg* CreateReportPrintDlg(UIDialog* const parent)
{
	UIReportPrintDlg *pDialog = NULL;

	pDialog = (UIReportPrintDlg *)CreateDialog(sizeof(UIReportPrintDlg), parent);
	if( pDialog != NULL )
	{
		UI_DIALOG(pDialog)->window = create_ReportPrint_dialog();
	}
	return pDialog;
}

void ShowReportPrintDlg( UIStatusWnd* const wnd )
{
	int nRet = 0;

	if( wnd == NULL )
	{
		return;
	}
	if( wnd->reportprint_dlg == NULL )
	{
		wnd->reportprint_dlg = CreateReportPrintDlg( UI_DIALOG( wnd ) );
	}

	SigDisable();
	nRet = InitReportPrintDlgWidgets( wnd );
	SigEnable();

	if( nRet == 0 )
	{
		ShowDialog( (UIDialog *)wnd->reportprint_dlg, NULL );
	}
	else
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_GET );
		if( wnd->reportprint_dlg != NULL )
		{
			if( wnd->reportprint_dlg->pDialogDict != NULL )
			{
				DeleteDict( wnd->reportprint_dlg->pDialogDict );
				wnd->reportprint_dlg->pDialogDict = NULL;
			}
			mem_free( wnd->reportprint_dlg );
			wnd->reportprint_dlg = NULL;
		}
	}
}

static unsigned int SetItemValue_ReportPrintDlgOK( const UIStatusWnd* const wnd )
{
	int i = 0;
	unsigned int unRet = 0;

	if( wnd == NULL )
	{
		UI_DEBUG("SetItemValue_ReportPrintDlgOK PPDCtrlTbl[%p] wnd[%p]\n", PPDCtrlTbl, wnd);
		return DICT_SET_RETURN_ERROR;
	}

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		switch( PPDCtrlTbl[i]->dbid )
		{
		case ID1833:
			{
				const char* pValue = NULL;

				pValue = GetComboBoxSelectedValue( wnd->reportprint_dlg->pLanguageComboBoxItem );
				if( pValue != NULL )
				{
					unRet |= SetItemValuetype_char( wnd->reportprint_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, pValue );
					UI_DEBUG("SetItemValue_ReportPrintDlgOK unRet[%d]\n", unRet);
				}
			}
			break;
		default:
			break;
		}
		if( (unRet & DICT_SET_RETURN_ERROR) == DICT_SET_RETURN_ERROR )
		{
			break;
		}
	}
	return unRet;
}

void ReportPrintDlgOK( UIStatusWnd* const wnd )
{
	int nRet = 0;
	unsigned int unRet = 0;

	if( wnd == NULL )
	{
		return;
	}
	else
	{
		nRet = CreateDict_SetData( wnd->reportprint_dlg->pDialogDict );
	}

	if( nRet == 0 )
	{
		unRet = SetItemValue_ReportPrintDlgOK( wnd );
		if( (unRet & DICT_SET_RETURN_ERROR) == DICT_SET_RETURN_ERROR )
		{
			nRet = -1;
		}
	}

	if( ( nRet == 0 ) && ( unRet == DICT_SET_RETURN_CHANGE ) )
	{
		nRet = CommunicatePrinterData( wnd, (UIDialog *)wnd->reportprint_dlg, wnd->reportprint_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	}

	HideDialog( (UIDialog *)wnd->reportprint_dlg );

	if( nRet != 0 )
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_SET );
	}

	return;
}

static const char *GetAreaInfoKey( UIStatusWnd* const wnd )
{
	const char *pAreaInfoKey = AreaInfoKeyNorthAmerica;

	EnterCriticalSection(&g_StatusSection);
	{
		const char *pAreaInfo = GetAreaInfo(wnd);

		if( pAreaInfo != NULL )
		{
			if( strcmp(pAreaInfo, AREA_INFO_ASIA) == 0 )
			{
				pAreaInfoKey = AreaInfoKeyAsia;
			}
			else if( strcmp(pAreaInfo, AREA_INFO_CHINA) == 0 )
			{
				pAreaInfoKey = AreaInfoKeyChina;
			}
			else if( strcmp(pAreaInfo, AREA_INFO_EU) == 0 )
			{
				pAreaInfoKey = AreaInfoKeyEurope;
			}
			else if( strcmp(pAreaInfo, AREA_INFO_NORTH_AMERICA) == 0 )
			{
				pAreaInfoKey = AreaInfoKeyNorthAmerica;
			}
		}
	}
	LeaveCriticalSection(&g_StatusSection);

	return pAreaInfoKey;
}

static int InitReportPrintDlgWidgets( UIStatusWnd* const wnd )
{
	GtkWidget *pWindow = NULL;
	GList *pGlist = NULL;
	int i = 0;
	int nRet = 0;
	const char* const ctrl_type[] = { "CNSUIReportPrintDlg", "CNSUICtrlReportPrintLang", NULL };

	if( wnd == NULL )
	{
		return -1;
	}

	if( wnd->reportprint_dlg == NULL )
	{
		return -1;
	}
	else
	{
		pWindow = wnd->reportprint_dlg->dialog.window;
	}

	CreatePPDCtrlTbl( wnd, ctrl_type, ctrlTbl, PPDCtrlTbl );

	SetLabel_HideWidget( pWindow, PPDCtrlTbl, ctrlTbl );

	pGlist = CreateGlist_DbId( PPDCtrlTbl );

	if( wnd->reportprint_dlg->pDialogDict != NULL )
	{
		UI_DEBUG("pDialogDict no mem_free, from Func[%s] Line[%u] \n", __func__, __LINE__);
		DeleteDict( wnd->reportprint_dlg->pDialogDict );
	}
	wnd->reportprint_dlg->pDialogDict = CretateDict_GetData( pGlist );
	g_list_free_wrapper( pGlist );
	pGlist = NULL;

	if( wnd->reportprint_dlg->pDialogDict == NULL )
	{
		return -1;
	}

	nRet = CommunicatePrinterData( wnd, NULL, wnd->reportprint_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	if( nRet != 0 )
	{
		return -1;
	}

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		switch( PPDCtrlTbl[i]->dbid )
		{
		case ID1833:
			if( wnd->reportprint_dlg->pLanguageComboBoxItem == NULL )
			{
				const char *pAreaInfoKey = GetAreaInfoKey( wnd );

				if( pAreaInfoKey != NULL )
				{
					wnd->reportprint_dlg->pLanguageComboBoxItem = CreateComboBoxItem( pWindow, wnd->pModData,
						pAreaInfoKey, "ReportPrintDlg_Language_combo", languageContents );
				}
			}

			if( wnd->reportprint_dlg->pLanguageComboBoxItem != NULL )
			{
				const char* pValue = NULL;

				pValue = GetItemValueType_char( wnd->reportprint_dlg->pDialogDict, PPDCtrlTbl[i]->dbid );
				if( pValue == NULL )
				{
					nRet = -1;
				}
				else
				{
					SetComboBoxSelectedValue(wnd->reportprint_dlg->pLanguageComboBoxItem, pValue);
				}
			}
			break;
		default:
			break;
		}
	}

	return nRet;
}

void DisposeReportPrintDlg( UIStatusWnd* const wnd )
{
	UIReportPrintDlg* ui_dialog = NULL;

	if(wnd == NULL)
	{
		return;
	}

	ui_dialog = wnd->reportprint_dlg;
	if( ui_dialog != NULL )
	{
		if( ui_dialog->pLanguageComboBoxItem != NULL )
		{
			DisposeComboBoxItem(ui_dialog->pLanguageComboBoxItem);
			ui_dialog->pLanguageComboBoxItem = NULL;
		}

		if( ui_dialog->pDialogDict != NULL )
		{
			DeleteDict( ui_dialog->pDialogDict );
			ui_dialog->pDialogDict = NULL;
		}

		DisposeDialog( (UIDialog *)ui_dialog );
		wnd->reportprint_dlg = NULL;
	}
}

