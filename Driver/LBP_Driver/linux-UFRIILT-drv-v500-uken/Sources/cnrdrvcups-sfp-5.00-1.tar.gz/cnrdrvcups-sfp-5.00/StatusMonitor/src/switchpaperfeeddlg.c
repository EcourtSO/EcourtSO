/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2015 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "uimain.h"
#include "widgets.h"
#include "interface.h"
#include "switchpaperfeeddlg.h"

#include "callbacks.h"
#include "support.h"
#include "id_defines.h"
#include "commandcontroller.h"
#include "value_defines.h"


CtrlTbl* PPDCtrlTbl[CTRL_LIST_MAXNUM];

static ComboBoxContent switchPaperFeedContents[] =
{
	{ N_("Speed Priority"), NCAP_VALUE_SPEED, },
	{ N_("Print Side Priority"), NCAP_VALUE_PRINTSIDE, },
	{ NULL, NULL, }
};

static CtrlTbl ctrlTbl[] =
{
	{ ID_SWITCHPAPERFEED_DIALOG1, LABEL_TYPE_TITLE, NULL,
		N_("Switch Paper Feed Method"), NULL, 0 },

	{ ID_CTRLSWITCHPAPERFEEDMANUALTRAY, LABEL_TYPE_TEXT, "SwitchPaperFeedDlg_ManualTray_label",
		N_("Multi-Purpose Tray:"), "SwitchPaperFeedDlg_ManualTray_box", ID1813 },

	{ ID_CTRLSWITCHPAPERFEEDCASSETTE1, LABEL_TYPE_TEXT, "SwitchPaperFeedDlg_Cassette1_label",
		N_("Drawer 1:"), "SwitchPaperFeedDlg_Cassette1_box", ID1823 },

	{ -1, -1, NULL, NULL, NULL, -1 }
};

static int InitSwitchPaperFeedDlgWidgets( UIStatusWnd* const wnd );
static unsigned int SetItemValue_SwitchPaperFeedDlgOK( const UIStatusWnd* const wnd );

UISwitchPaperFeedDlg* CreateSwitchPaperFeedDlg(UIDialog* const parent)
{
	UISwitchPaperFeedDlg *pDialog = NULL;

	pDialog = (UISwitchPaperFeedDlg *)CreateDialog(sizeof(UISwitchPaperFeedDlg), parent);
	if( pDialog != NULL )
	{
		UI_DIALOG(pDialog)->window = create_SwitchPaperFeed_dialog();
	}
	return pDialog;
}

void ShowSwitchPaperFeedDlg( UIStatusWnd* const wnd )
{
	int nRet = 0;

	if( wnd == NULL )
	{
		return;
	}
	if( wnd->switchpaperfeed_dlg == NULL )
	{
		wnd->switchpaperfeed_dlg = CreateSwitchPaperFeedDlg( UI_DIALOG( wnd ) );
	}

	SigDisable();
	nRet = InitSwitchPaperFeedDlgWidgets( wnd );
	SigEnable();

	if( nRet == 0 )
	{
		ShowDialog( (UIDialog *)wnd->switchpaperfeed_dlg, NULL );
	}
	else
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_GET );
		if( wnd->switchpaperfeed_dlg != NULL )
		{
			if( wnd->switchpaperfeed_dlg->pDialogDict != NULL )
			{
				DeleteDict( wnd->switchpaperfeed_dlg->pDialogDict );
				wnd->switchpaperfeed_dlg->pDialogDict = NULL;
			}
			mem_free( wnd->switchpaperfeed_dlg );
			wnd->switchpaperfeed_dlg = NULL;
		}
	}
}

static unsigned int SetItemValue_SwitchPaperFeedDlgOK( const UIStatusWnd* const wnd )
{
	int i = 0;
	unsigned int unRet = 0;

	if( wnd == NULL )
	{
		UI_DEBUG("SetItemValue_SwitchPaperFeedDlgOK PPDCtrlTbl[%p] wnd[%p]\n", PPDCtrlTbl, wnd);
		return DICT_SET_RETURN_ERROR;
	}

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		const char* pValue = NULL;

		switch( PPDCtrlTbl[i]->dbid )
		{
		case ID1813:
			pValue = GetComboBoxSelectedValue( wnd->switchpaperfeed_dlg->pManualTrayComboBoxItem );
			if( pValue != NULL )
			{
				unRet |= SetItemValuetype_char( wnd->switchpaperfeed_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, pValue );
				UI_DEBUG("SetItemValue_SwitchPaperFeedDlgOK dbid[%d] unRet[%d]\n", PPDCtrlTbl[i]->dbid, unRet);
			}
			break;
		case ID1823:
			pValue = GetComboBoxSelectedValue( wnd->switchpaperfeed_dlg->pCassette1ComboBoxItem );
			if( pValue != NULL )
			{
				unRet |= SetItemValuetype_char( wnd->switchpaperfeed_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, pValue );
				UI_DEBUG("SetItemValue_SwitchPaperFeedDlgOK dbid[%d] unRet[%d]\n", PPDCtrlTbl[i]->dbid, unRet);
			}
			break;
		default:
			break;
		}
		if( (unRet & DICT_SET_RETURN_ERROR) == DICT_SET_RETURN_ERROR )
		{
			break;
		}
	}
	return unRet;
}

void SwitchPaperFeedDlgOK( UIStatusWnd* const wnd )
{
	int nRet = 0;
	unsigned int unRet = 0;

	if( wnd == NULL )
	{
		return;
	}
	else
	{
		nRet = CreateDict_SetData( wnd->switchpaperfeed_dlg->pDialogDict );
	}

	if( nRet == 0 )
	{
		unRet = SetItemValue_SwitchPaperFeedDlgOK( wnd );
		if( (unRet & DICT_SET_RETURN_ERROR) == DICT_SET_RETURN_ERROR )
		{
			nRet = -1;
		}
	}

	if( ( nRet == 0 ) && ( unRet == DICT_SET_RETURN_CHANGE ) )
	{
		nRet = CommunicatePrinterData( wnd, (UIDialog *)wnd->switchpaperfeed_dlg, wnd->switchpaperfeed_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	}

	HideDialog( (UIDialog *)wnd->switchpaperfeed_dlg );

	if( nRet != 0 )
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_SET );
	}

	return;
}

static int InitSwitchPaperFeedDlgWidgets( UIStatusWnd* const wnd )
{
	GtkWidget *pWindow = NULL;
	GList *pGlist = NULL;
	int i = 0;
	int nRet = 0;
	const char* const ctrl_type[] = { "CNSUISwitchPaperFeedDlg", "CNSUICtrlSwitchPaperFeed", NULL };

	if( wnd == NULL )
	{
		return -1;
	}

	if( wnd->switchpaperfeed_dlg == NULL )
	{
		return -1;
	}
	else
	{
		pWindow = wnd->switchpaperfeed_dlg->dialog.window;
	}

	CreatePPDCtrlTbl( wnd, ctrl_type, ctrlTbl, PPDCtrlTbl );

	SetLabel_HideWidget( pWindow, PPDCtrlTbl, ctrlTbl );

	pGlist = CreateGlist_DbId( PPDCtrlTbl );

	if( wnd->switchpaperfeed_dlg->pDialogDict != NULL )
	{
		UI_DEBUG("pDialogDict no mem_free, from Func[%s] Line[%u] \n", __func__, __LINE__);
		DeleteDict( wnd->switchpaperfeed_dlg->pDialogDict );
	}
	wnd->switchpaperfeed_dlg->pDialogDict = CretateDict_GetData( pGlist );
	g_list_free_wrapper( pGlist );
	pGlist = NULL;

	if( wnd->switchpaperfeed_dlg->pDialogDict == NULL )
	{
		return -1;
	}

	nRet = CommunicatePrinterData( wnd, NULL, wnd->switchpaperfeed_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	if( nRet != 0 )
	{
		return -1;
	}

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		switch( PPDCtrlTbl[i]->dbid )
		{
		case ID1813:
			if( wnd->switchpaperfeed_dlg->pManualTrayComboBoxItem == NULL )
			{
				wnd->switchpaperfeed_dlg->pManualTrayComboBoxItem = CreateComboBoxItem( pWindow, wnd->pModData,
					"CNSUISwitchPaperFeedManualTrayList", "SwitchPaperFeedDlg_ManualTray_combo", switchPaperFeedContents );
			}

			if( wnd->switchpaperfeed_dlg->pManualTrayComboBoxItem == NULL )
			{
				nRet = -1;
			}
			else
			{
				const char* pValue = NULL;

				pValue = GetItemValueType_char( wnd->switchpaperfeed_dlg->pDialogDict, PPDCtrlTbl[i]->dbid );
				if( pValue == NULL )
				{
					nRet = -1;
				}
				else
				{
					SetComboBoxSelectedValue(wnd->switchpaperfeed_dlg->pManualTrayComboBoxItem, pValue);
				}
			}
			break;
		case ID1823:
			if( wnd->switchpaperfeed_dlg->pCassette1ComboBoxItem == NULL )
			{
				wnd->switchpaperfeed_dlg->pCassette1ComboBoxItem = CreateComboBoxItem( pWindow, wnd->pModData,
					"CNSUISwitchPaperFeedCassette1List", "SwitchPaperFeedDlg_Cassette1_combo", switchPaperFeedContents );
			}

			if( wnd->switchpaperfeed_dlg->pCassette1ComboBoxItem == NULL )
			{
				nRet = -1;
			}
			else
			{
				const char* pValue = NULL;

				pValue = GetItemValueType_char( wnd->switchpaperfeed_dlg->pDialogDict, PPDCtrlTbl[i]->dbid );
				if( pValue == NULL )
				{
					nRet = -1;
				}
				else
				{
					SetComboBoxSelectedValue(wnd->switchpaperfeed_dlg->pCassette1ComboBoxItem, pValue);
				}
			}
			break;
		default:
			break;
		}
	}

	return nRet;
}

void DisposeSwitchPaperFeedDlg( UIStatusWnd* const wnd )
{
	UISwitchPaperFeedDlg* ui_dialog = NULL;

	if(wnd == NULL)
	{
		return;
	}

	ui_dialog = wnd->switchpaperfeed_dlg;
	if( ui_dialog != NULL )
	{
		if( ui_dialog->pManualTrayComboBoxItem != NULL )
		{
			DisposeComboBoxItem(ui_dialog->pManualTrayComboBoxItem);
			ui_dialog->pManualTrayComboBoxItem = NULL;
		}

		if( ui_dialog->pCassette1ComboBoxItem != NULL )
		{
			DisposeComboBoxItem(ui_dialog->pCassette1ComboBoxItem);
			ui_dialog->pCassette1ComboBoxItem = NULL;
		}

		if( ui_dialog->pDialogDict != NULL )
		{
			DeleteDict( ui_dialog->pDialogDict );
			ui_dialog->pDialogDict = NULL;
		}

		DisposeDialog( (UIDialog *)ui_dialog );
		wnd->switchpaperfeed_dlg = NULL;
	}
}

