/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2015 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "uimain.h"
#include "widgets.h"
#include "interface.h"
#include "mobileprintdlg.h"

#include "callbacks.h"
#include "support.h"
#include "id_defines.h"
#include "commandcontroller.h"
#include "value_defines.h"


CtrlTbl* PPDCtrlTbl[CTRL_LIST_MAXNUM];

static ComboBoxContent halftonesContents[] =
{
	{ N_("Gradation"), NCAP_VALUE_GRADATION, },
	{ N_("Error Diffusion"), NCAP_VALUE_DITHERING, },
	{ NULL, NULL, }
};

static CtrlTbl ctrlTbl[] =
{
	{ ID_MOBILEPRINT_DIALOG1, LABEL_TYPE_TITLE, NULL,
		N_("Mobile Print Settings"), NULL, 0 },

	{ ID_CTRLMOBILEPRINTHALFTONES, LABEL_TYPE_TEXT, "MobilePrintDlg_Halftones_label",
		N_("Halftones:"), "MobilePrintDlg_Halftones_box", ID1793 },

	{ -1, -1, NULL, NULL, NULL, -1 }
};

static int InitMobilePrintDlgWidgets( UIStatusWnd* const wnd );
static unsigned int SetItemValue_MobilePrintDlgOK( const UIStatusWnd* const wnd );

UIMobilePrintDlg* CreateMobilePrintDlg(UIDialog* const parent)
{
	UIMobilePrintDlg *pDialog = NULL;

	pDialog = (UIMobilePrintDlg *)CreateDialog(sizeof(UIMobilePrintDlg), parent);
	if( pDialog != NULL )
	{
		UI_DIALOG(pDialog)->window = create_MobilePrint_dialog();
	}
	return pDialog;
}

void ShowMobilePrintDlg( UIStatusWnd* const wnd )
{
	int nRet = 0;

	if( wnd == NULL )
	{
		return;
	}
	if( wnd->mobileprint_dlg == NULL )
	{
		wnd->mobileprint_dlg = CreateMobilePrintDlg( UI_DIALOG( wnd ) );
	}

	SigDisable();
	nRet = InitMobilePrintDlgWidgets( wnd );
	SigEnable();

	if( nRet == 0 )
	{
		ShowDialog( (UIDialog *)wnd->mobileprint_dlg, NULL );
	}
	else
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_GET );
		if( wnd->mobileprint_dlg != NULL )
		{
			if( wnd->mobileprint_dlg->pDialogDict != NULL )
			{
				DeleteDict( wnd->mobileprint_dlg->pDialogDict );
				wnd->mobileprint_dlg->pDialogDict = NULL;
			}
			mem_free( wnd->mobileprint_dlg );
			wnd->mobileprint_dlg = NULL;
		}
	}
}

static unsigned int SetItemValue_MobilePrintDlgOK( const UIStatusWnd* const wnd )
{
	int i = 0;
	unsigned int unRet = 0;

	if( wnd == NULL )
	{
		UI_DEBUG("SetItemValue_MobilePrintDlgOK PPDCtrlTbl[%p] wnd[%p]\n", PPDCtrlTbl, wnd);
		return DICT_SET_RETURN_ERROR;
	}

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		switch( PPDCtrlTbl[i]->dbid )
		{
		case ID1793:
			{
				const char* pValue = NULL;

				pValue = GetComboBoxSelectedValue( wnd->mobileprint_dlg->pHalftonesComboBoxItem );
				if( pValue != NULL )
				{
					unRet |= SetItemValuetype_char( wnd->mobileprint_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, pValue );
					UI_DEBUG("SetItemValue_MobilePrintDlgOK unRet[%d]\n", unRet);
				}
			}
			break;
		default:
			break;
		}
		if( (unRet & DICT_SET_RETURN_ERROR) == DICT_SET_RETURN_ERROR )
		{
			break;
		}
	}
	return unRet;
}

void MobilePrintDlgOK( UIStatusWnd* const wnd )
{
	int nRet = 0;
	unsigned int unRet = 0;

	if( wnd == NULL )
	{
		return;
	}
	else
	{
		nRet = CreateDict_SetData( wnd->mobileprint_dlg->pDialogDict );
	}

	if( nRet == 0 )
	{
		unRet = SetItemValue_MobilePrintDlgOK( wnd );
		if( (unRet & DICT_SET_RETURN_ERROR) == DICT_SET_RETURN_ERROR )
		{
			nRet = -1;
		}
	}

	if( ( nRet == 0 ) && ( unRet == DICT_SET_RETURN_CHANGE ) )
	{
		nRet = CommunicatePrinterData( wnd, (UIDialog *)wnd->mobileprint_dlg, wnd->mobileprint_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	}

	HideDialog( (UIDialog *)wnd->mobileprint_dlg );

	if( nRet != 0 )
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_SET );
	}

	return;
}

static int InitMobilePrintDlgWidgets( UIStatusWnd* const wnd )
{
	GtkWidget *pWindow = NULL;
	GList *pGlist = NULL;
	int i = 0;
	int nRet = 0;
	const char* const ctrl_type[] = { "CNSUIMobilePrintDlg", "CNSUICtrlMobilePrintHalftones", NULL };

	if( wnd == NULL )
	{
		return -1;
	}

	if( wnd->mobileprint_dlg == NULL )
	{
		return -1;
	}
	else
	{
		pWindow = wnd->mobileprint_dlg->dialog.window;
	}

	CreatePPDCtrlTbl( wnd, ctrl_type, ctrlTbl, PPDCtrlTbl );

	SetLabel_HideWidget( pWindow, PPDCtrlTbl, ctrlTbl );

	pGlist = CreateGlist_DbId( PPDCtrlTbl );

	if( wnd->mobileprint_dlg->pDialogDict != NULL )
	{
		UI_DEBUG("pDialogDict no mem_free, from Func[%s] Line[%u] \n", __func__, __LINE__);
		DeleteDict( wnd->mobileprint_dlg->pDialogDict );
	}
	wnd->mobileprint_dlg->pDialogDict = CretateDict_GetData( pGlist );
	g_list_free_wrapper( pGlist );
	pGlist = NULL;

	if( wnd->mobileprint_dlg->pDialogDict == NULL )
	{
		return -1;
	}

	nRet = CommunicatePrinterData( wnd, NULL, wnd->mobileprint_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	if( nRet != 0 )
	{
		return -1;
	}

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		switch( PPDCtrlTbl[i]->dbid )
		{
		case ID1793:
			if( wnd->mobileprint_dlg->pHalftonesComboBoxItem == NULL )
			{
				wnd->mobileprint_dlg->pHalftonesComboBoxItem = CreateComboBoxItem( pWindow, wnd->pModData,
					"CNSUIMobilePrintHalftonesList", "MobilePrintDlg_Halftones_combo", halftonesContents );
			}

			if( wnd->mobileprint_dlg->pHalftonesComboBoxItem == NULL )
			{
				nRet = -1;
			}
			else
			{
				const char* pValue = NULL;

				pValue = GetItemValueType_char( wnd->mobileprint_dlg->pDialogDict, PPDCtrlTbl[i]->dbid );
				if( pValue == NULL )
				{
					nRet = -1;
				}
				else
				{
					SetComboBoxSelectedValue(wnd->mobileprint_dlg->pHalftonesComboBoxItem, pValue);
				}
			}
			break;
		default:
			break;
		}
	}

	return nRet;
}

void DisposeMobilePrintDlg( UIStatusWnd* const wnd )
{
	UIMobilePrintDlg* ui_dialog = NULL;

	if(wnd == NULL)
	{
		return;
	}

	ui_dialog = wnd->mobileprint_dlg;
	if( ui_dialog != NULL )
	{
		if( ui_dialog->pHalftonesComboBoxItem != NULL )
		{
			DisposeComboBoxItem(ui_dialog->pHalftonesComboBoxItem);
			ui_dialog->pHalftonesComboBoxItem = NULL;
		}

		if( ui_dialog->pDialogDict != NULL )
		{
			DeleteDict( ui_dialog->pDialogDict );
			ui_dialog->pDialogDict = NULL;
		}

		DisposeDialog( (UIDialog *)ui_dialog );
		wnd->mobileprint_dlg = NULL;
	}
}

