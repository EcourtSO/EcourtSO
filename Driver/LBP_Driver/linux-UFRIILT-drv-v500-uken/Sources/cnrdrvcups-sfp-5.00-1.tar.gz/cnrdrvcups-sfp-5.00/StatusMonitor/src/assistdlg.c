/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */



#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "uimain.h"
#include "widgets.h"
#include "interface.h"
#include "assistdlg.h"

#include "callbacks.h"
#include "support.h"
#include "id_defines.h"
#include "commandcontroller.h"
#include "value_defines.h"

#define ASSIST_CTRL_TYPE_NUM 3
#define ASSIST_CTRL_TBL_NUM 21

static int InitAssistSettingDlgWidgets( UIStatusWnd* const wnd );
static unsigned int SetItemValue_AssistSettingDlgOK( const UIStatusWnd* const wnd );

CtrlTbl* PPDCtrlTbl[CTRL_LIST_MAXNUM];

static ComboBoxContent specialPrintAdjustmentContents[] =
{
	{ N_("Off"), NCAP_VALUE_OFF, },
	{ N_("Mode 1"), NCAP_VALUE_MODE1, },
	{ N_("Mode 2"), NCAP_VALUE_MODE2, },
	{ N_("Mode 3"), NCAP_VALUE_MODE3, },
	{ N_("Mode 4"), NCAP_VALUE_MODE4, },
	{ NULL, NULL, }
};
static ComboBoxContent selectLineWidthContents[] =
{
	{ N_("Auto"), NCAP_VALUE_AUTO, },
	{ N_("Thin"), NCAP_VALUE_THIN, },
	{ N_("Slightly Thin"), NCAP_VALUE_SLIGHTLY_THIN, },
	{ N_("Slightly Thick"), NCAP_VALUE_SLIGHTLY_THICK, },
	{ N_("Thick"), NCAP_VALUE_EEEE, },
	{ NULL, NULL, }
};

static CtrlTbl ctrlTbl[ASSIST_CTRL_TBL_NUM] =
{
	{ ID_ASSISTSETTING_DIALOG1, LABEL_TYPE_TITLE, NULL, N_("Assisting Print Settings"), NULL, 0 },
	{ ID_CTRLCURLCORRECTENABLE, LABEL_TYPE_BUTTON, "AssistDlg_Curl_checkbutton", N_("Perform Curl Correction for Output Paper"), "AssistDlg_Curl_checkbutton", ID132 },
	{ ID_CTRLPREVENTQLTYENABLE, LABEL_TYPE_BUTTON, "AssistDlg_Qlty_checkbutton", N_("Prevent Poor Quality after Long Idle"), "AssistDlg_Qlty_checkbutton", ID1092 },
	{ ID_CTRLPREVENTCLINGENABLE, LABEL_TYPE_BUTTON, "AssistDlg_Cling_checkbutton", N_("Perform Envelope Cling Prevention When Printing"), "AssistDlg_Cling_checkbutton", ID872 },
	{ ID_CTRLREDUCTWRINKLEENABLE, LABEL_TYPE_BUTTON, "AssistDlg_Wrinkle_checkbutton", N_("Perform Envelope Wrinkle Reduction When Printing"), "AssistDlg_Wrinkle_checkbutton", ID1072 },
	{ ID_CTRLSPECIALPRINTADJUSTMENT_V, LABEL_TYPE_TEXT, "AssistDlg_SpecialPrintAdjustmentV_label", N_("Special Print Adjustment V:"), "AssistDlg_SpecialPrintAdjustmentV_box", ID673 },
	{ ID_CTRLSPECIALPRINTADJUSTMENT, LABEL_TYPE_TEXT, "AssistDlg_SpecialPrintAdjustment_label", N_("Special Print Adjustment:"), "AssistDlg_SpecialPrintAdjustment_box", ID2033 },
	{ ID_CTRLSPECIALPRINTADJUSTMENT_B, LABEL_TYPE_TEXT, "AssistDlg_SpecialPrintAdjustmentB_label", N_("Special Print Adjustment B:"), "AssistDlg_SpecialPrintAdjustmentB_box", ID683 },
	{ ID_CTRLSELECTLINEWIDTH, LABEL_TYPE_TEXT, "AssistDlg_SelectLineWidth_label", N_("Select Line Width:"), "AssistDlg_SelectLineWidth_box", ID2373 },
	{ ID_CTRLSPECIALPRINTADJUSTMENT_SEPARATOR, -1, NULL, NULL, "AssistDlg_SpecialPrintAdjustment_separator", 0 },
	{ ID_CTRLSPECIALPRINTADJUSTMENT_D, LABEL_TYPE_BUTTON, "AssistDlg_SpecialPrintAdjustmentD_checkbutton", N_("Use Special Print Adjustment D"), "AssistDlg_SpecialPrintAdjustmentD_checkbutton", ID692 },
	{ ID_CTRLSPECIALPRINTADJUSTMENT_U, LABEL_TYPE_BUTTON, "AssistDlg_SpecialPrintAdjustmentU_checkbutton", N_("Use Special Print Adjustment U"), "AssistDlg_SpecialPrintAdjustmentU_checkbutton", ID662 },
	{ ID_CTRLSPECIALPRINTADJUSTMENT_I, LABEL_TYPE_BUTTON, "AssistDlg_SpecialPrintAdjustmentI_checkbutton", N_("Use Special Print Adjustment I"), "AssistDlg_SpecialPrintAdjustmentI_checkbutton", ID1722 },
	{ ID_CTRLSPECIALPRINTADJUSTMENT_J, LABEL_TYPE_BUTTON, "AssistDlg_SpecialPrintAdjustmentJ_checkbutton", N_("Use Special Print Adjustment J"), "AssistDlg_SpecialPrintAdjustmentJ_checkbutton", ID1732 },
	{ ID_CTRLSPECIALPRINTADJUSTMENT_K, LABEL_TYPE_BUTTON, "AssistDlg_SpecialPrintAdjustmentK_checkbutton", N_("Use Special Print Adjustment K"), "AssistDlg_SpecialPrintAdjustmentK_checkbutton", ID1742 },
	{ ID_CTRLSPECIALPRINTADJUSTMENT_G, LABEL_TYPE_BUTTON, "AssistDlg_SpecialPrintAdjustmentG_checkbutton", N_("Use Special Print Adjustment G"), "AssistDlg_SpecialPrintAdjustmentG_checkbutton", ID2402 },
	{ ID_CTRLSPECIALPRINTADJUSTMENT_Q, LABEL_TYPE_BUTTON, "AssistDlg_SpecialPrintAdjustmentQ_checkbutton", N_("Use Special Print Adjustment Q"), "AssistDlg_SpecialPrintAdjustmentQ_checkbutton", ID2412 },
	{ ID_CTRLSPECIALPRINTADJUSTMENT_T, LABEL_TYPE_BUTTON, "AssistDlg_SpecialPrintAdjustmentT_checkbutton", N_("Use Special Print Adjustment T"), "AssistDlg_SpecialPrintAdjustmentT_checkbutton", ID2392 },
	{ ID_CTRLSPECIALPRINTADJUSTMENT_L, LABEL_TYPE_BUTTON, "AssistDlg_SpecialPrintAdjustmentL_checkbutton", N_("Use Special Print Adjustment L"), "AssistDlg_SpecialPrintAdjustmentL_checkbutton", ID2422 },
	{ ID_CTRLPRINTQUIETMODE, LABEL_TYPE_BUTTON, "AssistDlg_PrintQuietMode_checkbutton", N_("Print in Quiet Mode"), "AssistDlg_PrintQuietMode_checkbutton", ID1122 },
	{ -1, -1, NULL, NULL, NULL, -1 }
};

UIAssistSettingDlg* CreateAssistSettingDlg( UIDialog* const parent)
{
	UIAssistSettingDlg *pDialog;

	pDialog = (UIAssistSettingDlg *)CreateDialog(sizeof(UIAssistSettingDlg), parent);

	if( UI_DIALOG(pDialog) != NULL )
	{
		UI_DIALOG(pDialog)->window = create_Assist_dialog();
	}
	return pDialog;
}

void ShowAssistSettingDlg( UIStatusWnd* const wnd )
{
	int nRet = 0;

	if( wnd == NULL )
	{
		return;
	}
	else
	{
		if( wnd->assist_dlg == NULL )
		{
			wnd->assist_dlg = CreateAssistSettingDlg( UI_DIALOG( wnd ) );
		}
		SigDisable();
		nRet = InitAssistSettingDlgWidgets( wnd );
		SigEnable();
	}

	if( nRet == 0 )
	{
		ShowDialog( (UIDialog *)wnd->assist_dlg, NULL );
	}
	else
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_GET );
		if( wnd->assist_dlg != NULL )
		{
			if( wnd->assist_dlg->pDialogDict != NULL )
			{
				DeleteDict( wnd->assist_dlg->pDialogDict );
				wnd->assist_dlg->pDialogDict = NULL;
			}
			mem_free( wnd->assist_dlg );
			wnd->assist_dlg = NULL;

		}
	}
}

UIComboBoxItem* comboboxInstance( const UIStatusWnd* const wnd, int inID )
{
	UIComboBoxItem* instance = NULL;
	switch(inID)
	{
	case ID673:
		instance = wnd->assist_dlg->pSpecialPrintAdjustmentVComboBoxItem;
		break;
	case ID2033:
		instance = wnd->assist_dlg->pSpecialPrintAdjustmentComboBoxItem;
		break;
	case ID683:
		instance = wnd->assist_dlg->pSpecialPrintAdjustmentBComboBoxItem;
		break;
	case ID2373:
		instance = wnd->assist_dlg->pSelectLineWidthComboBoxItem;
		break;
	}
	return instance;
}

unsigned int SetItemValuetypeCombobox( const UIStatusWnd* const wnd, CtrlTbl* temptabel )
{
	unsigned int unRet = 0;

	UIComboBoxItem* instance = comboboxInstance( wnd, temptabel->dbid );
	if( instance != NULL )
	{
		const char* pValue = GetComboBoxSelectedValue( instance );
		if( pValue != NULL )
		{
			unRet |= SetItemValuetype_char( wnd->assist_dlg->pDialogDict, temptabel->dbid, pValue );
			UI_DEBUG("SetItemValue_AssistSettingDlgOK(%s) unRet[%d]\n", temptabel->labeltext, unRet);
		}
	}

	return unRet;
}

unsigned int SetItemValuetypeCheckbox( const UIStatusWnd* const wnd, CtrlTbl* temptabel )
{
	unsigned int unRet = 0;

	int nValue = GetToggleButtonActive( wnd->assist_dlg->dialog.window, temptabel->labelname, FALSE );
	unRet |= SetItemValuetype_int( wnd->assist_dlg->pDialogDict, temptabel->dbid, nValue );
	UI_DEBUG("SetItemValue_AssistSettingDlgOK(%s) unRet[%d]\n", temptabel->labeltext, unRet);

	return unRet;
}

static unsigned int SetItemValue_AssistSettingDlgOK( const UIStatusWnd* const wnd )
{
	int i = 0;
	unsigned int unRet = 0;
	GtkWidget *pWindow = NULL;

	if( wnd == NULL )
	{
		UI_DEBUG("SetItemValue_AssistSettingDlgOK PPDCtrlTbl[%p] pWindow[%p]\n", PPDCtrlTbl, pWindow);
		return DICT_SET_RETURN_ERROR;
	}
	pWindow = wnd->assist_dlg->dialog.window;

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		CtrlTbl* targetCtrlTbl = PPDCtrlTbl[i];
		switch(targetCtrlTbl->labeltype)
		{
		case LABEL_TYPE_TEXT:
			unRet |= SetItemValuetypeCombobox( wnd, targetCtrlTbl );
			break;
		case LABEL_TYPE_BUTTON:
			unRet |= SetItemValuetypeCheckbox( wnd, targetCtrlTbl );
			break;
		default:
			break;
		}

		if( (unRet & DICT_SET_RETURN_ERROR) == DICT_SET_RETURN_ERROR )
		{
			break;
		}
	}
	return unRet;
}

void AssistSettingDlgOK( UIStatusWnd* const wnd )
{
	int nRet = 0;
	unsigned int unRet = 0;

	if( wnd == NULL )
	{
		return;
	}

	nRet = CreateDict_SetData( wnd->assist_dlg->pDialogDict );

	if( nRet == 0 )
	{
		unRet = SetItemValue_AssistSettingDlgOK( wnd );
		if( (unRet & DICT_SET_RETURN_ERROR) == DICT_SET_RETURN_ERROR )
		{
			nRet = -1;
		}
	}

	if( ( nRet == 0 ) && ( unRet == DICT_SET_RETURN_CHANGE ) )
	{
		nRet = CommunicatePrinterData( wnd, (UIDialog *)wnd->assist_dlg, wnd->assist_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	}

	HideDialog( (UIDialog *)wnd->assist_dlg );

	if( nRet != 0 )
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_SET );
	}

	return;
}

UIComboBoxItem* SetCtrlInstanceWithCreateComboBoxItem( const UIStatusWnd* const wnd, int inID )
{
	GtkWidget *pWindow = wnd->assist_dlg->dialog.window;

	UIComboBoxItem* instance = NULL;
	switch(inID)
	{
	case ID673:
		wnd->assist_dlg->pSpecialPrintAdjustmentVComboBoxItem =
				CreateComboBoxItem( pWindow, wnd->pModData, "CNSUISPModeVList", "AssistDlg_SpecialPrintAdjustmentV_combo", specialPrintAdjustmentContents );
		instance = wnd->assist_dlg->pSpecialPrintAdjustmentVComboBoxItem;
		break;
	case ID2033:
		wnd->assist_dlg->pSpecialPrintAdjustmentComboBoxItem =
				CreateComboBoxItem( pWindow, wnd->pModData, "CNSUISPModeList", "AssistDlg_SpecialPrintAdjustment_combo", specialPrintAdjustmentContents );
		instance = wnd->assist_dlg->pSpecialPrintAdjustmentComboBoxItem;
		break;
	case ID683:
		wnd->assist_dlg->pSpecialPrintAdjustmentBComboBoxItem =
				CreateComboBoxItem( pWindow, wnd->pModData, "CNSUISPModeBList", "AssistDlg_SpecialPrintAdjustmentB_combo", specialPrintAdjustmentContents );
		instance = wnd->assist_dlg->pSpecialPrintAdjustmentBComboBoxItem;
		break;
	case ID2373:
		wnd->assist_dlg->pSelectLineWidthComboBoxItem =
				CreateComboBoxItem( pWindow, wnd->pModData, "CNSUISelectLineWidthList", "AssistDlg_SelectLineWidth_combo", selectLineWidthContents );
		instance = wnd->assist_dlg->pSelectLineWidthComboBoxItem;
		break;
	}
	return instance;
}

int SetValueToComboBox( const UIStatusWnd* const wnd, CtrlTbl* temptabel )
{
	int nRet = 0;
	const char* pValue = NULL;
    UIComboBoxItem* instance = SetCtrlInstanceWithCreateComboBoxItem( wnd, temptabel->dbid );

	if( instance == NULL )
	{
		nRet = -1;
	}
	else
	{
		pValue = GetItemValueType_char( wnd->assist_dlg->pDialogDict, temptabel->dbid );
		if( pValue == NULL )
		{
			nRet = -1;
		}
		else
		{
			SetComboBoxSelectedValue(instance, pValue);
		}
	}

	return nRet;
}

void SetValueToCheckButton( const UIStatusWnd* const wnd, CtrlTbl* temptabel )
{
	GtkWidget *pWindow = wnd->assist_dlg->dialog.window;
	int nValue = 0;

	GetItemValueType_int( wnd->assist_dlg->pDialogDict, temptabel->dbid, &nValue );
	SetActiveCheckButton( pWindow, temptabel->ctrlbox , nValue, FALSE );
}

static int InitAssistSettingDlgWidgets( UIStatusWnd* const wnd )
{
	GtkWidget *pWindow = NULL;
	GList *pGlist = NULL;
	int i = 0;
	int nRet = 0;
	const char* const ctrl_type[ASSIST_CTRL_TYPE_NUM] = { "CNSUIAssistDlg", "CNSUICtrlAssistSetting", NULL };

	if( wnd == NULL )
	{
		return -1;
	}

	if( wnd->assist_dlg == NULL )
	{
		return -1;
	}
	else
	{
		pWindow = wnd->assist_dlg->dialog.window;
	}

	CreatePPDCtrlTbl( wnd, ctrl_type, ctrlTbl, PPDCtrlTbl );

	SetLabel_HideWidget( pWindow, PPDCtrlTbl, ctrlTbl );

	pGlist = CreateGlist_DbId( PPDCtrlTbl );

	if( wnd->assist_dlg->pDialogDict != NULL )
	{
		UI_DEBUG("pDialogDict no mem_free, from Func[%s] Line[%u] \n", __func__, __LINE__);
		DeleteDict( wnd->assist_dlg->pDialogDict );
	}
	wnd->assist_dlg->pDialogDict = CretateDict_GetData( pGlist );
	g_list_free_wrapper(pGlist);
	pGlist = NULL;

	if( wnd->assist_dlg->pDialogDict == NULL )
	{
		return -1;
	}

	nRet = CommunicatePrinterData( wnd, NULL, wnd->assist_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	if( nRet != 0 )
	{
		return -1;
	}

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
    	CtrlTbl* tempTable = PPDCtrlTbl[i];
		switch(PPDCtrlTbl[i]->labeltype)
		{
		case LABEL_TYPE_TEXT:
			nRet = SetValueToComboBox( wnd, tempTable );
			break;
		case LABEL_TYPE_BUTTON:
			SetValueToCheckButton( wnd, tempTable );
			break;
		default:
			break;
		}
	}
	return nRet;
}

void DisposeAssistDlg( UIStatusWnd* const wnd )
{
	UIAssistSettingDlg* ui_assist_dlg = NULL;

	if(wnd == NULL)
	{
		return;
	}

	ui_assist_dlg = wnd->assist_dlg;
	if( ui_assist_dlg != NULL )
	{
		if( ui_assist_dlg->pSpecialPrintAdjustmentVComboBoxItem != NULL )
		{
			DisposeComboBoxItem(ui_assist_dlg->pSpecialPrintAdjustmentVComboBoxItem);
			ui_assist_dlg->pSpecialPrintAdjustmentVComboBoxItem = NULL;
		}
		if( ui_assist_dlg->pSpecialPrintAdjustmentComboBoxItem != NULL )
		{
			DisposeComboBoxItem(ui_assist_dlg->pSpecialPrintAdjustmentComboBoxItem);
			ui_assist_dlg->pSpecialPrintAdjustmentComboBoxItem = NULL;
		}
		if( ui_assist_dlg->pSpecialPrintAdjustmentBComboBoxItem != NULL )
		{
			DisposeComboBoxItem(ui_assist_dlg->pSpecialPrintAdjustmentBComboBoxItem);
			ui_assist_dlg->pSpecialPrintAdjustmentBComboBoxItem = NULL;
		}
		if( ui_assist_dlg->pSelectLineWidthComboBoxItem != NULL )
		{
			DisposeComboBoxItem(ui_assist_dlg->pSelectLineWidthComboBoxItem);
			ui_assist_dlg->pSelectLineWidthComboBoxItem = NULL;
		}

		if( ui_assist_dlg->pDialogDict != NULL )
		{
			DeleteDict( ui_assist_dlg->pDialogDict );
			ui_assist_dlg->pDialogDict = NULL;
		}
		DisposeDialog( (UIDialog *)ui_assist_dlg );
		wnd->assist_dlg = NULL;
	}
}

