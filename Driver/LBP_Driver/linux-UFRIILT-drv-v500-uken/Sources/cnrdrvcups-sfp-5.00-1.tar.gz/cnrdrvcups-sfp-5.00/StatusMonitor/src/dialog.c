/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */



#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "dialog.h"
#include "widgets.h"

#define WND_SIZE_DIV 2

UIDialog* CreateDialog(int size, UIDialog *parent)
{
	UIDialog *dialog;

	dialog = (UIDialog *)mem_alloc((unsigned int)size, __FILE__, __LINE__);

	dialog->window = NULL;
	dialog->parent = (void *)parent;

	dialog->size = size;

	return dialog;
}

void DisposeDialog(UIDialog *dialog)
{
	if( dialog != NULL )
	{
		gtk_main_quit();
		mem_free(dialog);
	}
}

void ShowDialog(UIDialog *dialog, gchar *def_widget_name)
{
	GtkWindow *pParentWnd = NULL;
	GtkWindow *pChildWnd = NULL;
	int px = 0, py = 0, pw = 0, ph = 0,
	    cw = 0, ch = 0,
	    mx = 0, my = 0;

	if(dialog == NULL)
	{
		return;
	}

	if( dialog->parent == NULL )
	{
		return;
	}

	pParentWnd = GTK_WINDOW(dialog->parent->window);
	pChildWnd = GTK_WINDOW(dialog->window);

	if( (pParentWnd != NULL) && (pChildWnd != NULL) )
	{
		gtk_window_set_transient_for( pChildWnd, pParentWnd );

		gtk_window_get_position( pParentWnd, &px, &py );
		gtk_window_get_size( pParentWnd, &pw, &ph );
		gtk_window_get_size( pChildWnd, &cw, &ch );

		mx = (px + (pw / WND_SIZE_DIV)) - (cw / WND_SIZE_DIV);
		my = (py + (ph / WND_SIZE_DIV)) - (ch / WND_SIZE_DIV);

		gtk_window_move( pChildWnd, mx, my);

		if(def_widget_name){
			GtkWidget *widget;
			if(strcmp(def_widget_name, "MainOK_button") == 0)
				widget = getWidget(dialog->parent->parent->window, def_widget_name);
			else
				widget = getWidget(dialog->parent->window, def_widget_name);
			if(widget != NULL){
				gtk_widget_grab_focus(widget);
				gtk_widget_grab_default(widget);
			}
		}
	}
	gtk_widget_show(dialog->window);
	gtk_main();
}

void HideDialog(UIDialog *dialog)
{
	GtkWidget *top;
	if(dialog == NULL)
		return;
	top = gtk_widget_get_toplevel(dialog->window);
	gtk_widget_hide(top);
	gtk_widget_destroy( dialog->window );
}


