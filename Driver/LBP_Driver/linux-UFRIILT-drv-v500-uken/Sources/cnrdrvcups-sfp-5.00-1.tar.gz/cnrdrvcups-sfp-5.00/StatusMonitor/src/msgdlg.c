/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>

#include "uimain.h"
#include "widgets.h"
#include "interface.h"
#include "msgdlg.h"
#include "support.h"

#include "commandcontroller.h"
#include "value_defines.h"

#include "callbacks.h"

#include "key_defines.h"


void UpdateMsgDlgWidgets(UIStatusWnd *wnd, int type);
static int SendRequest_DeviceOperation( UIStatusWnd* const wnd, const int nOperation, const int err_msg );

typedef struct{
	int type;
	char *message;
	char *title;
	int btn_type;
	int width;
	int height;
}MsgTable;

static MsgTable msg_table[] = {
	{ID_CALIBRATION_MSGDLG1, N_("Performs Calibration."), N_("Calibration"), BTN_TYPE_OKCANCEL, -1, -1},
	{ID_COLORMISMATCHCORRECTION_MSGDLG1, N_("Performs Color Mismatch Correction."), N_("Color Mismatch Correction"), BTN_TYPE_OKCANCEL, -1, -1},
    {ID_CLEANING_MSGDLG, N_("Performs Cleaning.\nCheck that the correct size paper is loaded in the paper source, and then click [OK].\nSee the instruction manual for more information about paper sizes."), N_("Cleaning"), BTN_TYPE_OKCANCEL, -1, -1},
	{ID_CLEANING_MSGDLGMPTRAY, N_("Performs Cleaning.\nLoad the correct size paper in the Multi-Purpose Tray, and then click [OK].\nSee the instruction manual for more information about paper sizes."), N_("Cleaning"), BTN_TYPE_OKCANCEL, -1, -1},
	{ID_CLEANING_MSGDLG1, N_("Performs Cleaning 1.\nCheck that the correct size paper is loaded in the paper source, and then click [OK].\nSee the instruction manual for more information about paper size."), N_("Cleaning 1"), BTN_TYPE_OKCANCEL, -1, -1},
	{ID_CLEANING_MSGDLG2, N_("Performs Cleaning 2."), N_("Cleaning 2"), BTN_TYPE_OKCANCEL, -1, -1},
	{ID_USBWAIT_MSGDLG1, N_("Wait a moment."), N_(" "), BTN_TYPE_NONE, -1, -1},
	{ID_USERDATALIST_MSGDLG1, N_("Output the User Data List."), N_("User Data List"), BTN_TYPE_OKCANCEL, -1, -1},
	{ID_PCLFONTLIST_MSGDLG1, N_("Output the PCL Font List."), N_("PCL Font List"), BTN_TYPE_OKCANCEL, -1, -1},
	{ID_UPDATINGFIRMWAREMODE_MSGDLG1, N_(" "), N_(" "), BTN_TYPE_OKCANCEL, 540, -1},
	{ID_CALIBRATION_ERR, N_("Could not perform Calibration."), N_(" "), BTN_TYPE_OK, -1, -1},
	{ID_COLORMISMATCHCORRECTION_ERR, N_("Could not perform Color Mismatch Correction."), N_(" "), BTN_TYPE_OK, -1, -1},
	{ID_CLEANING_ERR, N_("Could not perform cleaning.\nCheck the connection to the printer and the printer status, and then try again."), N_(" "), BTN_TYPE_OK, -1, -1},
	{ID_USERDATALIST_ERR, N_("Could not print the User Data List."), N_(" "), BTN_TYPE_OK, -1, -1},
	{ID_PCLFONTLIST_ERR, N_("Could not print the PCL Font List."), N_(" "), BTN_TYPE_OK, -1, -1},
	{ID_UPDATINGFIRMWAREMODEENTER_ERR, N_("Could not enter firmware update mode."), N_(" "), BTN_TYPE_OK, -1, -1},
	{ID_UPDATINGFIRMWAREMODECANCEL_ERR, N_("Could not cancel firmware update mode."), N_(" "), BTN_TYPE_OK, -1, -1},
	{ID_HIDE_MONITOR, N_("Hides Statusmonitor window."), N_("Hide Statusmonitor"), BTN_TYPE_OKCANCEL, -1, -1},
	{ID_COMMUNICATION_ERR_SET, N_("Could not configure the printer settings with the specified information."), N_(" "), BTN_TYPE_OK, -1, -1},
	{ID_COMMUNICATION_ERR_GET, N_("Could not retrieve the printer information."), N_(" "), BTN_TYPE_OK, -1, -1},
	{ID_CONSUMABLEINFO_ERR_GET, N_("Could not retrieve information about the amount of consumables remaining."), N_(" "), BTN_TYPE_OK, -1, -1},
	{ID_COUNTERINFO_ERR_GET, N_("Could not retrieve the print counter information."), N_(" "), BTN_TYPE_OK, -1, -1},
	{ID_AUTOSELECT_ERR, N_("Select at least one paper source for [Paper Sources to Auto Select]."), N_(" "), BTN_TYPE_OK, -1, -1},

	{ID_UPDATINGFIRMWAREMODEENTER_MSG, N_("Enter firmware update mode."), N_("Enter/Cancel Firmware Update Mode"), BTN_TYPE_OKCANCEL, -1, -1},
	{ID_UPDATINGFIRMWAREMODECANCEL_MSG, N_("Cancel firmware update mode."), N_("Enter/Cancel Firmware Update Mode"), BTN_TYPE_OKCANCEL, -1, -1},

	{-1, NULL, NULL, -1, -1, -1},
};

static int SendRequest_DeviceOperationIntParam( UIStatusWnd* const wnd, const int nOperation, const int nParam, const int err_msg );

static const MsgTable *GetMessageTable(int type);

UIMsgDlg* CreateMsgDlg(UIDialog *parent)
{
	UIMsgDlg *dialog;

	dialog = (UIMsgDlg *)CreateDialog(sizeof(UIMsgDlg), parent);

	UI_DIALOG(dialog)->window = create_Msg_dialog();

	return dialog;
}

void ShowMsgDlg(UIStatusWnd *wnd, int type)
{
	ShowChildMsgDlg(wnd, NULL, type);
}

void ShowChildMsgDlg(UIStatusWnd* const wnd, UIDialog *parent, const int type)
{
	if( wnd == NULL )
	{
		return;
	}

	if(parent == NULL)
	{
		parent = UI_DIALOG(wnd);
	}

	wnd->msg_dlg = CreateMsgDlg(parent);

	SigDisable();
	UpdateMsgDlgWidgets(wnd, type);
	SigEnable();

	gtk_window_set_transient_for(
		GTK_WINDOW(UI_DIALOG(wnd->msg_dlg)->window),
		GTK_WINDOW(UI_DIALOG(wnd->msg_dlg)->parent->window));

	switch(type){
	default:
		ShowDialog((UIDialog *)wnd->msg_dlg, NULL);
		break;
	}
}

void MsgDlgOK(UIStatusWnd *wnd)
{
	switch( wnd->msg_dlg->type )
	{
	case ID_CALIBRATION_MSGDLG1:
		SendRequest_DeviceOperation( wnd,
											DEVICE_OPERATION_CALIBRATION,
											ID_CALIBRATION_ERR );
		break;
	case ID_COLORMISMATCHCORRECTION_MSGDLG1:
		SendRequest_DeviceOperation( wnd,
											DEVICE_OPERATION_CPR,
											ID_COLORMISMATCHCORRECTION_ERR );
		break;
    case ID_CLEANING_MSGDLG:
	case ID_CLEANING_MSGDLGMPTRAY:
    {
        int  cleaningID = 0;
        if( GetPPDValue_Integer( wnd->pModData, "CNSUICleaningOperationID", &cleaningID) == FALSE )
        {
            HideMsgDlg(wnd);
            ShowMsgDlg( wnd, ID_CLEANING_ERR );
        }
        else
        {
            SendRequest_DeviceOperation( wnd,
                                                cleaningID,
                                                ID_CLEANING_ERR );
        }
    }
        break;
	case ID_CLEANING_MSGDLG1:
		SendRequest_DeviceOperation( wnd,
											DEVICE_OPERATION_FUSER_CLEANING,
											ID_CLEANING_ERR );
		break;
	case ID_CLEANING_MSGDLG2:
		SendRequest_DeviceOperation( wnd,
											DEVICE_OPERATION_ITBCLEANING,
											ID_CLEANING_ERR );
		break;
    case ID_USERDATALIST_MSGDLG1:
		SendRequest_DeviceOperationIntParam( wnd,
                                            DEVICE_OPERATION_LISTPRINT,
                                            PRINT_USERDATA,
                                            ID_USERDATALIST_ERR );
        break;
    case ID_PCLFONTLIST_MSGDLG1:
		SendRequest_DeviceOperationIntParam( wnd,
                                            DEVICE_OPERATION_LISTPRINT,
                                            PRINT_PCLFONT,
                                            ID_PCLFONTLIST_ERR );
        break;
    case ID_UPDATINGFIRMWAREMODE_MSGDLG1:
		{
			int nParam = FIRMUPDATEMODE_SHIFT;
			int err_msg = ID_UPDATINGFIRMWAREMODEENTER_ERR;

			if (wnd->msg_dlg->messageType == ID_UPDATINGFIRMWAREMODECANCEL_MSG)
			{
				nParam = FIRMUPDATEMODE_CANCEL;
				err_msg = ID_UPDATINGFIRMWAREMODECANCEL_ERR;
			}

			SendRequest_DeviceOperationIntParam( wnd,
												DEVICE_OPERATION_CHANGEFIRMWAREUPDATEMODE,
												nParam,
												err_msg );
        }
		break;
	case ID_HIDE_MONITOR:
		HideMsgDlg(wnd);
		HideMonitor(wnd);
		break;
	default:
		HideMsgDlg(wnd);
		break;
	}
}

void MsgDlgCancel(UIStatusWnd *wnd)
{
	HideMsgDlg(wnd);
}

void HideMsgDlg(UIStatusWnd *wnd)
{
	switch(wnd->msg_dlg->type){
	default:
		HideDialog((UIDialog *)wnd->msg_dlg);
		break;
	}
}

void DisposeMsgDlg( UIStatusWnd* const wnd )
{
	if( wnd != NULL )
	{
		DisposeDialog((UIDialog *) wnd->msg_dlg );
		wnd->msg_dlg = NULL;
	}
}

void UpdateMsgDlgWidgets(UIStatusWnd *wnd, int type)
{
	GtkWidget *window = UI_DIALOG(wnd->msg_dlg)->window;
	int i = 0;
	int messageType = -1;

	while(msg_table[i].type != -1){
		if(type == msg_table[i].type){
			GtkObject *pObject = GTK_OBJECT(window);
			GtkSignalFunc deleteEventFunc = GTK_SIGNAL_FUNC(on_Msg_dialog_delete_event);

			const char *title = msg_table[i].title;
			const char *message = msg_table[i].message;
			const int width = msg_table[i].width;
			const int height = msg_table[i].height;

			switch(type){
			case ID_UPDATINGFIRMWAREMODE_MSGDLG1:
				{
					const MsgTable *messageTable = NULL;

					messageType = ID_UPDATINGFIRMWAREMODEENTER_MSG;

					EnterCriticalSection(&g_StatusSection);
					{
						const char *status = GetDictValueString_forKey(wnd->pStatusDict, KEY_STATUS);
						if( status != NULL )
						{
							if( strcmp(status, SCODE_UPDATINGFIRMWAREMODE) == 0 )
							{
								messageType = ID_UPDATINGFIRMWAREMODECANCEL_MSG;
							}
						}
					}
					LeaveCriticalSection(&g_StatusSection);

					messageTable = GetMessageTable(messageType);
					if( messageTable != NULL )
					{
						title = messageTable->title;
						message = messageTable->message;
					}
				}
				break;
			default:
				break;
			}

			gtk_widget_set_size_request(window, width, height);

			SetDialogTitle(window, _(title));
			SetTextToLabel(window, "MsgDlg_label", _(message));

			switch(msg_table[i].btn_type){
			case BTN_TYPE_NONE:
				HideWidget(window, "MsgDlg_OK_button");
				HideWidget(window, "MsgDlg_Cancel_button");
				GtkWindow *pWindow = GTK_WINDOW(window);
				if(pWindow != NULL)
				{
					gtk_window_set_decorated(pWindow, FALSE);
				}
				if(pObject != NULL)
				{
					gtk_signal_connect( pObject, "show",
				    	                GTK_SIGNAL_FUNC( on_Msg_USBRetry_dialog_show ), NULL);
				}
				deleteEventFunc = GTK_SIGNAL_FUNC(on_Msg_dialog_delete_event_btn_none);
				break;
			case BTN_TYPE_OK:
				HideWidget(window, "MsgDlg_Cancel_button");
				break;
			case BTN_TYPE_CANCEL:
				HideWidget(window, "MsgDlg_OK_button");
				break;
			}
			if(pObject != NULL)
			{
				gtk_signal_connect( pObject, "delete_event", deleteEventFunc, NULL);
			}
			wnd->msg_dlg->type = type;
			wnd->msg_dlg->messageType = messageType;
			break;
		}
		i++;
	}
}

static int SendRequest_DeviceOperation( UIStatusWnd* const wnd, const int nOperation, const int err_msg )
{
	int nRet = 0;
	Dict* pDict = NULL;

	HideMsgDlg(wnd);

	pDict = CreateDict_DeviceOperation( nOperation );
	if( pDict == NULL )
	{
	  	nRet = -1;
	}

	if( nRet == 0 )
	{
		nRet = CommunicatePrinterData( wnd, NULL, pDict, CODE_COMMAND_ANALYZE, TRUE );
	}

	if( nRet != 0 )
	{
		ShowMsgDlg( wnd, err_msg );
	}

	if( pDict != NULL )
	{
		DeleteDict( pDict );
	}

	return nRet;
}

static int SendRequest_DeviceOperationIntParam( UIStatusWnd* const wnd, const int nOperation, const int nParam, const int err_msg )
{
	int nRet = 0;
	Dict* pDict = NULL;

	HideMsgDlg(wnd);

	pDict = CreateDict_DeviceOperationIntParam( nOperation, nParam );
	if( pDict == NULL )
	{
	  	nRet = -1;
	}

	if( nRet == 0 )
	{
		nRet = CommunicatePrinterData( wnd, NULL, pDict, CODE_COMMAND_ANALYZE, TRUE );
	}

	if( nRet != 0 )
	{
		ShowMsgDlg( wnd, err_msg );
	}

	if( pDict != NULL )
	{
		DeleteDict( pDict );
	}

	return nRet;
}

static const MsgTable *GetMessageTable(int type)
{
	const MsgTable *msgTable = NULL;
	int i = 0;

	for( i = 0; msg_table[i].type != -1; i++ )
	{
		if( msg_table[i].type == type )
		{
			msgTable = &msg_table[i];
			break;
		}
	}
	return msgTable;
}
