/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */



#ifndef _UIMAIN
#define _UIMAIN

#include <pthread.h>
#include "buftool.h"
#include <libxml/parser.h>
#include "pksmncapcontroller.h"
#include "dialog.h"
#include "msgdlg.h"
#include "cngplpmod.h"
#include "sleepsdlg.h"
#include "cancelkeydlg.h"
#include "dictcontroller.h"
#include "overridedlg.h"
#include "disablewifidlg.h"
#include "assistdlg.h"
#include "consumablesdlg.h"
#include "counterdlg.h"
#include "wlanstatusdlg.h"
#include "autoshutdowndlg.h"
#include "imgadjustdlg.h"
#include "pfeedunitdlg.h"
#include "warningdisplaydlg.h"
#include "warningdetailsdlg.h"
#include "mobileprintdlg.h"
#include "papersizecheckdlg.h"
#include "reportprintdlg.h"
#include "switchpaperfeeddlg.h"
#include "purchaseconsumables_scr_dlg.h"

#if 0
#ifdef _UI_DEBUG
#define UI_DEBUG(fmt, args...) fprintf( stderr,"UI >> " fmt, ##args)
#else
#define UI_DEBUG(fmt, args...)
#endif
#endif

typedef struct{
	xmlDocPtr pDocPtr;
	xmlNodePtr pRootNodePtr;
}SMXmlContext;

struct _UIStatusWnd {
	UIDialog dialog;
	cngplpData *pModData;
	char *pPrinterName;
	char *host_name;
	int socket_fd;
	int mode;
	int exit;
	int retry;
	unsigned int nStatusThreadSleepTime;
	gboolean bPoollingStop;

	gboolean pauseGetStatus;

	char *locale;
	char *encoding;

	UIMsgDlg *msg_dlg;

	UISleepSettingDlg *sleeps_dlg;
	UICancelJobKeyDlg *cancelkey_dlg;
	UIOverrideDlg *override_dlg;
	UIDisableWiFiDlg *disablewifi_dlg;
	UIAssistSettingDlg *assist_dlg;
	UIConsumablesDlg *consumables_dlg;
	UICounterDlg *counter_dlg;
	UIWLANStatusDlg *wlanstatus_dlg;
	UIAutoShutdownDlg *autoshutdown_dlg;
	UIImgAdjustDlg *imgadjust_dlg;
	UIPfeedUnitDlg *pfeedunit_dlg;
	UIWarningDisplayDlg *warningdisplay_dlg;
	UIWarningDetailsDlg *warningdetails_dlg;
	UIMobilePrintDlg *mobileprint_dlg;
	UIPaperSizeCheckDlg *papersizecheck_dlg;
	UIReportPrintDlg *reportprint_dlg;
	UISwitchPaperFeedDlg *switchpaperfeed_dlg;
	UIPurchaseConsumables_scr_dlg*	purchaseconsumables_scr_dlg;

	gboolean enableJobOperate;

	int nModel;
	int nic_flag;

	int nIFVersion;
	int nLangType;
	char *data_path;
	char pAlertCode[128];
	int isJobDisable;

	Mngpksmncap *pMngpksmncap;
	int nPortNum;
	int nMaxUSBRetrySec;
	char *pDriverPath;
	Dict *pStatusDict;

	SMXmlContext *pMsgXmlContext;
	gboolean isHideNowWnd;
	int nShowDlgCnt;

	char *pPDLType;

	char *pAreaInfo;
};

UIStatusWnd *g_status_window;

enum {
	ID_STR_UNKNOWN_ERROR,
	ID_STR_NOPRINTER,
	ID_STR_PRINTER_ERROR,
	ID_STR_FIFO_ERROR,
	ID_STR_PRINTER_ENTRY,
	ID_STR_DEVICE_PATH,
	ID_STR_DEVICE_URI
};

#define	LANG_TYPE_JP	1
#define	LANG_TYPE_UK	2
#define	LANG_TYPE_US	3
#define LANG_TYPE_US_STR	"US"

#define CHARACTER_COMMA ','
#define STRING_NEWLINE "\n"
#define STRING_NEWLINE_TAB "\n\t"
#define XMLGETSTRINGINLINE 1
#define STRING_UNDERLINE "_"

#define SUPPORTEDPRINTER_KEY		"ModelCode_SupportedPrinter"

#define	MAX_BUF_SIZE	255

#define NULL_CHAR_SIZE 1U


char* cngplpGetValue_Wrapper(cngplpData * const data, const char * const key);
int buftool_write_string_Wrapper(BufTool * const buf_tool, const char * const data, const int bytes);

typedef pthread_mutex_t CRITICAL_SECTION;
void InitializeCriticalSection( CRITICAL_SECTION* const section );
int EnterCriticalSection( CRITICAL_SECTION* const section );
int LeaveCriticalSection( CRITICAL_SECTION* const section );
int DeleteCriticalSection( CRITICAL_SECTION* const section );
CRITICAL_SECTION g_StatusSection;
CRITICAL_SECTION g_USBRetrySection;
CRITICAL_SECTION g_CommuticateSection;


SMXmlContext *xmlContextCreate( const char* const pXmlPath );
char* xmlGetString( const SMXmlContext* const pXmlContext, const char* const pKeyName );
void xmlContextDestory( SMXmlContext** const ppXmlContext );

UIStatusWnd *CreateStatusWnd(char * const printer_name, int mode);
void UpdateWidgets(UIStatusWnd *wnd);
void UpdateWidgets2(UIStatusWnd *wnd);
void DataProc(gpointer data);
void DisposeStatusWnd(UIStatusWnd *wnd);
void ShowMsgDlg(UIStatusWnd *wnd, int type);
void ShowChildMsgDlg(UIStatusWnd* const wnd, UIDialog *parent, const int type);
void HideMsgDlg(UIStatusWnd *wnd);
void MsgDlgOK(UIStatusWnd *wnd);
void MsgDlgCancel(UIStatusWnd *wnd);
int UpdateJob(long job_num);
void HideMonitor(UIStatusWnd *wnd);
int GetCtrlIdList( const UIStatusWnd* const wnd, const char* const key, int* const pCtrlList );
int GetMsgId( const UIStatusWnd* const wnd, const char* const key, const int default_id );
char* GetStrText(const CtrlTbl* const list, const int ctrlid);
gboolean GetJobID( const UIStatusWnd* const wnd, int* const nJobId );
void CreatePPDCtrlTbl( const UIStatusWnd* const wnd, const char* const * const ctrl_type, CtrlTbl* const ctrlTbl, CtrlTbl** const PPDCtrlTbl );
GList* CreateGlist_DbId( CtrlTbl* const * const PPDCtrlTbl );
void SetLabel_HideWidget( GtkWidget* const window, CtrlTbl** const PPDCtrlTbl, const CtrlTbl* const ctrlTbl );

void SetAreaInfo(UIStatusWnd* const wnd, const char *pAareaInfo);
const char *GetAreaInfo(const UIStatusWnd* const wnd);
void ClearAreaInfo(UIStatusWnd* const wnd);

GList* g_list_alloc_wrapper( const char* pFunc, unsigned int nLine );
GList* g_list_append_wrapper( GList* const pGList, void* const pValue, const char* pFunc, unsigned int nLine );
GList* g_list_concat_wrapper( GList* pGList1, GList* const pGList2, const char* pFunc, unsigned int nLine );
GList* g_list_delete_link_wrapper( GList* pBaseGList, GList* const pDeleteGList, const char* pFunc, unsigned int nLine );
GList* g_list_copy_wrapper( GList* const pGList, const char* pFunc, unsigned int nLine );
void g_list_free_wrapper( GList* const pGList );
void g_list_quit_alloc();
GString* g_string_new_wrapper( const char* const pStr, const char* pFunc, unsigned int nLine );
void g_string_free_wrapper( GString* const pGString, const gboolean bSegmentFree );
void g_string_quit_alloc();
void* mem_alloc(const size_t size, const char* pFunc, unsigned int nLine);
char* mem_strudup( const char* const pointer, const char* pFunc, unsigned int nLine );
void mem_free(void* const pointer);
void mem_free_list(char** const pointer);
void mem_quit_alloc();


void ShowCancelJobKeyDlg( UIStatusWnd * const wnd );
void CancelJobKeyDlgOK(UIStatusWnd * const wnd);
void ShowSleepSettingDlg( UIStatusWnd * const wnd );
void SleepSettingDlgOK( UIStatusWnd * const wnd );
void UpdateSleepSettingDlgWidgets(const UIStatusWnd * const wnd, const int use_sleep);
void ShowOverrideDlg( UIStatusWnd * const wnd );
void OverrideDlgOK( UIStatusWnd * const wnd );
void ShowDisableWiFiDlg( UIStatusWnd * const wnd );
void DisableWiFiDlgOK( UIStatusWnd * const wnd );
void ShowAssistSettingDlg( UIStatusWnd * const wnd );
void AssistSettingDlgOK( UIStatusWnd * const wnd );
void ShowConsumablesDlg( UIStatusWnd * const wnd );
void ShowCounterDlg( UIStatusWnd * const wnd );
void AddCtrlData( int id, CtrlTbl *ctrlTbl, CtrlTbl **ppdCtrlTbl );
gboolean isLocaleJapanese( const UIStatusWnd* const wnd );
void ShowWLANStatusDlg( UIStatusWnd * const wnd );
void ShowAutoShutdownDlg( UIStatusWnd * const wnd );
void AutoShutdownDlgOK( UIStatusWnd * const wnd );
void UpdateAutoShutdownDlgWidgets(const UIStatusWnd * const wnd, int use_autoshutdown);
void ShowImgAdjustDlg( UIStatusWnd * const wnd );
void ImgAdjustDlgOK( UIStatusWnd * const wnd );
void UpdateImgAdjustDlgWidgets(const UIStatusWnd * const wnd, const int enable_calibration);
void ShowPfeedUnitSettingDlg( UIStatusWnd * const wnd );
void PfeedUnitSettingDlgOK( UIStatusWnd * const wnd );
void UpdatePFeedUnitDlgChangeFeedCtrl( const UIStatusWnd * const wnd, const int nIndex, const char* const pCtrl );

void DisposeMsgDlg( UIStatusWnd* const wnd );
void DisposeAssistDlg( UIStatusWnd* const wnd );
void DisposeAutoShutdownDlg( UIStatusWnd* const wnd );
void DisposeJobCancelKeyDlg( UIStatusWnd* const wnd );
void DisposeCounterDlg( UIStatusWnd* const wnd );
void DisposeConsumablesDlg( UIStatusWnd* const wnd );
void DisposeDisableWifiDlg( UIStatusWnd* const wnd );
void DisposeImgAdjustDlg( UIStatusWnd* const wnd );
void DisposeOverRideDlg( UIStatusWnd* const wnd );
void DisposePFeedUnitDlg( UIStatusWnd* const wnd );
void DisposeSleepSettingDlg( UIStatusWnd* const wnd );
void DisposeWlansStatusDlg( UIStatusWnd* const wnd );


#endif


