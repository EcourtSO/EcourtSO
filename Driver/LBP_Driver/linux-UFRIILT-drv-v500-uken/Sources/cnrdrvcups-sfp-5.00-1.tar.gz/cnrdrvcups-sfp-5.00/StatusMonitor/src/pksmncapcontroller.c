/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#include <signal.h>
#include <wait.h>

#include "uimain.h"
#include "pksmncapcontroller.h"
#include "buftool.h"


#define CMD_PIPE_STR "--cmd_fd=%d"
#define RES_PIPE_STR "--res_fd=%d"

#define PKSM_MODULE_PATH "Utilities"
#define PKSM_MODULE_NAME "pksmncapr"

#define CMD_HEADER_SIZE		4
#define CMD_RESPONSE_SIZE		6

#define CMD_PIPE_OPT_ARRAY 32
#define COMMAND_PIPE_ARRAY 2

#define NUM_OF_SLASH 2

enum{
	MODULE_ARG_POS_0 = 0,
	MODULE_ARG_POS_1,
	MODULE_ARG_POS_2,
	MODULE_ARG_POS_3,
	MODULE_ARG_COUNT
};

static int pksmncapCreateProcess_execv( const int nCmdpipe, const int nRespipe, const char* const pDriverPath );
static int pksmncapCreateProcess_pipe( Mngpksmncap* const pMngpksm, const char* const pDriverPath );
static int WritePipe( const int fdPipe, char* const pData, const int nDataSize );
static int ReadPipe( const  int fdPipe, char* const pData, const int nDataSize );
static short pksmncapRead_readheader( const int fds, short* const pCmdID, short* const pDataSize );

static int pksmncapCreateProcess_execv( const int nCmdpipe, const int nRespipe, const char* const pDriverPath )
{
	char cmdpipe_opt[CMD_PIPE_OPT_ARRAY] = {0};
	char respipe_opt[CMD_PIPE_OPT_ARRAY] = {0};
	char* module_arg[MODULE_ARG_COUNT] = {0};
	char* module_path = NULL;
	unsigned int nSize = 0;
	int nRet = -1;

	snprintf(cmdpipe_opt, (sizeof(cmdpipe_opt) - 1), CMD_PIPE_STR, nCmdpipe);
	snprintf(respipe_opt, (sizeof(respipe_opt) - 1), RES_PIPE_STR, nRespipe);

	const unsigned int numOfSlash = NUM_OF_SLASH;
	nSize = strlen(pDriverPath) + strlen(PKSM_MODULE_PATH) + strlen(PKSM_MODULE_NAME) + numOfSlash + 1u;
	module_path = (char*)mem_alloc(nSize, __FILE__, __LINE__);


	const unsigned int nDriverPathLen = strlen(pDriverPath);
	const unsigned int nPkamModulePathLen = strlen(PKSM_MODULE_PATH);
 	const unsigned int nPkamModuleNameLen = strlen(PKSM_MODULE_NAME);
	strncpy(module_path, pDriverPath, nDriverPathLen);
	strcat(module_path, "/");
	strncat(module_path, PKSM_MODULE_PATH, nPkamModulePathLen);
	strcat(module_path, "/");
	strncat(module_path, PKSM_MODULE_NAME, nPkamModuleNameLen);

	module_arg[MODULE_ARG_POS_0] = module_path;
	module_arg[MODULE_ARG_POS_1] = cmdpipe_opt;
	module_arg[MODULE_ARG_POS_2] = respipe_opt;
	module_arg[MODULE_ARG_POS_3] = NULL;

	nRet = execv(module_path, module_arg);
	mem_free(module_path);
	if( nRet == -1 )
	{
		UI_DEBUG("%s execv error, from Line[%u] \n", __func__, __LINE__);
		exit(nRet);
	}

	return nRet;
}

static int pksmncapCreateProcess_pipe( Mngpksmncap* const pMngpksm, const char* const pDriverPath )
{
	int command_pipe[COMMAND_PIPE_ARRAY] = {0};
	int response_pipe[COMMAND_PIPE_ARRAY] = {0};
	int nPid = 0;
	int nRet = -1;

	if( (pMngpksm == NULL) || (pDriverPath == NULL) )
	{
		return nRet;
	}
	if( pipe(command_pipe) == -1 )
	{
		return nRet;
	}

	if( pipe(response_pipe) == -1 )
	{
		close(command_pipe[0]);
		close(command_pipe[1]);
		return nRet;
	}

	nPid = fork();
	if( nPid == -1 )
	{
		UI_DEBUG("%s fork error, from Line[%u] \n", __func__, __LINE__);
	}
	else if( nPid == 0 )
	{
		close(command_pipe[1]);
		close(response_pipe[0]);
		nRet = pksmncapCreateProcess_execv(command_pipe[0], response_pipe[1], pDriverPath);
	}
	else
	{
		close(command_pipe[0]);
		close(response_pipe[1]);
		nRet = 0;
	}

	if( nRet == -1 )
	{
		close(command_pipe[0]);
		close(command_pipe[1]);
		close(response_pipe[0]);
		close(response_pipe[1]);
	}
	else
	{
		pMngpksm->pid = nPid;
		pMngpksm->cmd_fd = command_pipe[1];
		pMngpksm->res_fd = response_pipe[0];
	}

	return nRet;
}

Mngpksmncap* pksmncapCreateProcess( const char* const pDriverPath )
{
	Mngpksmncap* pMngpksm = NULL;
	int nRet = -1;

	if( pDriverPath == NULL )
	{
		return NULL;
	}

	pMngpksm = (Mngpksmncap*)mem_alloc(sizeof(Mngpksmncap), __FILE__, __LINE__);
	nRet = pksmncapCreateProcess_pipe(pMngpksm, pDriverPath);
	if( nRet == -1 )
	{
		mem_free(pMngpksm);
		return NULL;
	}

	return pMngpksm;
}

static int WritePipe( const int fdPipe, char* const pData, const int nDataSize )
{
	int write_size = 0;
	char* pTemp = pData;
	int total_size = nDataSize;
	int nRet = 0;

	if( pData == NULL )
	{
		return -1;
	}

	while( total_size > 0 )
	{
		write_size = write(fdPipe, pTemp, (unsigned int)total_size);
		if( write_size == -1 )
		{
			nRet = -1;
			break;
		}
		total_size -= write_size;
		pTemp += write_size;
	}

	return nRet;
}

static int ReadPipe( const  int fdPipe, char* const pData, const int nDataSize )
{
	int read_size = 0;
	int total_size = nDataSize;
	int nRet = 0;
	char* pTemp = pData;

	while( total_size > 0 )
	{
		read_size = read(fdPipe, pTemp, (unsigned int)total_size);
		if( read_size == -1 )
		{
			nRet = -1;
			break;
		}
		total_size -= read_size;
		pTemp += read_size;
	}

	return nRet;
}

int pksmncapWrite( const int fds, const int nCmdID, char* const pData, const int nDataSize )
{
	int nRet = -1;
	const int write_size = CMD_HEADER_SIZE + nDataSize;

	BufTool* const buftool = buftool_new(write_size, BUFTOOL_LITTLE_ENDIAN);
	if( buftool != NULL )
	{
		buftool_write_short(buftool, (short)nCmdID);
		buftool_write_short(buftool, (short)nDataSize);
		if( pData != NULL )
		{
			buftool_write(buftool, pData, nDataSize);
		}
		char* const pBuftoolData = (char*)buftool_data(buftool);
		const int nBuftoolPos = buftool_pos(buftool);
		nRet = WritePipe(fds, pBuftoolData, nBuftoolPos);
		buftool_destroy(buftool);
	}
	return nRet;
}

static short pksmncapRead_readheader( const int fds, short* const pCmdID, short* const pDataSize )
{
	char resheader[CMD_RESPONSE_SIZE] = {0};
	short result = COMM_HOST_ERROR;

	if( (pDataSize == NULL) || (pCmdID == NULL) )
	{
		return result;
	}

	if( ReadPipe(fds, resheader, sizeof(resheader)) == 0 )
	{
		BufTool* const buftool = buftool_new(CMD_RESPONSE_SIZE, BUFTOOL_LITTLE_ENDIAN);
		if( buftool != NULL )
		{
			void* const pBuftoolData= buftool_data(buftool);
			memcpy(pBuftoolData, resheader, sizeof(resheader));

			buftool_set_pos(buftool, 0);
			buftool_read_short(buftool, pCmdID);
			buftool_read_short(buftool, &result);
			buftool_read_short(buftool, pDataSize);

			buftool_destroy(buftool);
		}
	}

	return result;
}

int pksmncapRead( const int fds, const int nCmdID, int* const pDataSize, char** const pResData )
{
	short result = COMM_HOST_ERROR;
	short cmd = 0;
	short data_size = 0;

	result = pksmncapRead_readheader(fds, &cmd, &data_size);
	if( result != COMM_HOST_NO_ERROR )
	{
		return result;
	}

	if( cmd == nCmdID )
	{
		if( data_size > 0 )
		{
			if( pDataSize != NULL )
			{
				*pDataSize = 	data_size;
			}
			if( pResData != NULL )
			{
				*pResData = (char*)mem_alloc((unsigned int)data_size, __FILE__, __LINE__);
				if( *pResData != NULL )
				{
					if( ReadPipe(fds, (char*)*pResData, data_size) < 0 )
					{
						result = COMM_HOST_ERROR;
					}
				}
			}
		}
	}
	else
	{
		result = COMM_HOST_ERROR;
	}

	return result;
}

void pksmncapClose( const Mngpksmncap* const pMngpksm )
{
	int nRet = -1;

	if( pMngpksm == NULL )
	{
		return;
	}

	nRet = pksmncapWrite(pMngpksm->cmd_fd, PKSM_ID_EXIT_PROC, NULL, 0);
	if( nRet == -1 )
	{
		return;
	}

	if( pMngpksm->pid > 0 )
	{
		waitpid(pMngpksm->pid, NULL, 0);
	}
}

