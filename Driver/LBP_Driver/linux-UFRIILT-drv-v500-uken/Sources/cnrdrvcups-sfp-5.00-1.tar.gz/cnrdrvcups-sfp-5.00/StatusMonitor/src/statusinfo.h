/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#ifndef _STATUSINFO
#define _STATUSINFO

#include "uimain.h"

#define STATUSMSG_FOLDER			"/usr/lib/Canon/CUPS_SFPR/Utilities/Message/"
#define STATUSMSG_FILE			"/StatusMsg.xml"
#define COMPOSITONKEY_STRING		"[]"
#define BLANK_MESSAGE			""
#define PPDVALUE_BLANK			"\"\""
#define STATUSCOMMA_XMLKEY			"STATUS_COMMA"
#define GETTINGSTATUS_XMLKEY		"GETTINGSTATUS"
#define GETTINGSTATUSSUB_XMLKEY		"GETTINGSTATUS_SUB"
#define ORIENTATION_SHORT_EDGE_FORSTATUSMSG "Orientation_Short_Edge_forStatusMsg"
#define ORIENTATION_LONG_EDGE_FORSTATUSMSG  "Orientation_Long_Edge_forStatusMsg"

#define SUBMESSAGE_ADDKEY			"_SUB"
#define WLANMODEL_KEY			"ModelCode_WlanModel"
#define ERRORPAPERINFO_ADDKEY		"_ErrPaperInfo"
#define ERRORPAPER_PAPERSIZE_USERSETTINGPAPER "Size_User_Paper_forError"
#define JAMPOINT_ADDKEY			"_JamPoint"
#define COVEROPENOPINT_ADDKEY		"_CoverOpenPoint"
#define WAITLIST_ADDKEY			"_WaitList"
#define PAPERWARNINGINFO_KEY		"PaperWarning_NoPaperInfo"
#define PAPARWARN_PAPERSIZE_USERSETTINGPAPER "Size_User_Paper_forWarning"
#define PAPARWARN_PAPERSIZE_FREE		"Size_Free_forWarning"
#define SERVICEERROR_DEFAULTKEY		"SRVERRCODEEMPTY_SUB"
#define OPERATIONFLAG_ADDKEY		"_OpeFlag"
#define PAPERWARNINGSOURCEINFO_KEY		"PaperWarning_SourceInfo"
#define PAPEROVERPOINT_ADDKEY			"_PaperOverPoint"
#define PAPEROVERCASSETTE_KEY			"Paper_OverCassette"
#define PAPEROVERCASSETTEINFO_KEY		"Paper_OverCassette_SourceInfo"
#define MPTRAY_ADDKEY			"_MPTRAY"

#define ERRORPAPERINFO_JP_DEFAULT		"\"PaperSource,PaperSize,PaperType,Orientation\""
#define ERRORPAPERINFO_EN_DEFAULT		"\"PaperType,PaperSize,Orientation,PaperSource\""
#define JAMPOINT_DEFAULT			"\"JM_CS1,JM_Output,JM_RearCover\""
#define COVEROPENOPINT_DEFAULT		"\"CV_Front,CV_Rear\""
#define WAITLIST_DEFAULT			"\"WT_Initial,WT_Calib,WT_Regi\""
#define PAPERWARNINFO_JP_DEFAULT		"\"PaperSource,PaperSize\""
#define PAPERWARNINFO_EN_DEFAULT		"\"PaperSize,PaperSource\""
#define PAPERWARNSOURCEINFO_DEFAULT		"\"CS1\""
#define PAPEROVERPOINT_DEFAULT			"\"CS2OVER\""
#define PAPEROVERWARNINFO_DEFAULT		"\"CS2OVER\""


void* threadStatus(void* arg );
gboolean pollingGetStatus(gpointer user_data);
int msgXmlContextCreate(UIStatusWnd* const wnd);
char* msgXmlGetString(const UIStatusWnd* const wnd, const char* const pKeyName);
void msgXmlContextDestory(UIStatusWnd* const wnd);
gboolean isEnableJobCancel(const UIStatusWnd* const wnd);
gboolean isOperationEnable(const UIStatusWnd* const wnd, const char* const pOperation);
char* crgTypeList(const UIStatusWnd* const wnd);
char* crgTypeDefault(const UIStatusWnd* const wnd);
gboolean isEquipmentEnable(const UIStatusWnd* const wnd, const char* const pEquipment);
gboolean isHideMainWindow(const UIStatusWnd* const wnd);
gboolean isWlanModel(const UIStatusWnd* const wnd);
gboolean isSupportedPrinter(const UIStatusWnd* const wnd);

#endif
