/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#include "uimain.h"
#include "dictcontroller.h"

static void push_integer_value( gpointer data, gpointer user_data );
static void push_string_value( gpointer data, gpointer user_data );
static void push_substitute_value( gpointer data, gpointer user_data );
static GList* CopyGList( GList* const list, const dict_type type );
static Dict* CreateDict_Common_Value( Dict* const dict, const char* const pKeyName, const dict_type type, void* const pValue );
static gboolean CompareDictParameter( const Dict* const dict1, const Dict* const dict2 );
static int GCompareFunc_intValue( gconstpointer data1, gconstpointer data2 );
static void DeleteGList(GList* const list, const dict_type type);
static void DebugDictTypeValue( const Dict* const dict );

static void push_integer_value( gpointer data, gpointer user_data )
{
	int* pnValue = NULL;
	GList* pList = (GList*)user_data;
	if( data == NULL )
	{
		return;
	}

	pnValue = mem_alloc(sizeof(int), __FILE__, __LINE__);
	if( pnValue != NULL )
	{
		*pnValue = *((int*)data);
	}
	pList = g_list_append_wrapper(pList, (gpointer)pnValue, __FILE__, __LINE__);
}

static void push_string_value( gpointer data, gpointer user_data )
{
	char* psValue = NULL;
	GList* pList = (GList*)user_data;

	psValue = mem_strudup((char*)data, __FILE__, __LINE__);
	pList = g_list_append_wrapper( pList, (gpointer)psValue, __FILE__, __LINE__);
}

static void push_substitute_value( gpointer data, gpointer user_data )
{
	GList* pList = (GList*)user_data;
	pList = g_list_append_wrapper( pList, data, __FILE__, __LINE__);
}

static GList* CopyGList( GList* const list, const dict_type type )
{
	GList* copyList = g_list_alloc_wrapper( __FILE__, __LINE__);

	if( list == NULL )
	{
		return NULL;
	}

	switch( type )
	{
		case DICT_TYPE_NUMBER:
			g_list_foreach(list, (GFunc)push_integer_value, (gpointer)copyList);
			break;
		case DICT_TYPE_STRING:
			g_list_foreach(list, (GFunc)push_string_value, (gpointer)copyList);
			break;
		default:
			g_list_foreach(list, (GFunc)push_substitute_value, (gpointer)copyList);
			break;
	}

	copyList = g_list_delete_link_wrapper(copyList, copyList, __FILE__, __LINE__);

	return copyList;
}

Dict* CreateDict(Dict* const dict, const char* const pKeyName, const dict_type type, GList* const value)
{
	Dict* pDict = NULL;
	Dict* retDict = dict;

	pDict = (Dict*)mem_alloc(sizeof(Dict), __FILE__, __LINE__);
	if( pDict == NULL )
	{
		return NULL;
	}

	pDict->pKeyName = pKeyName;
	pDict->type = type;
	pDict->value = CopyGList(value, type);
	pDict->next = NULL;

	if( dict != NULL )
	{
		Dict* pTemp = dict;
		while( pTemp->next != NULL )
		{
			pTemp = pTemp->next;
		}
		pTemp->next = pDict;
	}
	else
	{
		retDict = pDict;
	}

	DebugOutputDict(pDict);

	return retDict;
}

static Dict* CreateDict_Common_Value( Dict* const dict, const char* const pKeyName, const dict_type type, void* const pValue )
{
	Dict* makeDict = NULL;
	GList* pList = NULL;

	if( (pKeyName == NULL) || (pValue == NULL) )
	{
		return NULL;
	}

	pList = g_list_append_wrapper(pList, pValue, __FILE__, __LINE__);

	makeDict = CreateDict(dict, pKeyName, type, pList);

	g_list_free_wrapper(pList);
	return makeDict;
}


Dict* CreateDict_Number_Value( Dict* const dict, const char* const pKeyName, int* const pValue )
{
	Dict* ValueDict = NULL;

	if( (pKeyName == NULL) || (pValue == NULL) )
	{
		return NULL;
	}

	ValueDict = CreateDict_Common_Value(dict, pKeyName, DICT_TYPE_NUMBER, pValue);

	return ValueDict;
}

Dict* CreateDict_String_Value( Dict* const dict, const char* const pKeyName, const char* const pValue )
{
	Dict* ValueDict = NULL;
	char* pDupValue = NULL;

	if( (pKeyName == NULL) || (pValue == NULL) )
	{
		return NULL;
	}

	pDupValue = mem_strudup(pValue, __func__, __LINE__);

	if(pDupValue != NULL)
	{
		ValueDict = CreateDict_Common_Value(dict, pKeyName, DICT_TYPE_STRING, pDupValue);
		mem_free( pDupValue );
	}
	return ValueDict;
}

Dict* CreateDict_Dict_Value( Dict* const dict, const char* const pKeyName, Dict* const pValue )
{
	Dict* ValueDict = NULL;

	if( (pKeyName == NULL) || (pValue == NULL) )
	{
		return NULL;
	}

	ValueDict = CreateDict_Common_Value(dict, pKeyName, DICT_TYPE_DICT, pValue);
	return ValueDict;
}

Dict* GetDict_forkey(Dict* const dict, const char* const pKeyName)
{
	Dict* retDict = dict;

	while( retDict != NULL )
	{
		size_t strLen = (((strlen(retDict->pKeyName)) >= (strlen(pKeyName))) ? (strlen(retDict->pKeyName)) : (strlen(pKeyName)));
		if( strncmp( retDict->pKeyName, pKeyName, strLen ) == 0 )
		{
			if( strlen(pKeyName) == strlen(retDict->pKeyName) )
			{
				break;
			}
		}
		retDict = (Dict*)retDict->next;
	}

	return retDict;
}

gboolean GetDictValuetype_int( const Dict* const dict, int* const pValue )
{
	if( (dict == NULL) || (dict->value == NULL) || (dict->value->data == NULL) || ( pValue == NULL) )
	{
		UI_DEBUG("%s NULL pointer, from Line[%u] \n", __func__, __LINE__);
		return FALSE;
	}

	*pValue = *((int*)dict->value->data);
	return TRUE;
}

char* GetDictValuetype_char( const Dict* const dict )
{
	if( (dict == NULL) || (dict->value == NULL) || (dict->value->data == NULL) )
	{
		UI_DEBUG("%s NULL dict pointer, from Line[%u] \n", __func__, __LINE__);
		return NULL;
	}
	return (char*)dict->value->data;
}

Dict* GetDictValuetype_Dict( const Dict* const dict )
{
	if( (dict == NULL) || (dict->value == NULL) || (dict->value->data == NULL) )
	{
		UI_DEBUG("%s NULL dict pointer, from Line[%u] \n", __func__, __LINE__);
		return NULL;
	}
	return (Dict*)dict->value->data;
}

GList* GetDictValuetype_GList(const Dict* const dict)
{
	if( (dict == NULL) || (dict->value == NULL) )
	{
		UI_DEBUG("%s NULL dict pointer, from Line[%u] \n", __func__, __LINE__);
		return NULL;
	}
	return dict->value;
}

unsigned int SetDictValuetype_int(Dict* const dict, const int value)
{
	unsigned int nRet = DICT_SET_RETURN_ERROR;

	if( (dict != NULL) && (dict->value != NULL) && (dict->value->data != NULL) )
	{

		if( *((int*)dict->value->data) == value )
		{
			nRet = DICT_SET_RETURN_SAME;
		}
		else
		{
			int* pData = NULL;
			pData = mem_alloc(sizeof(int), __FILE__, __LINE__);
			if( pData != NULL )
			{
				g_list_foreach(dict->value, (GFunc)mem_free, NULL);
				g_list_free_wrapper(dict->value);
				dict->value = NULL;
				*pData = value;
				dict->value = g_list_append_wrapper(dict->value, (gpointer)pData, __FILE__, __LINE__);
				nRet = DICT_SET_RETURN_CHANGE;
			}
		}
	}

	return nRet;

}

unsigned int SetDictValuetype_char(Dict* const dict, const char* const value)
{
	unsigned int nRet = DICT_SET_RETURN_ERROR;

	if( (dict != NULL) && (dict->value != NULL) && (dict->value->data != NULL) )
	{

		if( strcmp(dict->value->data, value) == 0 )
		{
			nRet = DICT_SET_RETURN_SAME;
		}
		else
		{
			char* pData = NULL;

			pData = mem_strudup(value, __FILE__, __LINE__);
			if( pData != NULL )
			{
				g_list_foreach(dict->value, (GFunc)mem_free, NULL);
				g_list_free_wrapper(dict->value);
				dict->value = NULL;

				dict->value = g_list_append_wrapper(dict->value, (gpointer)pData, __FILE__, __LINE__);
				nRet = DICT_SET_RETURN_CHANGE;
			}
		}
	}

	return nRet;
}

static int GCompareFunc_intValue( gconstpointer data1, gconstpointer data2 )
{
	if( (data1 == NULL) || (data2 == NULL) )
	{
		return -1;
	}

	if( *((const int*)data1) == *((const int*)data2) )
	{
		return 0;
	}

	return -1;
}

static gboolean CompareDictParameter( const Dict* const dict1, const Dict* const dict2 )
{
	gboolean bRet = TRUE;

	if( (dict1 == NULL) || (dict2 == NULL) )
	{
		return FALSE;
	}

	if( strlen(dict1->pKeyName) != strlen(dict2->pKeyName) )
	{
		return FALSE;
	}


	if( strcmp(dict1->pKeyName, dict2->pKeyName) != 0 )
	{
		return FALSE;
	}

	if( dict1->type != dict2->type )
	{
		return FALSE;
	}

	bRet = CompareGListValue(dict1->value, dict2->value, dict1->type);

	return bRet;
}

gboolean CompareGListValue( GList* const List1, GList* const List2, const dict_type type )
{
	gboolean bRet = TRUE;

	if( (List1 == NULL) || (List2 == NULL) )
	{
		return FALSE;
	}

	if( g_list_length(List1) != g_list_length(List2) )
	{
		return FALSE;
	}

	switch( type )
	{
		case DICT_TYPE_NUMBER:
		{
			unsigned int nIndex = 0;
			int* pListValue = NULL;
			for( nIndex = 0; nIndex < g_list_length(List1); ++nIndex )
			{
				pListValue = (int*)g_list_nth_data(List2, nIndex);
				if( g_list_find_custom(List1, pListValue, (GCompareFunc)GCompareFunc_intValue) == NULL )
				{
					bRet = FALSE;
					break;
				}
			}
			break;
		}
		case DICT_TYPE_STRING:
		{
			unsigned int nIndex = 0;
			char* pListValue = NULL;
			for( nIndex = 0; nIndex < g_list_length(List1); ++nIndex )
			{
				pListValue = (char*)g_list_nth_data(List2, nIndex);
				if( g_list_find_custom(List1, pListValue, (GCompareFunc)strcmp ) == NULL )
				{
					bRet = FALSE;
					break;
				}
			}
			break;
		}
		default:
		{
			unsigned int nIndex = 0;
			Dict* pList1Value = NULL;
			Dict* pList2Value = NULL;
			for( nIndex = 0; nIndex < g_list_length(List1); ++nIndex )
			{
				pList1Value = (Dict*)g_list_nth_data(List1, nIndex);
				pList2Value = (Dict*)g_list_nth_data(List2, nIndex );
				bRet = CompareDictParameter(pList1Value, pList2Value);
				if( bRet == FALSE )
				{
					break;
				}
			}
			break;
		}
	}

	return bRet;
}


static void DeleteGList(GList* const list, const dict_type type)
{
	switch(type)
	{
		case DICT_TYPE_NUMBER:
		case DICT_TYPE_STRING:
		{
			g_list_foreach(list, (GFunc)mem_free, NULL);
			break;
		}
		default:
		{

			g_list_foreach(list, (GFunc)DeleteDict, NULL);
			break;
		}
	}
	g_list_free_wrapper(list);
}

void DeleteDict(Dict* dict )
{
	Dict* nextDict = NULL;
	if( dict == NULL )
	{
		return;
	}
	do{
		nextDict = dict->next;
		if( dict->value != NULL )
		{
			DeleteGList(dict->value, dict->type);
		}
		mem_free(dict);
		dict = nextDict;
	}while( dict != NULL );
}

static void DebugDictTypeValue( const Dict* const dict )
{
	if( dict == NULL )
	{
		return;
	}

	switch( dict->type )
	{
		case DICT_TYPE_NUMBER:
		{
			unsigned int nIndex = 0;
			for( nIndex = 0; nIndex < g_list_length(dict->value); ++nIndex )
			{
				UI_DEBUG("DebugOutputDict int value[%d] = %d\n", nIndex, *((int*)g_list_nth_data(dict->value, nIndex)));
			}
			break;
		}
		case DICT_TYPE_STRING:
		{
			unsigned int nIndex = 0;
			for( nIndex = 0; nIndex < g_list_length(dict->value); ++nIndex )
			{
				UI_DEBUG("DebugOutputDict string value[%d] = %s\n", nIndex, (char*)g_list_nth_data(dict->value, nIndex));
			}
			break;
		}
		case DICT_TYPE_DICT:
		{
			unsigned int nIndex = 0;
			char *pDictValue = NULL;
			UI_DEBUG("DebugOutputDict Dict value num[%d]\n", g_list_length(dict->value));
			for( nIndex = 0; nIndex < g_list_length(dict->value); ++nIndex )
			{
				pDictValue = g_list_nth_data(dict->value, nIndex);
				UI_DEBUG("DebugOutputDict Dict value dict[%d] = %p\n", nIndex, pDictValue);
				DebugOutputDict((Dict*)pDictValue);
			}
			break;
		}
		default:
		{
			UI_DEBUG("DebugOutputDict unKnown type = %d\n", dict->type);
			break;
		}
	}
}

void DebugOutputDict( Dict *dict )
{
#ifdef _UI_DEBUG
	Dict* temp = dict;

	if( dict == NULL )
	{
		UI_DEBUG("DebugOutputDict dict == NULL \n");
		return;
	}

	while( temp != NULL )
	{
		UI_DEBUG("DebugOutputDict dict[%p] pKeyName[%s], type[%d] next[%p]\n", temp, temp->pKeyName, temp->type, temp->next);
		if( temp->value != NULL )
		{
			DebugDictTypeValue(temp);
		}
		else
		{
			UI_DEBUG("DebugOutputDict value == NULL\n");
		}
		temp = temp->next;
	}
#endif
}

GList* GetDictValueGList_forKey(Dict* const dict, const char* const pKeyName )
{
	Dict *retDict = NULL;
	GList *pValues = NULL;

	retDict = GetDict_forkey( dict, pKeyName );

	if( retDict != NULL )
	{
		pValues = GetDictValuetype_GList(retDict);
	}

	return pValues;
}

char* GetDictValueString_forKey(Dict* const dict, const char* const pKeyName )
{
	Dict* retDict = NULL;
	char *pValues = NULL;

	if( (dict == NULL) || (pKeyName == NULL) )
	{
		return NULL;
	}

	retDict = GetDict_forkey( dict, pKeyName );

	if( retDict != NULL )
	{
		pValues = GetDictValuetype_char(retDict);
	}

	return pValues;
}

gboolean GetDictValueInt_forKey(Dict* const dict, const char* const pKeyName, int* const pValue )
{
	Dict *retDict = NULL;
	gboolean bRet = FALSE;

	if( (dict == NULL) || (pKeyName == NULL) || (pValue == NULL) )
	{
		return FALSE;
	}

	retDict = GetDict_forkey( dict, pKeyName );

	if( retDict != NULL )
	{
		bRet = GetDictValuetype_int(retDict, pValue);
	}

	return bRet;
}

Dict* GetDictValueDict_forKey(Dict* const dict, const char* const pKeyName )
{
	Dict *retDict = NULL;
	Dict *pValues = NULL;

	if( (dict == NULL) || (pKeyName == NULL) )
	{
		return NULL;
	}

	retDict = GetDict_forkey( dict, pKeyName );

	if( retDict != NULL )
	{
		pValues = GetDictValuetype_Dict(retDict);
	}

	return pValues;
}

