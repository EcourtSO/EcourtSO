/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */



#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>

#include "uimain.h"
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "widgets.h"
#include "commandcontroller.h"
#include "value_defines.h"

static int SendRequest_JobOperation( UIStatusWnd * const wnd, const int nOperation );
static void ActivateShowMsg_Common( UIStatusWnd * const wnd, const int nID );
static void ActivateShowDlg_Common( UIStatusWnd * const wnd, void (* const ShowDialog)(UIStatusWnd * const wnd) );

void
on_StatusMonitorWnd_destroy            (GtkObject       *object,
                                        gpointer         user_data)
{
UI_DEBUG("destroy\n");

	gtk_main_quit();
}


gboolean
on_StatusMonitorWnd_delete_event       (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
	gboolean bDelete = FALSE;
	if( g_status_window != NULL )
	{
		if( g_status_window->exit != 0 )
		{
			bDelete = TRUE;
		}
		else
		{
			g_status_window->exit = 1;
		}
	}
	return bDelete;
}

static void ActivateShowMsg_Common( UIStatusWnd * const wnd, const int nID )
{
	if( wnd == NULL )
	{
		return;
	}

	wnd->nShowDlgCnt++;
	SetEnableAllMenu(g_status_window, FALSE);

	ShowMsgDlg( wnd, nID );

	wnd->nShowDlgCnt--;
}

static void ActivateShowDlg_Common( UIStatusWnd * const wnd, void (* const ShowDialog)(UIStatusWnd * const wnd) )
{
	if( (wnd == NULL) || (ShowDialog == NULL) )
	{
		return;
	}
	wnd->nShowDlgCnt++;
	SetEnableAllMenu(g_status_window, FALSE);

	ShowDialog( wnd );

	wnd->nShowDlgCnt--;
}

static int SendRequest_JobOperation( UIStatusWnd * const wnd, const int nOperation )
{
	Dict* pDict = NULL;
	int nJobID = 0;
	int nRet = 0;
	gboolean bRet = TRUE;

	if( wnd == NULL )
	{
		return -1;
	}

	wnd->nShowDlgCnt++;
	SetEnableAllMenu(g_status_window, FALSE);

	bRet = GetJobID( wnd, &nJobID );
	if( bRet == FALSE )
	{
		nRet = -1;
	}

	pDict = CreateDict_JobOperation( nOperation, nJobID );
	if( pDict == NULL )
	{
		nRet = -1;
	}

	if( nRet == 0 )
	{
		nRet = CommunicatePrinterData( g_status_window, NULL, pDict, CODE_COMMAND_ANALYZE, TRUE );
	}

	if( pDict != NULL )
	{
		DeleteDict( pDict );
	}

	wnd->nShowDlgCnt--;

	return nRet;
}

void
on_continue_retry_activate              (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	if(SigDisable()){
		SendRequest_JobOperation( g_status_window, JOB_OPERATION_ERROR_SKIP );
	}
	SigEnable();
}

void
on_ContinueRetry_button_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
	if(SigDisable()){
		SendRequest_JobOperation( g_status_window, JOB_OPERATION_ERROR_SKIP );
	}
	SigEnable();
}


void
on_cancel_job_activate                 (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	if(SigDisable()){
		SendRequest_JobOperation( g_status_window, JOB_OPERATION_CANCEL );
	}
	SigEnable();

}

void
on_CancelJob_button_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
	if(SigDisable()){
		SendRequest_JobOperation( g_status_window, JOB_OPERATION_CANCEL );
	}
	SigEnable();
}


void
on_consumables_information_activate    (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	ActivateShowDlg_Common( g_status_window, ShowConsumablesDlg );
}


void
on_counters_activate                   (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	ActivateShowDlg_Common( g_status_window, ShowCounterDlg );
}


void
on_wireless_lan_status_activate        (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	ActivateShowDlg_Common( g_status_window, ShowWLANStatusDlg );
}


void
on_calibration_activate                (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	const int msg_id = GetMsgId( g_status_window, "CNSUICalibrationDlg", ID_CALIBRATION_MSGDLG1 );
	ActivateShowMsg_Common( g_status_window, msg_id );
}


void
on_color_mismatch_correction_activate  (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	const int msg_id = GetMsgId( g_status_window, "CNSUIColorMismatchCorrectionDlg", ID_COLORMISMATCHCORRECTION_MSGDLG1 );
	ActivateShowMsg_Common( g_status_window, msg_id );
}


void
on_cleaning_activate                  (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	const int msg_id = GetMsgId( g_status_window, "CNSUICleaningDlg", ID_CLEANING_MSGDLG );
	ActivateShowMsg_Common( g_status_window, msg_id );
}


void
on_cleaning1_activate                  (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	const int msg_id = GetMsgId( g_status_window, "CNSUICleaning1Dlg", ID_CLEANING_MSGDLG1 );
	ActivateShowMsg_Common( g_status_window, msg_id );
}


void
on_cleaning2_activate                  (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	const int msg_id = GetMsgId( g_status_window, "CNSUICleaning2Dlg", ID_CLEANING_MSGDLG2 );
	ActivateShowMsg_Common( g_status_window, msg_id );
}


void
on_paper_source_settings_activate      (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	ActivateShowDlg_Common( g_status_window, ShowPfeedUnitSettingDlg );
}


void
on_settings_for_cancel_job_key_activate
                                        (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	ActivateShowDlg_Common( g_status_window, ShowCancelJobKeyDlg );
}


void
on_CJKDlg_ErrorJob_checkbutton_toggled (GtkToggleButton *togglebutton,
					gpointer	 user_data)
{

}

void
on_CJKDlg_OK_button_clicked	    (GtkButton       *button,
					gpointer	 user_data)
{
	CancelJobKeyDlgOK(g_status_window);
}


void
on_CJKDlg_Cancel_button_clicked	(GtkButton       *button,
					gpointer	 user_data)
{
	if( g_status_window != NULL )
	{
		HideDialog( (UIDialog *)g_status_window->cancelkey_dlg );
	}
}


gboolean
on_CancelJobKeyDlg_dialog_delete_event (GtkWidget       *widget,
					GdkEvent	*event,
					gpointer	 user_data)
{
	return FALSE;
}


void
on_CancelJobKeyDlg_dialog_destroy      (GtkObject       *object,
					gpointer	 user_data)
{
	DisposeJobCancelKeyDlg( g_status_window );
}


void
on_settings_to_disable_wi_fi_key_activate
                                        (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	ActivateShowDlg_Common( g_status_window, ShowDisableWiFiDlg );
}


void
on_sleep_settings_activate             (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	ActivateShowDlg_Common( g_status_window, ShowSleepSettingDlg );
}


void
on_SleepS_dialog_destroy           (GtkObject       *object,
                    gpointer     user_data)
{
	DisposeSleepSettingDlg( g_status_window );
}


void
on_SleepSDlg_Use_checkbutton_toggled   (GtkToggleButton *togglebutton,
					gpointer	 user_data)
{
	if(SigDisable()){
		UpdateSleepSettingDlgWidgets(g_status_window, (int)togglebutton->active);
	}
	SigEnable();
}

void
on_SleepSDlg_OK_button_clicked	 (GtkButton       *button,
					gpointer	 user_data)
{
	SleepSettingDlgOK(g_status_window);
}


void
on_SleepSDlg_Cancel_button_clicked     (GtkButton       *button,
					gpointer	 user_data)
{
	if( g_status_window != NULL )
	{
		HideDialog( (UIDialog *)g_status_window->sleeps_dlg );
	}
}


gboolean
on_SleepS_dialog_delete_event     (GtkWidget       *widget,
                    GdkEvent    *event,
                    gpointer     user_data)
{
	return FALSE;
}


void
on_auto_shutdown_settings_activate     (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	ActivateShowDlg_Common( g_status_window, ShowAutoShutdownDlg );
}

void
on_AutoShutdown_dialog_destroy           (GtkObject       *object,
                    gpointer     user_data)
{
	DisposeAutoShutdownDlg( g_status_window );
}


void
on_AutoShutdownDlg_Use_checkbutton_toggled   (GtkToggleButton *togglebutton,
					gpointer	 user_data)
{
	if( (SigDisable() != FALSE) && (togglebutton != NULL) )
	{
		UpdateAutoShutdownDlgWidgets( g_status_window, (int)togglebutton->active );
	}
	SigEnable();
}

void
on_AutoShutdownDlg_OK_button_clicked	 (GtkButton       *button,
					gpointer	 user_data)
{
	AutoShutdownDlgOK( g_status_window );
}


void
on_AutoShutdownDlg_Cancel_button_clicked     (GtkButton       *button,
					gpointer	 user_data)
{
	if( g_status_window != NULL )
	{
		HideDialog( (UIDialog *)g_status_window->autoshutdown_dlg );
	}
}


gboolean
on_AutoShutdown_dialog_delete_event     (GtkWidget       *widget,
                    GdkEvent    *event,
                    gpointer     user_data)
{
	return FALSE;
}


void
on_image_quality_adjustment_settings_activate
                                        (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	ActivateShowDlg_Common( g_status_window, ShowImgAdjustDlg );
}

gboolean
on_ImgAdjust_dialog_delete_event     (GtkWidget       *widget,
                    GdkEvent    *event,
                    gpointer     user_data)
{
    return FALSE;
}

void
on_ImgAdjust_dialog_destroy           (GtkObject       *object,
                    gpointer     user_data)
{
	DisposeImgAdjustDlg( g_status_window );
}


void
on_ImgAdjustDlg_Calib_checkbutton_toggled   (GtkToggleButton *togglebutton,
					gpointer	 user_data)
{
	if( (SigDisable() != FALSE) && (togglebutton != NULL) )
	{
		UpdateImgAdjustDlgWidgets( g_status_window, (int)togglebutton->active );
	}
	SigEnable();
}

void
on_ImgAdjustDlg_OK_button_clicked	 (GtkButton       *button,
					gpointer	 user_data)
{
	ImgAdjustDlgOK( g_status_window );
}


void
on_ImgAdjustDlg_Cancel_button_clicked     (GtkButton       *button,
					gpointer	 user_data)
{
	if( g_status_window != NULL )
	{
		HideDialog( (UIDialog *)g_status_window->imgadjust_dlg );
	}
}

void
on_paper_size_override_settings_activate
                                        (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	ActivateShowDlg_Common( g_status_window, ShowOverrideDlg );
}

void
on_assisting_print_setting_activate    (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	ActivateShowDlg_Common( g_status_window, ShowAssistSettingDlg );
}


void
on_hide_statusmonitor_activate         (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	if(SigDisable()){
		ActivateShowMsg_Common( g_status_window, ID_HIDE_MONITOR );
	}
	SigEnable();
}


void
on_HideSM_button_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
#ifdef _XML_DEBUG
	g_status_window->pauseGetStatus = FALSE;
#else
	if(SigDisable()){
		ActivateShowMsg_Common( g_status_window, ID_HIDE_MONITOR );
	}
	SigEnable();
#endif
}

void
on_Msg_USBRetry_dialog_show				(GtkObject       *object,
                                        gpointer         user_data)
{
	LeaveCriticalSection(&g_USBRetrySection);
}

gboolean on_Msg_dialog_hide_from_thread(gpointer data)
{
	UIStatusWnd* const wnd = (UIStatusWnd*)data;
	if( wnd != NULL )
	{
		HideMsgDlg(wnd);
	}
	return FALSE;
}

void
on_Msg_dialog_destroy                  (GtkObject       *object,
                                        gpointer         user_data)
{
	DisposeMsgDlg( g_status_window );
}


gboolean
on_Msg_dialog_delete_event             (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
 	return FALSE;
}

gboolean
on_Msg_dialog_delete_event_btn_none    (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
 	return TRUE;
}


void
on_MsgDlg_OK_button_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
	MsgDlgOK(g_status_window);
}


void
on_MsgDlg_Cancel_button_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
	MsgDlgCancel(g_status_window);
}


void
on_paper_size_override_checkbutton_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_paper_size_override_OK_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
	OverrideDlgOK(g_status_window);
}


void
on_paper_size_override_Cancel_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
	if( g_status_window != NULL )
	{
		HideDialog( (UIDialog *)g_status_window->override_dlg );
	}
}

gboolean
on_paper_size_override_dialog_delete_event
                                        (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
	return FALSE;
}


void
on_paper_size_override_dialog_destroy  (GtkObject       *object,
                                        gpointer         user_data)
{
	DisposeOverRideDlg( g_status_window );
}


gboolean
on_DisableWiFiDlg_delete_event         (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
	return FALSE;
}


void
on_DisableWiFiDlg_destroy              (GtkObject       *object,
                                        gpointer         user_data)
{
	DisposeDisableWifiDlg( g_status_window );
}


void
on_DisableWiFiDlg_checkbutton_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_DisablwWiFiDlg_OK_button_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
	DisableWiFiDlgOK(g_status_window);
}


void
on_DisableWiFiDlg_Cancel_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
	if( g_status_window != NULL )
	{
		HideDialog( (UIDialog *)g_status_window->disablewifi_dlg );
	}
}

gboolean
on_AssistDlg_delete_event              (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
	return FALSE;
}


void
on_AssistDlg_destroy                   (GtkObject       *object,
                                        gpointer         user_data)
{
	DisposeAssistDlg( g_status_window );
}


void
on_AssistDlg_Curl_checkbutton_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_AssistDlg_Qlty_checkbutton_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_AssistDlg_Cling_checkbutton_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_AssistDlg_Wrinkle_checkbutton_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_AssistDlg_OK_button_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
	AssistSettingDlgOK( g_status_window );
}


void
on_AssistDlg_Cancel_button_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{
	if( g_status_window != NULL )
	{
		HideDialog( (UIDialog *)g_status_window->assist_dlg );
	}
}

gboolean
on_ConsumablesDlg_delete_event         (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
	return FALSE;
}


void
on_ConsumablesDlg_destroy              (GtkObject       *object,
                                        gpointer         user_data)
{
	DisposeConsumablesDlg( g_status_window );
}


void
on_ConsumablesDlg_OK_button_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
	if( g_status_window != NULL )
	{
		HideDialog( (UIDialog *)g_status_window->consumables_dlg );
	}
}

gboolean
on_CounterDlg_delete_event             (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
	return FALSE;
}


void
on_CounterDlg_destroy                  (GtkObject       *object,
                                        gpointer         user_data)
{
	DisposeCounterDlg( g_status_window );
}


void
on_CounterDlg_OK_button_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
	if( g_status_window != NULL )
	{
		HideDialog( (UIDialog *)g_status_window->counter_dlg );
	}
}

void
on_WLANStatusDlg_destroy               (GtkObject       *object,
                                        gpointer         user_data)
{
	DisposeWlansStatusDlg( g_status_window );
}

gboolean
on_WLANStatusDlg_delete_event          (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
	return FALSE;
}

void
on_WLANStatusDlg_OK_button_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{
	if( g_status_window != NULL )
	{
		HideDialog( (UIDialog *)g_status_window->wlanstatus_dlg );
	}
}

gboolean
on_PFeedUnitDlg_delete_event           (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
	return FALSE;
}


void
on_PFeedUnitDlg_destroy                (GtkObject       *object,
                                        gpointer         user_data)
{
	DisposePFeedUnitDlg( g_status_window );
}

void
on_PFeedUnitDlg_OK_button_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
	PfeedUnitSettingDlgOK( g_status_window );
}

void
on_PFeedUnit_Cancel_button_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{
	if( g_status_window != NULL )
	{
		HideDialog( (UIDialog *)g_status_window->pfeedunit_dlg );
	}
}

void
on_PFeedUnitDlg_CS1Size_combo_changed   (GtkComboBox     *combobox,
                                        gpointer         user_data)
{
	gint nIndex = -1;

	nIndex = gtk_combo_box_get_active( combobox );
	if( nIndex != -1 )
	{
		UpdatePFeedUnitDlgChangeFeedCtrl( g_status_window, nIndex, "PFeedUnitDlg_CS1Feed_combo" );
	}
}

void
on_PFeedUnitDlg_CS1Rough_checkbutton_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}

void
on_PFeedUnitDlg_MPTraySize_combo_changed
                                        (GtkComboBox     *combobox,
                                        gpointer         user_data)
{
	gint nIndex = -1;

	nIndex = gtk_combo_box_get_active( combobox );
	if( nIndex != -1 )
	{
		UpdatePFeedUnitDlgChangeFeedCtrl( g_status_window, nIndex, "PFeedUnitDlg_MPTrayFeed_combo" );
	}

}


void
on_PFeedUnitDlg_CS1PSWSize_combo_changed
                                        (GtkComboBox     *combobox,
                                        gpointer         user_data)
{
	gint nIndex = -1;

	nIndex = gtk_combo_box_get_active( combobox );
	if( nIndex != -1 )
	{
		UpdatePFeedUnitDlgChangeFeedCtrl( g_status_window, nIndex, "PFeedUnitDlg_CS1PSWFeed_combo" );
	}
}


void
on_PFeedUnitDlg_CS2PSWSize_combo_changed
                                        (GtkComboBox     *combobox,
                                        gpointer         user_data)
{
	gint nIndex = -1;

	nIndex = gtk_combo_box_get_active( combobox );
	if( nIndex != -1 )
	{
		UpdatePFeedUnitDlgChangeFeedCtrl( g_status_window, nIndex, "PFeedUnitDlg_CS2PSWFeed_combo" );
	}
}


void
on_PFeedUnitDlg_CS3PSWSize_combo_changed
                                        (GtkComboBox     *combobox,
                                        gpointer         user_data)
{
	gint nIndex = -1;

	nIndex = gtk_combo_box_get_active( combobox );
	if( nIndex != -1 )
	{
		UpdatePFeedUnitDlgChangeFeedCtrl( g_status_window, nIndex, "PFeedUnitDlg_CS3PSWFeed_combo" );
	}
}


void
on_PFeedUnitDlg_CS4PSWSize_combo_changed
                                        (GtkComboBox     *combobox,
                                        gpointer         user_data)
{
	gint nIndex = -1;

	nIndex = gtk_combo_box_get_active( combobox );
	if( nIndex != -1 )
	{
		UpdatePFeedUnitDlgChangeFeedCtrl( g_status_window, nIndex, "PFeedUnitDlg_CS4PSWFeed_combo" );
	}
}


void
on_warning_display_settings_activate   (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	ActivateShowDlg_Common( g_status_window, ShowWarningDisplayDlg );
}

gboolean
on_WarningDisplayDlg_delete_event     (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
  return FALSE;
}

void
on_WarningDisplayDlg_destroy          (GtkObject       *object,
                                        gpointer         user_data)
{
	DisposeWarningDisplayDlg( g_status_window );
}

void
on_WarningDisplayDlg_DisplayTonerLow_checkbutton_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
}

void
on_WarningDisplayDlg_OK_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
	WarningDisplayDlgOK(g_status_window);
}

void
on_WarningDisplayDlg_Cancel_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
	if( g_status_window != NULL )
	{
		HideDialog( (UIDialog *)g_status_window->warningdisplay_dlg );
	}
}


void
on_warning_display_details_activate    (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	ActivateShowDlg_Common( g_status_window, ShowWarningDetailsDlg );
}

gboolean
on_WarningDetails_dialog_delete_event  (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
  return FALSE;
}

void
on_WarningDetails_dialog_destroy       (GtkObject       *object,
                                        gpointer         user_data)
{
	DisposeWarningDetailsDlg( g_status_window );
}

void
on_WarningDetailsDlg_OK_button_clicked (GtkButton       *button,
                                        gpointer         user_data)
{
	WarningDetailsDlgOK(g_status_window);
}

void
on_WarningDetailsDlg_Cancel_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
	if( g_status_window != NULL )
	{
		HideDialog( (UIDialog *)g_status_window->warningdetails_dlg );
	}
}


void
on_mobile_print_settings_activate      (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	ActivateShowDlg_Common( g_status_window, ShowMobilePrintDlg );
}

gboolean
on_MobilePrint_dialog_delete_event     (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
  return FALSE;
}

void
on_MobilePrint_dialog_destroy          (GtkObject       *object,
                                        gpointer         user_data)
{
	DisposeMobilePrintDlg( g_status_window );
}

void
on_MobilePrintDlg_OK_button_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
	MobilePrintDlgOK(g_status_window);
}

void
on_MobilePrintDlg_Cancel_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
	if( g_status_window != NULL )
	{
		HideDialog( (UIDialog *)g_status_window->mobileprint_dlg );
	}
}


void
on_action_when_paper_size_mismatch_settings_activate
                                        (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	ActivateShowDlg_Common( g_status_window, ShowPaperSizeCheckDlg );
}


gboolean
on_PaperSizeCheck_dialog_delete_event  (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
  return FALSE;
}


void
on_PaperSizeCheck_dialog_destroy       (GtkObject       *object,
                                        gpointer         user_data)
{
	DisposePaperSizeCheckDlg(g_status_window);
}


void
on_PaperSizeCheckDlg_OK_button_clicked (GtkButton       *button,
                                        gpointer         user_data)
{
	PaperSizeCheckDlgOK(g_status_window);
}


void
on_PaperSizeCheckDlg_Cancel_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
	if( g_status_window != NULL )
	{
		HideDialog( (UIDialog *)g_status_window->papersizecheck_dlg );
	}
}

void
on_select_language_for_user_data_list_activate
                                        (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	ActivateShowDlg_Common( g_status_window, ShowReportPrintDlg );
}

gboolean
on_ReportPrint_dialog_delete_event     (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
  return FALSE;
}

void
on_ReportPrint_dialog_destroy          (GtkObject       *object,
                                        gpointer         user_data)
{
	DisposeReportPrintDlg(g_status_window);
}

void
on_ReportPrintDlg_OK_button_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
	ReportPrintDlgOK(g_status_window);
}

void
on_ReportPrintDlg_Cancel_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
	if( g_status_window != NULL )
	{
		HideDialog( (UIDialog *)g_status_window->reportprint_dlg );
	}
}


void
on_switch_paper_feed_method_activate   (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	ActivateShowDlg_Common( g_status_window, ShowSwitchPaperFeedDlg );
}

gboolean
on_SwitchPaperFeed_dialog_delete_event
                                        (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data)
{
  return FALSE;
}

void
on_SwitchPaperFeed_dialog_destroy
                                        (GtkObject       *object,
                                        gpointer         user_data)
{
	DisposeSwitchPaperFeedDlg(g_status_window);
}


void
on_SwitchPaperFeedDlg_OK_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
	SwitchPaperFeedDlgOK(g_status_window);
}


void
on_SwitchPaperFeedDlg_Cancel_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
	if( g_status_window != NULL )
	{
		HideDialog( (UIDialog *)g_status_window->switchpaperfeed_dlg );
	}
}

void
on_user_data_list_activate             (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	const int msg_id = GetMsgId( g_status_window, "CNSUIUserDataListDlg", ID_USERDATALIST_MSGDLG1 );
	ActivateShowMsg_Common( g_status_window, msg_id );
}

void
on_pcl_font_list_activate              (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	const int msg_id = GetMsgId( g_status_window, "CNSUIPCLFontListDlg", ID_PCLFONTLIST_MSGDLG1 );
	ActivateShowMsg_Common( g_status_window, msg_id );
}

void
on_enter_cancel_firmware_update_mode_activate
                                        (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	const int msg_id = GetMsgId( g_status_window, "CNSUIUpdatingFirmwareModeDlg", ID_UPDATINGFIRMWAREMODE_MSGDLG1 );
	ActivateShowMsg_Common( g_status_window, msg_id );
}


gboolean
on_pc_scr_dialog_delete_event
										(GtkWidget       *widget,
                                		GdkEvent        *event,
            							gpointer         user_data)
{
  return FALSE;
}

void
on_pc_scr_dialog_destroy
										(GtkObject       *object,
										gpointer         user_data)
{
	DisposePurchaseConsumables_scr_dlg(g_status_window);
}

void
on_pc_access_purchasing_site_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
	ActivateShowDlg_Common( g_status_window, ShowPurchaseConsumables_scr_dlg );
}


void
on_pc_scr_dialog_ok_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
	PurchaseConsumables_scr_dlgOK(g_status_window);
}


void
on_pc_scr_dialog_cancel_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{
	if( g_status_window != NULL )
	{
		HideDialog( (UIDialog *)g_status_window->purchaseconsumables_scr_dlg );
	}
}

