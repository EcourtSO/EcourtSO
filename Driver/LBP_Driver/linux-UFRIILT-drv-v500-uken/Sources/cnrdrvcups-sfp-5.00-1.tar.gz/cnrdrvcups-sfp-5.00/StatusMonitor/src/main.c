/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */




#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"

#include "dialog.h"
#include "uimain.h"
#include "widgets.h"

#include "statusinfo.h"

#define POLLING_COUNT	1000
#define GETSTATUS_SLEEPTIME	1

int LaunchOption(int argc, char *argv[], char *printer_name)
{
	if(argc == 3){
		if(strcmp(argv[1], "-P") == 0){
			if(argv[2] != NULL)
				strncpy(printer_name, argv[2], 127);
			return 1;
		}
	}else if(argc == 4){
		if(strcmp(argv[1], "-P") == 0){
			if(argv[2] != NULL)
				strncpy(printer_name, argv[2], 127);
			if(strcmp(argv[3], "-e") == 0)
				return 0;
			printf("*** WARNING *** Unknown switch, %s\n", argv[3]);
			return 1;
		}
	}
	printf("ncapstatusui --- Status monitor for Canon NCAP Printer.\n");
	printf("Usage  :  ncapstatusui -P printer [-e]\n");
	printf(" -e	\"Status Monitor is showed only when errors occur\".\n\n");
	return -1;
}

int StartProcess(mode)
{
	guint PollingFlag = 0;
	pthread_t StatusThread;
	int ret = 0;

	ret = msgXmlContextCreate(g_status_window);

	if( ret == 0 )
	{
		SigDisable();
		UpdateMainWindow(g_status_window, NULL, NULL);
		SigEnable();

		if(mode){
			gtk_widget_show(UI_DIALOG(g_status_window)->window);
		}

#ifdef _XML_DEBUG
		g_status_window->pauseGetStatus = TRUE;
		SetEnableAllMenu(g_status_window, TRUE);
#endif
		g_status_window->nStatusThreadSleepTime = GETSTATUS_SLEEPTIME;
		ret = pthread_create(&StatusThread, NULL, threadStatus, (void*)g_status_window);
		if( ret == 0 )
		{
			PollingFlag = gtk_timeout_add(POLLING_COUNT, (GtkFunction)pollingGetStatus, NULL);

			gtk_main ();
			if( PollingFlag != 0u )
			{
				gtk_timeout_remove(PollingFlag);
			}
			g_status_window->pauseGetStatus = TRUE;
			g_status_window->bPoollingStop = TRUE;

			pthread_join(StatusThread, NULL);
		}
		msgXmlContextDestory(g_status_window);
	}

	return ret;
}

int
main (int argc, char *argv[])
{
	char printer_name[128];
	int mode = 0;

#ifdef ENABLE_NLS
	bindtextdomain(PACKAGE, PACKAGE_LOCALE_DIR);
#ifndef OLD_GTK
	bind_textdomain_codeset(PACKAGE, "UTF-8");
#endif
	textdomain(PACKAGE);
#endif
	gtk_set_locale ();
	gtk_init (&argc, &argv);

	add_pixmap_directory (PACKAGE_DATA_DIR "/pixmaps");
#ifdef OLD_GTK
	add_pixmap_directory (PACKAGE_SOURCE_DIR "/pixmaps");
#endif

	memset(printer_name, 0, sizeof(printer_name));
	mode = LaunchOption(argc, argv, printer_name);
	if(mode != -1){
		SigInit();

		InitializeCriticalSection(&g_USBRetrySection);
		InitializeCriticalSection(&g_StatusSection);
		InitializeCriticalSection(&g_CommuticateSection);

		g_status_window = CreateStatusWnd(printer_name, mode);
		if(g_status_window == NULL){
UI_DEBUG("Window Create Error\n");
			return -1;
		}
		gtk_widget_realize(UI_DIALOG(g_status_window)->window);

		StartProcess(mode);

		DeleteCriticalSection(&g_USBRetrySection);
		DeleteCriticalSection(&g_StatusSection);
		DeleteCriticalSection(&g_CommuticateSection);

		DisposeStatusWnd( g_status_window );
		mem_free( g_status_window );
	}

	g_list_quit_alloc();
	g_string_quit_alloc();
	mem_quit_alloc();
UI_DEBUG("Finish\n");

	return 0;
}

