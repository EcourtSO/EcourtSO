/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */



#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "uimain.h"
#include "widgets.h"
#include "interface.h"
#include "disablewifidlg.h"

#include "callbacks.h"
#include "support.h"
#include "id_defines.h"
#include "commandcontroller.h"
#include "value_defines.h"

#define DISABLE_WIFI_CTRL_TYPE_NUM 3
#define DISABLE_WIFI_CTRL_TBL_NUM 4

static int InitDisableWiFiDlgWidgets( UIStatusWnd* const wnd );
static unsigned int SetItemValue_DisableWiFiDlgOK( const UIStatusWnd* const wnd );

CtrlTbl* PPDCtrlTbl[CTRL_LIST_MAXNUM];

static CtrlTbl ctrlTbl[DISABLE_WIFI_CTRL_TBL_NUM] =
{
	{ ID_DISABLEWIFI_DIALOG1, LABEL_TYPE_TITLE, NULL, N_("Settings to Disable Wi-Fi Key"), NULL, 0 },
	{ ID_CTRLWIFIDISABLE, LABEL_TYPE_BUTTON, "DisableWiFiDlg_Use_checkbutton", N_("Disable Wi-Fi Key"), "DisableWiFiDlg_Use_checkbutton", ID121472 },
	{ ID_CTRLWIFIDISABLE_COMMENT, LABEL_TYPE_TEXT, "DisableWiFiDlg_Label", N_("* Select this check box to prevent Wi-Fi key operation errors."), "DisableWiFiDlg_Label", 0 },
	{ -1, -1, NULL, NULL, NULL, -1 }
};

UIDisableWiFiDlg* CreateDisableWiFiDlg(UIDialog* const parent)
{
	UIDisableWiFiDlg *pDialog;

	pDialog = (UIDisableWiFiDlg *)CreateDialog(sizeof(UIDisableWiFiDlg), parent);
	if( pDialog != NULL )
	{
		UI_DIALOG(pDialog)->window = create_DisableWiFi_dialog();
	}
	return pDialog;
}

void ShowDisableWiFiDlg( UIStatusWnd* const wnd )
{
	int nRet = 0;

	if( wnd == NULL )
	{
		return;
	}
	if( wnd->disablewifi_dlg == NULL )
	{
		wnd->disablewifi_dlg = CreateDisableWiFiDlg( UI_DIALOG( wnd ) );
	}

	SigDisable();
	nRet = InitDisableWiFiDlgWidgets( wnd );
	SigEnable();

	if( nRet == 0 )
	{
		ShowDialog( (UIDialog *)wnd->disablewifi_dlg, NULL );
	}
	else
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_GET );
		if( wnd->disablewifi_dlg != NULL )
		{
			if( wnd->disablewifi_dlg->pDialogDict != NULL )
			{
				DeleteDict( wnd->disablewifi_dlg->pDialogDict );
				wnd->disablewifi_dlg->pDialogDict = NULL;
			}
			mem_free( wnd->disablewifi_dlg );
			wnd->disablewifi_dlg = NULL;
		}
	}
}

static unsigned int SetItemValue_DisableWiFiDlgOK( const UIStatusWnd* const wnd )
{
	int i = 0;
	int nValue = 0;
	unsigned int unRet = 0;
	GtkWidget *pWindow = NULL;

	if( wnd == NULL )
	{
		UI_DEBUG("SetItemValue_DisableWiFiDlgOK PPDCtrlTbl[%p] pWindow[%p]\n", PPDCtrlTbl, pWindow);
		return DICT_SET_RETURN_ERROR;
	}
	pWindow = wnd->disablewifi_dlg->dialog.window;

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		switch( PPDCtrlTbl[i]->dbid )
		{
		case ID121472:
			nValue = GetToggleButtonActive( pWindow, "DisableWiFiDlg_Use_checkbutton", TRUE );
			unRet |= SetItemValuetype_int( wnd->disablewifi_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, nValue );
			UI_DEBUG("SetItemValue_DisableWiFiDlgOK unRet[%d]\n", unRet);
			break;
		default:
			break;
		}
		if( (unRet & DICT_SET_RETURN_ERROR) == DICT_SET_RETURN_ERROR )
		{
			break;
		}
	}
	return unRet;
}

void DisableWiFiDlgOK( UIStatusWnd* const wnd )
{
	int nRet = 0;
	unsigned int unRet = 0;

	if( wnd == NULL )
	{
		return;
	}
	else
	{
		nRet = CreateDict_SetData( wnd->disablewifi_dlg->pDialogDict );
	}

	if( nRet == 0 )
	{
		unRet = SetItemValue_DisableWiFiDlgOK( wnd );
		if( (unRet & DICT_SET_RETURN_ERROR) == DICT_SET_RETURN_ERROR )
		{
			nRet = -1;
		}
	}

	if( ( nRet == 0 ) && ( unRet == DICT_SET_RETURN_CHANGE ) )
	{
		nRet = CommunicatePrinterData( wnd, (UIDialog *)wnd->disablewifi_dlg, wnd->disablewifi_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	}

	HideDialog( (UIDialog *)wnd->disablewifi_dlg );

	if( nRet != 0 )
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_SET );
	}

	return;
}

static int InitDisableWiFiDlgWidgets( UIStatusWnd* const wnd )
{
	GtkWidget *pWindow = NULL;
	GList *pGlist = NULL;
	int nValue = 1;
	int i = 0;
	int nRet = 0;
	const char* const ctrl_type[DISABLE_WIFI_CTRL_TYPE_NUM] = { "CNSUIWifiInvDlg", "CNSUICtrlDisableWiFi", NULL };

	if( wnd == NULL )
	{
		return -1;
	}

	if( wnd->disablewifi_dlg == NULL )
	{
		return -1;
	}
	else
	{
		pWindow = wnd->disablewifi_dlg->dialog.window;
	}

	CreatePPDCtrlTbl( wnd, ctrl_type, ctrlTbl, PPDCtrlTbl );

	SetLabel_HideWidget( pWindow, PPDCtrlTbl, ctrlTbl );

	pGlist = CreateGlist_DbId( PPDCtrlTbl );

	if( wnd->disablewifi_dlg->pDialogDict != NULL )
	{
		UI_DEBUG("pDialogDict no mem_free, from Func[%s] Line[%u] \n", __func__, __LINE__);
		DeleteDict( wnd->disablewifi_dlg->pDialogDict );
	}
	wnd->disablewifi_dlg->pDialogDict = CretateDict_GetData( pGlist );
	g_list_free_wrapper( pGlist );
	pGlist = NULL;

	if( wnd->disablewifi_dlg->pDialogDict == NULL )
	{
		return -1;
	}

	nRet = CommunicatePrinterData( wnd, NULL, wnd->disablewifi_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	if( nRet != 0 )
	{
		return -1;
	}

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		switch( PPDCtrlTbl[i]->dbid )
		{
		case ID121472:
			GetItemValueType_int( wnd->disablewifi_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, &nValue );
			SetActiveCheckButton( pWindow, "DisableWiFiDlg_Use_checkbutton" , nValue, TRUE );
			break;
		default:
			break;
		}
	}

	return nRet;
}

void DisposeDisableWifiDlg( UIStatusWnd* const wnd )
{
	UIDisableWiFiDlg* ui_disablewifi_dlg = NULL;

	if(wnd == NULL)
	{
		return;
	}

	ui_disablewifi_dlg = wnd->disablewifi_dlg;
	if( ui_disablewifi_dlg != NULL )
	{
		if( ui_disablewifi_dlg->pDialogDict != NULL )
		{
			DeleteDict( ui_disablewifi_dlg->pDialogDict );
			ui_disablewifi_dlg->pDialogDict = NULL;
		}
		DisposeDialog( (UIDialog *)ui_disablewifi_dlg );
		wnd->disablewifi_dlg = NULL;
	}
}

