/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */



#include <gtk/gtk.h>


void
on_StatusMonitorWnd_destroy            (GtkObject       *object,
                                        gpointer         user_data);

gboolean
on_StatusMonitorWnd_delete_event       (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_continue_retry_activate              (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_cancel_job_activate                 (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_consumables_information_activate    (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_counters_activate                   (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_wireless_lan_status_activate        (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_calibration_activate                (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_color_mismatch_correction_activate  (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_cleaning_activate                   (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_cleaning1_activate                  (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_cleaning2_activate                  (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_paper_source_settings_activate      (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_settings_for_cancel_job_key_activate
                                        (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_settings_to_disable_wi_fi_key_activate
                                        (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_sleep_settings_activate             (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_auto_shutdown_settings_activate     (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_image_quality_adjustment_settings_activate
                                        (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_paper_size_override_settings_activate
                                        (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_assisting_print_setting_activate    (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_hide_statusmonitor_activate         (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_HideSM_button_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_ContinueRetry_button_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_CancelJob_button_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_Msg_USBRetry_dialog_show				(GtkObject       *object,
                                        gpointer         user_data);

gboolean
on_Msg_dialog_hide_from_thread(gpointer data);

void
on_Msg_dialog_destroy                  (GtkObject       *object,
                                        gpointer         user_data);

gboolean
on_Msg_dialog_delete_event             (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

gboolean
on_Msg_dialog_delete_event_btn_none    (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_MsgDlg_OK_button_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_MsgDlg_Cancel_button_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_continue_retry_activate             (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

gboolean
on_SleepS_dialog_delete_event          (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_SleepS_dialog_destroy               (GtkObject       *object,
                                        gpointer         user_data);

void
on_SleepSDlg_Use_checkbutton_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_SleepSDlg_OK_button_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_SleepSDlg_Cancel_button_clicked     (GtkButton       *button,
                                        gpointer         user_data);

gboolean
on_CancelJobKeyDlg_dialog_delete_event (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_CancelJobKeyDlg_dialog_destroy      (GtkObject       *object,
                                        gpointer         user_data);
void
on_CJKDlg_ErrorJob_checkbutton_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_CJKDlg_OK_button_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_CJKDlg_Cancel_button_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_SleepSDlg_Use_checkbutton_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_SleepSDlg_OK_button_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_SleepSDlg_Cancel_button_clicked     (GtkButton       *button,
                                        gpointer         user_data);

gboolean
on_CancelJobKeyDlg_dialog_delete_event (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_CancelJobKeyDlg_dialog_destroy      (GtkObject       *object,
                                        gpointer         user_data);

void
on_paper_size_override_dialog_destroy      (GtkObject       *object,
											gpointer	 user_data);

void
on_paper_size_override_OK_button_clicked	    (GtkButton       *button,
											gpointer	 user_data);


void
on_paper_size_override_Cancel_button_clicked	(GtkButton       *button,
											gpointer	 user_data);

void
on_paper_size_override_checkbutton_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_paper_size_override_OK_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_paper_size_override_Cancel_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

gboolean
on_paper_size_override_dialog_delete_event
                                        (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_paper_size_override_dialog_destroy  (GtkObject       *object,
                                        gpointer         user_data);
gboolean
on_DisableWiFiDlg_delete_event         (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_DisableWiFiDlg_destroy              (GtkObject       *object,
                                        gpointer         user_data);

void
on_DisableWiFiDlg_checkbutton_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_DisablwWiFiDlg_OK_button_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_DisableWiFiDlg_Cancel_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);
gboolean
on_AssistDlg_delete_event              (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_AssistDlg_destroy                   (GtkObject       *object,
                                        gpointer         user_data);

void
on_AssistDlg_Curl_checkbutton_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_AssistDlg_Qlty_checkbutton_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_AssistDlg_Cling_checkbutton_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_AssistDlg_Wrinkle_checkbutton_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_AssistDlg_OK_button_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_AssistDlg_Cancel_button_clicked     (GtkButton       *button,
                                        gpointer         user_data);

gboolean
on_ConsumablesDlg_delete_event         (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_ConsumablesDlg_destroy              (GtkObject       *object,
                                        gpointer         user_data);

void
on_ConsumablesDlg_OK_button_clicked    (GtkButton       *button,
                                        gpointer         user_data);

gboolean
on_CounterDlg_delete_event             (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_CounterDlg_destroy                  (GtkObject       *object,
                                        gpointer         user_data);

void
on_CounterDlg_OK_button_clicked        (GtkButton       *button,
                                        gpointer         user_data);

gboolean
on_WLANStatusDlg_delete_event          (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_WLANStatusDlg_destroy               (GtkObject       *object,
                                        gpointer         user_data);

void
on_WLANStatusDlg_OK_button_clicked     (GtkButton       *button,
                                        gpointer         user_data);

gboolean
on_AutoShutdown_dialog_delete_event          (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_AutoShutdown_dialog_destroy               (GtkObject       *object,
                                        gpointer         user_data);

void
on_AutoShutdownDlg_Use_checkbutton_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_AutoShutdownDlg_OK_button_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_AutoShutdownDlg_Cancel_button_clicked     (GtkButton       *button,
                                        gpointer         user_data);

gboolean
on_ImgAdjust_dialog_delete_event     (GtkWidget       *widget,
											 GdkEvent    *event,
											 gpointer     user_data);

void
on_ImgAdjust_dialog_destroy           (GtkObject       *object,
											 gpointer     user_data);

void
on_ImgAdjustDlg_Calib_checkbutton_toggled   (GtkToggleButton *togglebutton,
											 gpointer	 user_data);

void
on_ImgAdjustDlg_OK_button_clicked	 (GtkButton       *button,
											 gpointer	 user_data);

void
on_ImgAdjustDlg_Cancel_button_clicked     (GtkButton       *button,
											 gpointer	 user_data);



gboolean
on_PFeedUnitDlg_delete_event           (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_PFeedUnitDlg_destroy                (GtkObject       *object,
                                        gpointer         user_data);

void
on_PFeedUnitDlg_OK_button_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_PFeedUnit_Cancel_button_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_PFeedUnitDlg_CS1Size_combo_changed   (GtkComboBox     *combobox,
                                        gpointer         user_data);

void
on_PFeedUnitDlg_CS1Rough_checkbutton_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_PFeedUnitDlg_MPTraySize_combo_changed
                                        (GtkComboBox     *combobox,
                                        gpointer         user_data);

void
on_PFeedUnitDlg_CS4PSWSize_combo_changed
                                        (GtkComboBox     *combobox,
                                        gpointer         user_data);

void
on_PFeedUnitDlg_CS1PSWSize_combo_changed
                                        (GtkComboBox     *combobox,
                                        gpointer         user_data);

void
on_PFeedUnitDlg_CS2PSWSize_combo_changed
                                        (GtkComboBox     *combobox,
                                        gpointer         user_data);

void
on_PFeedUnitDlg_CS3PSWSize_combo_changed
                                        (GtkComboBox     *combobox,
                                        gpointer         user_data);

void
on_warning_display_settings_activate   (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

gboolean
on_WarningDisplayDlg_delete_event      (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_WarningDisplayDlg_destroy           (GtkObject       *object,
                                        gpointer         user_data);

void
on_WarningDisplayDlg_DisplayTonerLow_checkbutton_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_WarningDisplayDlg_OK_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_WarningDisplayDlg_Cancel_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_warning_display_details_activate    (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

gboolean
on_WarningDetails_dialog_delete_event  (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_WarningDetails_dialog_destroy       (GtkObject       *object,
                                        gpointer         user_data);

void
on_WarningDetailsDlg_OK_button_clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_WarningDetailsDlg_Cancel_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);


void
on_mobile_print_settings_activate      (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

gboolean
on_MobilePrint_dialog_delete_event     (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_MobilePrint_dialog_destroy          (GtkObject       *object,
                                        gpointer         user_data);

void
on_MobilePrintDlg_OK_button_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_MobilePrintDlg_Cancel_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_action_when_paper_size_mismatch_settings_activate
                                        (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

gboolean
on_PaperSizeCheck_dialog_delete_event  (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_PaperSizeCheck_dialog_destroy       (GtkObject       *object,
                                        gpointer         user_data);

void
on_PaperSizeCheckDlg_OK_button_clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_PaperSizeCheckDlg_Cancel_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_select_language_for_user_data_list_activate
                                        (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

gboolean
on_ReportPrint_dialog_delete_event     (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_ReportPrint_dialog_destroy          (GtkObject       *object,
                                        gpointer         user_data);

void
on_ReportPrintDlg_OK_button_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_ReportPrintDlg_Cancel_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_switch_paper_feed_method_activate   (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

gboolean
on_SwitchPaperFeed_dialog_delete_event
                                        (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_SwitchPaperFeed_dialog_destroy
                                        (GtkObject       *object,
                                        gpointer         user_data);

void
on_SwitchPaperFeedDlg_OK_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_SwitchPaperFeedDlg_Cancel_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_user_data_list_activate             (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_pcl_font_list_activate              (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_enter_cancel_firmware_update_mode_activate
                                        (GtkMenuItem     *menuitem,
                                        gpointer         user_data);


gboolean
on_pc_scr_dialog_delete_event
										(GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

void
on_pc_scr_dialog_destroy
										(GtkObject       *object,
                                        gpointer         user_data);

void
on_pc_access_purchasing_site_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_pc_scr_dialog_ok_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_pc_scr_dialog_cancel_button_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);
