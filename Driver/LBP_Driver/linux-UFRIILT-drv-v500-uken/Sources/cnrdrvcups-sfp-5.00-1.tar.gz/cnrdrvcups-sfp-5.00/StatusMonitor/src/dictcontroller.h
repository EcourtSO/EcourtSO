/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#ifndef _DICTCONTROLLER
#define _DICTCONTROLLER

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>

typedef enum {
       DICT_TYPE_NUMBER = 1,
       DICT_TYPE_STRING,
       DICT_TYPE_DICT
}dict_type;

enum {
       DICT_SET_RETURN_SAME = 0x00,
       DICT_SET_RETURN_CHANGE = 0x01,
       DICT_SET_RETURN_ERROR = 0x02,
       DICT_SET_RETURN_CHECKERROR = 0x04
};

typedef struct{
       const char* pKeyName;
       dict_type type;
       GList* value;
       void* next;
}Dict;

Dict* CreateDict(Dict* const dict, const char* const pKeyName, const dict_type type, GList* const value);
Dict* CreateDict_Number_Value( Dict* const dict, const char* const pKeyName, int* const pValue );
Dict* CreateDict_String_Value( Dict* const dict, const char* const pKeyName, const char* const pValue );
Dict* CreateDict_Dict_Value( Dict* const dict, const char* const pKeyName, Dict* const pValue );
Dict* GetDict_forkey(Dict* const dict, const char* const pKeyName);
GList* GetDictValueGList_forKey(Dict* const dict, const char* const pKeyName );
gboolean GetDictValuetype_int( const Dict* const dict, int* const pValue );
char* GetDictValuetype_char( const Dict* const dict );
Dict* GetDictValuetype_Dict( const Dict* const dict );
GList* GetDictValuetype_GList(const Dict* const dict);
gboolean CompareGListValue( GList* const List1, GList* const List2, const dict_type type );
unsigned int SetDictValuetype_int(Dict* const dict, const int value);
unsigned int SetDictValuetype_char(Dict* const dict, const char* const value);
GList* GetDictValueGList_forKey(Dict* const dict, const char* const pKeyName );
char* GetDictValueString_forKey(Dict* const dict, const char* const pKeyName );
gboolean GetDictValueInt_forKey(Dict* const dict, const char* const pKeyName, int* const pValue );
Dict* GetDictValueDict_forKey(Dict* const dict, const char* const pKeyName );

void DeleteDict(Dict* dict );

void DebugOutputDict(Dict* dict);

#endif

