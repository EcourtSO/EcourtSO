/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#ifndef _VALUE_DEFINENS
#define _VALUE_DEFINENS

#define DAY_OF_WEEK_0			"0"
#define DAY_OF_WEEK_MON			"Monday"
#define DAY_OF_WEEK_TUE			"Tuesday"
#define DAY_OF_WEEK_WED			"Wednesday"
#define DAY_OF_WEEK_THU			"Thursday"
#define DAY_OF_WEEK_FRI			"Friday"
#define DAY_OF_WEEK_SAT			"Saturday"
#define DAY_OF_WEEK_SUN			"Sunday"
#define MPTRAY_STR				"MPTray"
#define CS1_STR					"CS1"
#define CS2_STR					"CS2"
#define CS3_STR					"CS3"
#define CS4_STR					"CS4"
#define CS2OVER_STR				"CS2OVER"
#define CS3OVER_STR				"CS3OVER"
#define CS4OVER_STR				"CS4OVER"
#define DUPLEX_STR				"Duplex"
#define NIC_STR					"NIC"
#define WLAN_STR				"Wlan"
#define FDTRAY_STR				"FDTray"
#define FUTRAY_STR				"FUTray"
#define CRGTYPE1_STR			"CrgType1"
#define CRGTYPE2_STR			"CrgType2"
#define ERR_SKIP_STR			"ErrorSkip"
#define SETTING_STR				"Setting"
#define UTILITY_STR				"Utility"
#define NIC_UTIL_STR			"NICUtil"
#define CONSUMABLE_STR			"Consumable"
#define CALIBRATION_STR			"Calibration"
#define NEED_SET_TIME_STR		"NeedSetTime"
#define SHOWWARNINGDISPLAYDETAILS_STR	"ShowWarningDisplayDetails"
#define CHANGEFIRMUPDATEMODE_STR		"ChangeFirmUpdateMode"
#define JM_MPTRAY_STR			"JM_MPTray"
#define JM_CS1_STR				"JM_CS1"
#define JM_CS2_STR				"JM_CS2"
#define JM_CS3_STR				"JM_CS3"
#define JM_CS4_STR				"JM_CS4"
#define JM_DUPLEX_STR			"JM_Duplex"
#define JM_OUTPUT_STR			"JM_Output"
#define JM_REAR_COVER_STR		"JM_RearCover"
#define JM_FRONT_COVER_STR		"JM_FrontCover"
#define JM_UPPER_COVER_STR		"JM_UpperCover"
#define CV_FRONT_STR			"CV_Front"
#define CV_UPPER_STR			"CV_Upper"
#define CV_REAR_STR				"CV_Rear"
#define WT_CLEANING_STR			"WT_Cleaning"
#define WT_INIT_STR				"WT_Initial"
#define WT_CALIB_STR			"WT_Calib"
#define WT_REGI_STR				"WT_Regi"
#define WT_EJECTPAPER_STR		"WT_EjectPaper"
#define WT_LIFTUP_STR			"WT_LiftUp"
#define OW_CALIB_FAIL_STR		"OW_CalibFail"
#define OW_REGI_FAIL_STR		"OW_RegiFail"
#define OW_BELT_CLEANING_STR	"OW_BeltCleaning"
#define OW_CRG_ACCESS_STR		"OW_CRG_Access"
#define OW_CIS_SENSOR_NG_STR	"OW_CISSensorNG"
#define OW_FUSER_LIFE_WARN_STR	"OW_FUserLifeWarn"
#define DRUM_K_STR				"Drum_Black"
#define DRUM_C_STR				"Drum_Cyan"
#define DRUM_M_STR				"Drum_Magenta"
#define DRUM_Y_STR				"Drum_Yellow"
#define TONER_K_STR				"Toner_Black"
#define TONER_C_STR				"Toner_Cyan"
#define TONER_M_STR				"Toner_Magenta"
#define TONER_Y_STR				"Toner_Yellow"
#define OPC_STR					"OPC"
#define PAPER_SIZE_FREE					"Size_Free"
#define PAPER_SIZE_ISO_A3				"Size_A3"
#define PAPER_SIZE_JIS_B4				"Size_B4"
#define PAPER_SIZE_ISO_A4				"Size_A4"
#define PAPER_SIZE_JIS_B5				"Size_B5"
#define PAPER_SIZE_ISO_A5				"Size_A5"
#define PAPER_SIZE_NA_LETTER			"Size_Letter"
#define PAPER_SIZE_NA_LEGAL				"Size_Legal"
#define PAPER_SIZE_LEDGER				"Size_Ledger"
#define PAPER_SIZE_EXECUTIVE			"Size_Exective"
#define PAPER_SIZE_STATEMENT			"Size_Statment"
#define PAPER_SIZE_FOOLSCAP				"Size_Foolscap"
#define PAPER_SIZE_K8					"Size_8K"
#define PAPER_SIZE_K16					"Size_16K"
#define PAPER_SIZE_JIS_N3_ENVELOPE		"Size_Envelope_N3"
#define PAPER_SIZE_JIS_K2_ENVELOPE		"Size_Envelope_K2"
#define PAPER_SIZE_YN3_ENVELOPE			"Size_Envelope_Y3"
#define PAPER_SIZE_C5_ENVELOPE			"Size_Envelope_C5"
#define PAPER_SIZE_COM10_ENVELOPE   	"Size_Envelope_Com10"
#define PAPER_SIZE_NA_MONARCH_ENVELOPE 	"Size_Envelope_Monarch"
#define PAPER_SIZE_DL_ENVELOPE			"Size_Envelope_DL"
#define PAPER_SIZE_HAGAKI				"Size_Hagaki"
#define PAPER_SIZE_HAGAKI_X2			"Size_Hagaki_X2"
#define PAPER_SIZE_HAGAKI_X4			"Size_Hagaki_X4"
#define PAPER_SIZE_INDEXCARD			"Size_IndexCard"
#define PAPER_SIZE_OFICIO               "Size_Oficio"
#define PAPER_SIZE_B_OFICIO             "Size_B_Oficio"
#define PAPER_SIZE_M_OFICIO             "Size_M_Oficio"
#define PAPER_SIZE_G_LETTER				"Size_G_Letter"
#define PAPER_SIZE_G_LEGAL				"Size_G_Legal"
#define PAPER_SIZE_INDIAN_LEGAL			"Size_Indian_Legal"
#define PAPER_SIZE_A_FOOLSCAP			"Size_A_Foolscap"
#define PAPER_SIZE_USER_PAPER			"Size_User_Paper"
#define PAPER_TYPE_ANY			"Type_Free"
#define PAPER_TYPE_STATIONARY	"Type_Stationary"
#define PAPER_TYPE_STATIONARY2	"Type_Stationary2"
#define PAPER_TYPE_FLIMSY		"Type_Flimsy"
#define PAPER_TYPE_FLIMSY2		"Type_Flimsy2"
#define PAPER_TYPE_PASTEBOARD	"Type_Pasteboard1"
#define PAPER_TYPE_PASTEBOARD2	"Type_Pasteboard2"
#define PAPER_TYPE_PASTEBOARD3	"Type_Pasteboard3"
#define PAPER_TYPE_GLOSSY		"Type_Glossy"
#define PAPER_TYPE_TRANS		"Type_Trans"
#define PAPER_TYPE_LABELS		"Type_Labels"
#define PAPER_TYPE_COATED1		"Type_Coated1"
#define PAPER_TYPE_COATED2		"Type_Coated2"
#define PAPER_TYPE_COATED3		"Type_Coated3"
#define PAPER_TYPE_COATED4		"Type_Coated4"
#define PAPER_TYPE_POST_CARD	"Type_PostCard"
#define PAPER_TYPE_ENV			"Type_Env"
#define PAPER_TYPE_ENV2			"Type_Env2"
#define PAPER_TYPE_ROUGH1		"Type_Rough1"
#define PAPER_TYPE_ROUGH2		"Type_Rough2"
#define PAPER_TYPE_ROUGH3		"Type_Rough3"
#define PAPER_TYPE_COLOR		"Type_Color"
#define PAPER_TYPE_RECYCLED		"Type_Recycled"
#define ORIENTATION_SHORT_EDGE	"Orientation_Short_Edge"
#define ORIENTATION_LONG_EDGE	"Orientation_Long_Edge"
#define AREA_INFO_JP			"Japan"
#define AREA_INFO_NORTH_AMERICA	"North America"
#define AREA_INFO_CHINA			"China"
#define AREA_INFO_EU			"Europe"
#define AREA_INFO_ASIA			"Asia"
#define AREA_INFO_KOREA			"Korea"
#define AREA_INFO_TAIWAN		"Taiwan"
#define AREA_INFO_OCEANIA		"Oceania"
#define CUSTOM_UNIT_INCH		"inch"
#define CUSTOM_UNIT_MM			"mm"
#define WLAN_STATUS_STOP		"Stop"
#define WLAN_STATUS_DISCONNECT	"DisConnect"
#define WLAN_STATUS_CONNECT		"Connect"
#define WLAN_RSSI_VERY_BAD		"Verybad"
#define WLAN_RSSI_BAD			"Bad"
#define WLAN_RSSI_NORMAL		"Normal"
#define WLAN_RSSI_GOOD			"Good"
#define WLAN_RSSI_VERY_GOOD		"VeryGood"
#define SGROUP_COMMERROR        "CommError"
#define SGROUP_MAINTENANCE		"Maintenance"
#define SGROUP_SERVICE_ERROR	"Service"
#define SGROUP_JAM				"Jam"
#define SGROUP_OTHER_ERROR		"Other"
#define SGROUP_COVER_OPEN		"Cover"
#define SGROUP_SUPPLY_ERROR		"Supply"
#define SGROUP_PAPER_ERROR		"Paper"
#define SGROUP_WAIT				"Wait"
#define SGROUP_PRINTING			"Printing"
#define SGROUP_IDLE				"Idle"
#define SGROUP_CASSETTE_OPEN	"Cassette"
#define SGROUP_OUTPUT_ERROR		"Output"
#define SGROUP_EXTRA_PAPER		"Extra"
#define SCODE_GETTINGSTATUS         "GETTINGSTATUS"
#define SCODE_PAUSEPRINTER          "PAUSEPRINTER"
#define SCODE_NICCOMMERROR          "NICCOMMERROR"
#define SCODE_LOCALCOMMERROR        "LOCALCOMMERROR"
#define SCODE_UNSUPPORTEDPRINTER    "UNSUPPORTEDPRINTER"
#define SCODE_SHUTDOWN				"SHUTDOWN"
#define SCODE_UPDATINGFIRMWARE		"UPDATINGFIRMWARE"
#define SCODE_UPDATINGFIRMWAREMODE	"UPDATINGFIRMWAREMODE"
#define SCODE_TONERROTATEOPEN		"TONERROTATEOPEN"
#define SCODE_TONERROTATECLOSE		"TONERROTATECLOSE"
#define SCODE_SERVICEERROR			"SERVICEERROR"
#define SCODE_PAPERJAM				"PAPERJAM"
#define SCODE_DISINTEGRATIONERROR	"DISINTEGRATIONERROR"
#define SCODE_SHIPPINGLOCKERROR     "SHIPPINGLOCKERROR"
#define SCODE_COVEROPEN				"COVEROPEN"
#define	SCODE_DUPLEXCONNECTIONERROR	"DUPLEXCONNECTIONERROR"
#define	SCODE_CASSETTECONNECTIONERROR	"CASSETTECONNECTIONERROR"
#define	SCODE_SETDUPLEXUNIT			"SETDUPLEXUNIT"
#define	SCODE_OUTTRAYOPEN			"OUTTRAYOPEN"
#define	SCODE_OUTTRAYFULL			"OUTTRAYFULL"
#define	SCODE_PAPEROVER				"PAPEROVER"
#define	SCODE_CASSETTEOPEN			"CASSETTEOPEN"
#define SCODE_NODRUMCRG				"NODRUMCRG"
#define SCODE_MISPLACEDTONER		"MISPLACEDTONER"
#define SCODE_NOTONERCRG			"NOTONERCRG"
#define SCODE_SEALEDTONERCRG		"SEALEDTONERCRG"
#define SCODE_DRUMMEMERROR			"DRUMMEMERROR"
#define SCODE_TONERMEMERROR			"TONERMEMERROR"
#define SCODE_TONEROUT2				"TONEROUT2"
#define SCODE_DRUMOUT1				"DRUMOUT1"
#define SCODE_TONEROUT1				"TONEROUT1"
#define SCODE_TONEROUT3				"TONEROUT3"
#define SCODE_DRUMOUT2				"DRUMOUT2"
#define SCODE_DRUMOUT3				"DRUMOUT3"
#define SCODE_MISPRINT				"MISPRINT"
#define SCODE_PAPERMISMATCH			"PAPERMISMATCH"
#define SCODE_CHANGEPAPER			"CHANGEPAPER"
#define SCODE_ADDPAPER				"ADDPAPER"
#define SCODE_CHECKPAPER			"CHECKPAPER"
#define SCODE_SETCLEANINGPAGE		"SETCLEANINGPAGE"
#define SCODE_REMOVEPAPER			"REMOVEPAPER"
#define SCODE_MEMORYFULL			"MEMORYFULL"
#define SCODE_WAIT					"WAIT"
#define SCODE_CLEANING				"CLEANING"
#define SCODE_COOLING				"COOLING"
#define SCODE_CLEANINGJOB			"CLEANINGJOB"
#define SCODE_PRINTING				"PRINTING"
#define SCODE_ABORTING				"ABORTING"
#define SCODE_ANYTONEROUT			"ANYTONEROUT"
#define SCODE_ANYTONEROUT2			"ANYTONEROUT2"
#define SCODE_ANYDRUMOUT			"ANYDRUMOUT"
#define SCODE_ANYDRUMOUT2			"ANYDRUMOUT2"
#define SCODE_SLEEP					"SLEEP"
#define SCODE_STANDBY				"STANDBY"
#define MODEL_LBP7100_WLAN			"LBP7100_WLAN"
#define MODEL_LBP7100_WLANAOSS		"LBP7100_WLANAOSS"
#define MODEL_LBP7100_LAN			"LBP7100_LAN"
#define MODEL_LBP6030				"LBP6030"
#define MODEL_LBP6030_WLAN			"LBP6030_WLAN"
#define MODEL_LBP6230				"LBP6230"
#define MODEL_LBP6230_WLAN			"LBP6230_WLAN"
#define MODEL_LBP8100				"LBP8100"
#define MODEL_CNABK_WLAN			"CNABK_WLAN"
#define JOB_INFO_STATUS_PREPROCESS		"PreProcess"
#define JOB_INFO_STATUS_PROCESS			"Process"
#define JOB_INFO_STATUS_WAITEXECUTE		"WaitExecute"
#define JOB_INFO_STATUS_EXECUTING		"Executing"
#define JOB_INFO_STATUS_COMPLETED		"Completed"
#define JOB_INFO_STATUS_PAUSED			"Paused"
#define JOB_INFO_STATUS_PAUSING			"Pausing"
#define JOB_INFO_STATUS_INTERACTION		"Interaction"
#define JOB_INFO_STATUS_WAITINTERACTION	"WaitInteraction"
#define JOB_INFO_STATUS_CONTINUING		"Continuing"
#define JOB_INFO_STATUS_TERMINATING		"Terminating"
#define WLAN_INTERFACE_SETTING_WIRED		"Wired"
#define WLAN_INTERFACE_SETTING_WIRERESS		"Wireress"
#define WLAN_SECURITY_NONE					"none"
#define WLAN_SECURITY_WEP					"WEP"
#define WLAN_SECURITY_WPAPSK				"WPA-PSK"
#define WLAN_SECURITY_WPA2PSK				"WPA2-PSK"
#define WLAN_RESULT_STATUS_INVALID			"Invalid"
#define WLAN_RESULT_STATUS_VALID			"Valid"
#define WLAN_CONNECT_NOERROR				"NoError"
#define WLAN_CONNECT_ERROR					"Error"
#define IPV4_AUTO_GET_ADDR_MANUAL			"Manual"
#define IPV4_AUTO_GET_ADDR_AUTO				"Auto"
#define IPV4_AUTOIP_ON						"ON"
#define IPV4_AUTOIP_OFF						"OFF"
#define IPV4_PROTOCOL_OFF					"OFF"
#define IPV4_PROTOCOL_DHCP					"DHCP"
#define IPV4_PROTOCOL_BOOTP					"BOOTP"
#define IPV4_PROTOCOL_RARP					"RARP"
#define WPA_SETTINGS_WPA_SECURITY_AUTO		"Auto"
#define WPA_SETTINGS_WPA_SECURITY_AESCOMP	"AES-COMP"
#define WPA_SETTINGS_PSK_INPUT_ASCII		"ASCII"
#define WPA_SETTINGS_PSK_INPUT_HEX			"Hex"
#define WPA_SETTINGS_WEP_LENGTH_40BIT		"40bit"
#define WPA_SETTINGS_WEP_LENGTH_104BIT		"104bit"
#define WPA_SETTINGS_WEP_INPUT_40BITASCII	"40bitASCII"
#define WPA_SETTINGS_WEP_INPUT_104BITASCII	"104bitASCII"
#define WPA_SETTINGS_WEP_INPUT_40BITHEX		"40bitHex"
#define WPA_SETTINGS_WEP_INPUT_104BITHEX	"104bitHex"
#define WPA_SETTINGS_80211AUTH_OPEN			"Open"
#define WPA_SETTINGS_80211AUTH_COMMON		"Common"
#define NCAP_VALUE_OFF						"OFF"
#define NCAP_VALUE_MODE1					"Mode1"
#define NCAP_VALUE_MODE2					"Mode2"
#define NCAP_VALUE_MODE3					"Mode3"
#define NCAP_VALUE_MODE4					"Mode4"
#define NCAP_VALUE_SPEED					"Speed"
#define NCAP_VALUE_QUALITY					"Quality"
#define NCAP_VALUE_GRADATION				"Gradation"
#define NCAP_VALUE_DITHERING				"Dithering"
#define NCAP_VALUE_DISPLAYERROR				"DisplayError"
#define NCAP_VALUE_FORCEPRINT				"ForcePrint"
#define NCAP_VALUE_PRINTSIDE				"Printside"
#define NCAP_VALUE_LANGENGLISH				"LangEnglish"
#define NCAP_VALUE_LANGFRENCH				"LangFrench"
#define NCAP_VALUE_LANGSPANISH				"LangSpanish"
#define NCAP_VALUE_LANGGERMAN				"LangGerman"
#define NCAP_VALUE_LANGITALIAN				"LangItalian"
#define NCAP_VALUE_LANGDUTCH				"LangDutch"
#define NCAP_VALUE_LANGPORTUGUESE			"LangPortuguese"
#define NCAP_VALUE_LANGRUSSIAN				"LangRussian"
#define NCAP_VALUE_LANGNORWEGIAN			"LangNorwegian"
#define NCAP_VALUE_LANGFINNISH				"LangFinnish"
#define NCAP_VALUE_LANGSWEDISH				"LangSwedish"
#define NCAP_VALUE_LANGDANISH				"LangDanish"
#define NCAP_VALUE_LANGPOLISH				"LangPolish"
#define NCAP_VALUE_LANGCZECH				"LangCzech"
#define NCAP_VALUE_LANGHUNGARIAN			"LangHungarian"
#define NCAP_VALUE_LANGTURKISH				"LangTurkish"
#define NCAP_VALUE_LANGCHNSIMPLIFIED		"LangCHNSimplified"
#define NCAP_VALUE_LANGKOREAN				"LangKorean"
#define NCAP_VALUE_LANGTHAI					"LangThai"
#define NCAP_VALUE_LANGVIETNAMESE			"LangVietnamese"
#define NCAP_VALUE_LANGMALAY				"LangMalay"
#define NCAP_VALUE_LANGARABIC				"LangArabic"
#define NCAP_VALUE_LANGBASQUE				"LangBasque"
#define NCAP_VALUE_LANGCATALAN				"LangCatalan"
#define NCAP_VALUE_STOP						"Stop"
#define NCAP_VALUE_MACOS					"MacOS"
#define NCAP_VALUE_WINDOWS					"Windows"
#define NCAP_VALUE_OTHER					"Other"
#define NCAP_VALUE_AUTO						"Auto"
#define NCAP_VALUE_THIN						"Thin"
#define NCAP_VALUE_SLIGHTLY_THIN			"SlightlyThin"
#define NCAP_VALUE_SLIGHTLY_THICK			"SlightlyThick"
#define NCAP_VALUE_EEEE						"Thick"


enum {
	COMMAND_GET_STATUS = 0,
	COMMAND_GET_CONSUMABLE_STATUS,
	COMMAND_GET_JOB_ID_LIST,
	COMMAND_GET_JOB_INFO,
	COMMAND_JOB_OPERATION,
	COMMAND_GET_DATA,
	COMMAND_DEVICE_OPERATION,
	COMMAND_SET_DATA,
	COMMAND_GET_DATE_TIME,
	COMMAND_SET_DATE_TIME,
	COMMAND_GET_ALL_JOB_INFO
};

enum {
	ERROR_NIC = 1,
	ERROR_USB,
	ERROR_GENERIC,
	ERROR_UNKNOWN_COMMAND,
	ERROR_INVALID_PARAM,
	ERROR_NOT_EXECUTABLE,
	ERROR_EXECUTION,
	ERROR_TOO_MANY_PARAM,
	ERROR_DOWNLOADER_READY,
	ERROR_DOWNLOADER_UPDATE
};

enum {
	JOB_OPERATION_ERROR_SKIP = 0,
	JOB_OPERATION_CANCEL
};

enum {
	DEVICE_OPERATION_CALIBRATION = 0,
	DEVICE_OPERATION_CPR,
	DEVICE_OPERATION_FUSER_CLEANING,
	DEVICE_OPERATION_ITBCLEANING,
	DEVICE_OPERATION_LEAVE_SLEEP,
	DEVICE_OPERATION_REBOOT,
	DEVICE_OPERATION_GETCRGCOUNTER,
    DEVICE_OPERATION_WLANWPSPIN,
    DEVICE_OPERATION_WLANWPSPINSTATUS,
    DEVICE_OPERATION_WLANSCAN,
    DEVICE_OPERATION_WLANSCANSTATUS,
    DEVICE_OPERATION_WLANCONNECT,
    DEVICE_OPERATION_WLANCONNECTSTATUS,
    DEVICE_OPERATION_WLANINTERFACECHANGE,
    DEVICE_OPERATION_WLANINTERFACECHANGESTATUS,
    DEVICE_OPERATION_CHANGEFIRMWAREUPDATEMODE,
    DEVICE_OPERATION_LISTPRINT,
    DEVICE_OPERATION_NETWORKSETTINGREFLECT,
};

enum {
	CRG_COUNTER_BLACK = 0,
	CRG_COUNTER_YELLOW,
	CRG_COUNTER_CYAN,
	CRG_COUNTER_MAGENTA
};
enum {
    OPERATION_IDLE = 1,
    OPERATION_EXECUTION,
    OPERATION_GENERATED,
    OPERATION_CONNECTING,
    OPERATION_END,
    OPERATION_CANCEL,
    OPERATION_CANCEL_END
};

enum {
	FIRMUPDATEMODE_CANCEL = 0,
	FIRMUPDATEMODE_SHIFT
};

enum {
	PRINT_PCLFONT = 0,
	PRINT_USERDATA,
};

#endif
