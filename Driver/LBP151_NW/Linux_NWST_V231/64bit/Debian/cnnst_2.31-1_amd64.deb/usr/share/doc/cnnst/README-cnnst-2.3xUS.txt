=================================================================================
Canon MF/LBP Network Setup Tool Version 2.31

PLEASE READ THIS DOCUMENT CAREFULLY
=================================================================================

PRECAUTIONS

Please note the following restrictions when using this software.

1. The software can detect up to 10 wireless LAN access points by searching for 
wireless LAN access points. 

2. The software cannot detect wireless LAN access points by searching for 
wireless LAN access points when the wireless LAN access points are using a 
stealth function. 

3. When the printer firmware is being updated, or immediately after the power 
switch is turned ON or OFF, or when the printer is printing, it is not possible 
to make configuration settings using this software. 

4. Depending on your operational environment, the "Useful Tips" cannot be 
displayed directly from this software.
In this case, follow the on-screen message to display the "Useful Tips" from the 
Web browser you are using.

=================================================================================
                                                        Copyright CANON INC. 2014
