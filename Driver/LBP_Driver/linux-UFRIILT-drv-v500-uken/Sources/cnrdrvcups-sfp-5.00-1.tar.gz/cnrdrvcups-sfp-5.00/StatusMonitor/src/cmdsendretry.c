/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#include <pthread.h>
#include <gtk/gtk.h>
#include "cmdsendretry.h"
#include "callbacks.h"
#include "msgdlg.h"
#include "commandcontroller.h"

void*
threadSendRetry(void* arg)
{
	retryCmd* const pRetryCmd = (retryCmd*)arg;

	if( pRetryCmd != NULL )
	{
		EnterCriticalSection(&g_USBRetrySection);

		pRetryCmd->result =  SendData(pRetryCmd->wnd, pRetryCmd->code, TRUE);

		LeaveCriticalSection(&g_USBRetrySection);

		if(pRetryCmd->msgid == ID_USBWAIT_MSGDLG1)
		{
			g_idle_add_full(G_PRIORITY_HIGH_IDLE, on_Msg_dialog_hide_from_thread, pRetryCmd->wnd, NULL);
		}
	}

	return NULL;
}

int
cmdSendRetry(UIStatusWnd* const wnd, UIDialog* const parent, const int code, const int msgId)
{
	int nRet = COMM_HOST_ERROR;

	if( wnd != NULL )
	{
		wnd->pauseGetStatus = TRUE;
		pthread_t USBCommThread;

		retryCmd stRetryCmd = {0};
		stRetryCmd.wnd = wnd;
		stRetryCmd.code = code;
		stRetryCmd.msgid = msgId;
		stRetryCmd.result = COMM_HOST_ERROR;

		if(msgId == ID_USBWAIT_MSGDLG1)
		{
			EnterCriticalSection(&g_USBRetrySection);
		}

		if(pthread_create(&USBCommThread, NULL, threadSendRetry, (void *)&stRetryCmd) == 0)
		{
			if(msgId == ID_USBWAIT_MSGDLG1)
			{
				ShowChildMsgDlg(wnd, parent, msgId);
			}

			if(pthread_join(USBCommThread, NULL) == 0)
			{
				nRet = stRetryCmd.result;
			}
			else
			{
				nRet = COMM_HOST_ERROR;
			}
		}

		wnd->pauseGetStatus = FALSE;
	}

	return nRet;
}
