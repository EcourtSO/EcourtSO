/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2015 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "uimain.h"
#include "widgets.h"
#include "interface.h"
#include "papersizecheckdlg.h"

#include "callbacks.h"
#include "support.h"
#include "id_defines.h"
#include "commandcontroller.h"
#include "value_defines.h"


CtrlTbl* PPDCtrlTbl[CTRL_LIST_MAXNUM];

static ComboBoxContent paperSizeMismatchActionContents[] =
{
	{ N_("Force Output"), NCAP_VALUE_FORCEPRINT, },
	{ N_("Display Error"), NCAP_VALUE_DISPLAYERROR, },
	{ NULL, NULL, }
};

static CtrlTbl ctrlTbl[] =
{
	{ ID_PAPERSIZECHECK_DIALOG1, LABEL_TYPE_TITLE, NULL,
		N_("Action When Paper Size Mismatch Settings"), NULL, 0 },

	{ ID_CTRLPAPERSIZEMISMATCHACTION, LABEL_TYPE_TEXT, "PaperSizeCheckDlg_PaperSizeMismatchAction_label",
		N_("Action When Paper Size Mismatch:"), "PaperSizeCheckDlg_PaperSizeMismatchAction_box", ID1803 },

	{ -1, -1, NULL, NULL, NULL, -1 }
};

static int InitPaperSizeCheckDlgWidgets( UIStatusWnd* const wnd );
static unsigned int SetItemValue_PaperSizeCheckDlgOK( const UIStatusWnd* const wnd );

UIPaperSizeCheckDlg* CreatePaperSizeCheckDlg(UIDialog* const parent)
{
	UIPaperSizeCheckDlg *pDialog = NULL;

	pDialog = (UIPaperSizeCheckDlg *)CreateDialog(sizeof(UIPaperSizeCheckDlg), parent);
	if( pDialog != NULL )
	{
		UI_DIALOG(pDialog)->window = create_PaperSizeCheck_dialog();
	}
	return pDialog;
}

void ShowPaperSizeCheckDlg( UIStatusWnd* const wnd )
{
	int nRet = 0;

	if( wnd == NULL )
	{
		return;
	}
	if( wnd->papersizecheck_dlg == NULL )
	{
		wnd->papersizecheck_dlg = CreatePaperSizeCheckDlg( UI_DIALOG( wnd ) );
	}

	SigDisable();
	nRet = InitPaperSizeCheckDlgWidgets( wnd );
	SigEnable();

	if( nRet == 0 )
	{
		ShowDialog( (UIDialog *)wnd->papersizecheck_dlg, NULL );
	}
	else
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_GET );
		if( wnd->papersizecheck_dlg != NULL )
		{
			if( wnd->papersizecheck_dlg->pDialogDict != NULL )
			{
				DeleteDict( wnd->papersizecheck_dlg->pDialogDict );
				wnd->papersizecheck_dlg->pDialogDict = NULL;
			}
			mem_free( wnd->papersizecheck_dlg );
			wnd->papersizecheck_dlg = NULL;
		}
	}
}

static unsigned int SetItemValue_PaperSizeCheckDlgOK( const UIStatusWnd* const wnd )
{
	int i = 0;
	unsigned int unRet = 0;

	if( wnd == NULL )
	{
		UI_DEBUG("SetItemValue_PaperSizeCheckDlgOK PPDCtrlTbl[%p] wnd[%p]\n", PPDCtrlTbl, wnd);
		return DICT_SET_RETURN_ERROR;
	}

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		switch( PPDCtrlTbl[i]->dbid )
		{
		case ID1803:
			{
				const char* pValue = NULL;

				pValue = GetComboBoxSelectedValue( wnd->papersizecheck_dlg->pPaperSizeMismatchActionComboBoxItem );
				if( pValue != NULL )
				{
					unRet |= SetItemValuetype_char( wnd->papersizecheck_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, pValue );
					UI_DEBUG("SetItemValue_PaperSizeCheckDlgOK unRet[%d]\n", unRet);
				}
			}
			break;
		default:
			break;
		}
		if( (unRet & DICT_SET_RETURN_ERROR) == DICT_SET_RETURN_ERROR )
		{
			break;
		}
	}
	return unRet;
}

void PaperSizeCheckDlgOK( UIStatusWnd* const wnd )
{
	int nRet = 0;
	unsigned int unRet = 0;

	if( wnd == NULL )
	{
		return;
	}
	else
	{
		nRet = CreateDict_SetData( wnd->papersizecheck_dlg->pDialogDict );
	}

	if( nRet == 0 )
	{
		unRet = SetItemValue_PaperSizeCheckDlgOK( wnd );
		if( (unRet & DICT_SET_RETURN_ERROR) == DICT_SET_RETURN_ERROR )
		{
			nRet = -1;
		}
	}

	if( ( nRet == 0 ) && ( unRet == DICT_SET_RETURN_CHANGE ) )
	{
		nRet = CommunicatePrinterData( wnd, (UIDialog *)wnd->papersizecheck_dlg, wnd->papersizecheck_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	}

	HideDialog( (UIDialog *)wnd->papersizecheck_dlg );

	if( nRet != 0 )
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_SET );
	}

	return;
}

static int InitPaperSizeCheckDlgWidgets( UIStatusWnd* const wnd )
{
	GtkWidget *pWindow = NULL;
	GList *pGlist = NULL;
	int i = 0;
	int nRet = 0;
	const char* const ctrl_type[] = { "CNSUIPaperSizeCheckDlg", "CNSUICtrlPaperSizeMismatchAction", NULL };

	if( wnd == NULL )
	{
		return -1;
	}

	if( wnd->papersizecheck_dlg == NULL )
	{
		return -1;
	}
	else
	{
		pWindow = wnd->papersizecheck_dlg->dialog.window;
	}

	CreatePPDCtrlTbl( wnd, ctrl_type, ctrlTbl, PPDCtrlTbl );

	SetLabel_HideWidget( pWindow, PPDCtrlTbl, ctrlTbl );

	pGlist = CreateGlist_DbId( PPDCtrlTbl );

	if( wnd->papersizecheck_dlg->pDialogDict != NULL )
	{
		UI_DEBUG("pDialogDict no mem_free, from Func[%s] Line[%u] \n", __func__, __LINE__);
		DeleteDict( wnd->papersizecheck_dlg->pDialogDict );
	}
	wnd->papersizecheck_dlg->pDialogDict = CretateDict_GetData( pGlist );
	g_list_free_wrapper( pGlist );
	pGlist = NULL;

	if( wnd->papersizecheck_dlg->pDialogDict == NULL )
	{
		return -1;
	}

	nRet = CommunicatePrinterData( wnd, NULL, wnd->papersizecheck_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	if( nRet != 0 )
	{
		return -1;
	}

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		switch( PPDCtrlTbl[i]->dbid )
		{
		case ID1803:
			if( wnd->papersizecheck_dlg->pPaperSizeMismatchActionComboBoxItem == NULL )
			{
				wnd->papersizecheck_dlg->pPaperSizeMismatchActionComboBoxItem = CreateComboBoxItem( pWindow, wnd->pModData,
					"CNSUIPaperSizeMismatchActionList", "PaperSizeCheckDlg_PaperSizeMismatchAction_combo", paperSizeMismatchActionContents );
			}

			if( wnd->papersizecheck_dlg->pPaperSizeMismatchActionComboBoxItem == NULL )
			{
				nRet = -1;
			}
			else
			{
				const char* pValue = NULL;

				pValue = GetItemValueType_char( wnd->papersizecheck_dlg->pDialogDict, PPDCtrlTbl[i]->dbid );
				if( pValue == NULL )
				{
					nRet = -1;
				}
				else
				{
					SetComboBoxSelectedValue(wnd->papersizecheck_dlg->pPaperSizeMismatchActionComboBoxItem, pValue);
				}
			}
			break;
		default:
			break;
		}
	}

	return nRet;
}

void DisposePaperSizeCheckDlg( UIStatusWnd* const wnd )
{
	UIPaperSizeCheckDlg* ui_dialog = NULL;

	if(wnd == NULL)
	{
		return;
	}

	ui_dialog = wnd->papersizecheck_dlg;
	if( ui_dialog != NULL )
	{
		if( ui_dialog->pPaperSizeMismatchActionComboBoxItem != NULL )
		{
			DisposeComboBoxItem(ui_dialog->pPaperSizeMismatchActionComboBoxItem);
			ui_dialog->pPaperSizeMismatchActionComboBoxItem = NULL;
		}

		if( ui_dialog->pDialogDict != NULL )
		{
			DeleteDict( ui_dialog->pDialogDict );
			ui_dialog->pDialogDict = NULL;
		}

		DisposeDialog( (UIDialog *)ui_dialog );
		wnd->papersizecheck_dlg = NULL;
	}
}

