/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>

#include "support.h"
#include "callbacks.h"
#include "uimain.h"
#include "widgets.h"
#include "statusinfo.h"
#include "value_defines.h"

#include "cngplpmod.h"

#include "dictcontroller.h"
#include "key_defines.h"


#define CHARACTER_NEW_LINE '\n'
#define CHARACTER_DOUBLE_QUOTATION '"'
#define PREFIX_PPDKEY "CNSUI"

#define	CNSUISHOWMENU_AREA_AUTOSHUTDOWNSETTINGS	"CNSUIShowMenu_Area_AutoShutdownSettings"
#define	CNSUIPC_SCR_DIALOG						"CNSUIPC_scr_dialog"
#define	PURCHASECONSUMABLES_VBOX				"pc_vbox"
#define	ACCESS_PURCHASING_SITE_BUTTON			"pc_access_purchasing_site_button"

static int g_curr_signal;

typedef struct {
	const char *ppdkey;
	const gchar *widgetname;
	gboolean show_flag;
}UIItem;

static char *menu_type[]={"CNSUIJobMenu", "CNSUIUtilMenu", "CNSUIDevMenu","CNSUIOptionMenu", NULL};

static UIItem menu_tbl[]={
	{"CNSUIContinueRetry", "continue_retry", FALSE},
	{"CNSUICancelJob", "cancel_job", FALSE},
	{"CNSUIConsumablesDlg", "consumables_information", FALSE},
	{"CNSUICounterDlg", "counters", FALSE},
	{"CNSUIWLanStateDlg", "wireless_lan_status", FALSE},
	{"CNSUIUtilMenu", "utility", FALSE},
	{"CNSUICalibrationDlg", "calibration", FALSE},
	{"CNSUIColorMisCorrDlg", "color_mismatch_correction", FALSE},
    {"CNSUICleaningDlg", "cleaning", FALSE},
	{"CNSUICleaning1Dlg", "cleaning1", FALSE},
	{"CNSUICleaning2Dlg", "cleaning2", FALSE},
	{"CNSUIUserDataListDlg", "user_data_list", FALSE},
	{"CNSUIPCLFontListDlg", "pcl_font_list", FALSE},
	{"CNSUIUpdatingFirmwareModeDlg", "enter_cancel_firmware_update_mode", FALSE},
	{"CNSUIDevMenu", "device_settings", FALSE},
	{"CNSUISwitchPaperFeedDlg", "switch_paper_feed_method", FALSE},
	{"CNSUIPaperSizeCheckDlg", "action_when_paper_size_mismatch_settings", FALSE},
	{"CNSUIPFeedUnitDlg", "paper_source_settings", FALSE},
	{"CNSUIJobCancelDlg", "settings_for_cancel_job_key", FALSE},
	{"CNSUIWifiInvDlg", "settings_to_disable_wi_fi_key", FALSE},
	{"CNSUISleepDlg", "sleep_settings", FALSE},
	{"CNSUIAutoShutDlg", "auto_shutdown_settings", FALSE},
	{"CNSUIWarningDisplayDlg", "warning_display_settings", FALSE},
	{"CNSUIWarningDetailsDlg", "warning_display_details", FALSE},
	{"CNSUIImgAdjDlg", "image_quality_adjustment_settings", FALSE},
	{"CNSUIPORIDEDlg", "paper_size_override_settings", FALSE},
	{"CNSUIAssistDlg", "assisting_print_setting", FALSE},
	{"CNSUIMobilePrintDlg", "mobile_print_settings", FALSE},
	{"CNSUIReportPrintDlg", "select_language_for_user_data_list", FALSE},
	{"CNSUIHideMonitor", "hide_statusmonitor", FALSE},
	{NULL, NULL, FALSE},
};

static const char* ppdCrgTypeList[] = {CRGTYPE1_STR, CRGTYPE2_STR, NULL};


static UIItem *FindUIItemWithWidgetName(const gchar *widgetName);
int GetCurrDisable(const int id, const char *in);
static void UpdateMainWindowMenu(UIStatusWnd* const wnd);
char* CngplpGetValue_AddExtraKeyStr(const UIStatusWnd* const wnd, const char* const baseKeyStr, const char* const addKeyStr, const char* const extraKeyStr);
static char * joinPPDValue(const char* value1, const char* value2);
static char* getPPDValueAppendSuffixIndex(cngplpData *pModData, const char* pPPDKey);


static UIItem *FindUIItemWithWidgetName(const gchar *widgetName)
{
	UIItem	*item = NULL;

	if (widgetName != NULL)
	{
		int i = 0;

		while (menu_tbl[i].ppdkey != NULL)
		{
			if (strcmp(menu_tbl[i].widgetname, widgetName) == 0)
			{
				item = &menu_tbl[i];
				break;
			}
			i++;
		}
	}

	return item;
}

int GetCurrDisable(const int id, const char *in)
{
	return 0;
}

void SigInit(void)
{
	g_curr_signal = 0;
}

gboolean SigEnable(void)
{
	gboolean enable = TRUE;
	if(g_curr_signal > 0){
		g_curr_signal--;
		enable = FALSE;
	}
	return enable;
}

gboolean SigDisable(void)
{
	gboolean enable = TRUE;
	if(g_curr_signal)
		enable = FALSE;
	g_curr_signal++;

	return enable;
}
void ShowMenu(UIStatusWnd *wnd, char **menu_list)
{
	GtkWidget *window = UI_DIALOG(wnd)->window;
	int i=0;
	while(menu_list[i] != NULL){
		ShowWidget(window,menu_list[i]);
		i++;
	}
}
void ShowWidget(GtkWidget *window, const gchar* const widget_name)
{
        GtkWidget *widget;

        widget = getWidget(window, widget_name);
        if(widget != NULL)
                gtk_widget_show(widget);
}


void ChangeHideMainWindow(UIStatusWnd* const wnd)
{
	GtkWidget* pWindow = NULL;
	UIDialog *pUidialog = NULL;
	gboolean bHideMainWindow = FALSE;

	if(wnd == NULL)
	{
		return;
	}

	pUidialog = &(wnd->dialog);
	pWindow = pUidialog->window;

	if(pWindow == NULL)
	{
		return;
	}

	bHideMainWindow = !(wnd->isHideNowWnd);
	if(bHideMainWindow == TRUE)
	{
		gtk_widget_hide(pWindow);
	}
	else
	{
		gtk_widget_show(pWindow);
	}

	wnd->isHideNowWnd = bHideMainWindow;
}

static gboolean isShowPurchaseConsumablesRect(const UIStatusWnd* pWnd)
{
	gboolean	isShowPurchaseConsumablesRectResult = FALSE;
	if(pWnd != NULL)
	{
		char*	pPPDValue = cngplpGetValue_Wrapper(pWnd->pModData, CNSUIPC_SCR_DIALOG);
		if(pPPDValue != NULL)
		{
			isShowPurchaseConsumablesRectResult = TRUE;
			mem_free(pPPDValue);
			pPPDValue = NULL;
		}
	}

	return	isShowPurchaseConsumablesRectResult;
}

#define MAX_USB_RETRY_TIME 10

int CreateStatusWidgets( UIStatusWnd* const wnd )
{
	char *tmp = NULL;
	char **menu_tmp = NULL;

	if( wnd == NULL )
	{
		return -1;
	}

	wnd->nMaxUSBRetrySec = MAX_USB_RETRY_TIME;

	if( GetPPDValue_Integer( wnd->pModData, "CNSUICommNumber", &(wnd->nPortNum)) == FALSE )
	{
		return -1;
	}
	wnd->pDriverPath = cngplpGetData(wnd->pModData, ID_DRIVERROOTPATH);
	if( wnd->pDriverPath == NULL )
	{
		return -1;
	}
	wnd->pMngpksmncap = pksmncapCreateProcess(wnd->pDriverPath);
	if( wnd->pMngpksmncap == NULL )
	{
		return -1;
	}

	int n = 0;
	while( menu_type[n] != NULL )
	{
		tmp = cngplpGetValue_Wrapper( wnd->pModData, menu_type[n] );
		if( tmp != NULL )
		{
			menu_tmp = SeparateString( tmp, CHARACTER_COMMA );
			if( (menu_tmp != NULL) && (*menu_tmp == NULL) )
			{
				mem_free( tmp );
				break;
			}
		}

		int i = 0;
		while( menu_tbl[i].ppdkey != NULL)
		{
			if( ( menu_tmp != NULL ) && ( *menu_tmp != NULL ) )
			{
				int j = 0;
				while( menu_tmp[j] != NULL )
				{
					if( strcmp(menu_tbl[i].ppdkey, menu_tmp[j]) == 0 )
					{
						menu_tbl[i].show_flag = TRUE;
						ShowWidget( wnd->dialog.window, menu_tbl[i].widgetname );
					}
					j++;
				}
			}
			i++;
		}
		if( tmp != NULL )
		{
			mem_free( tmp );
		}
		if( menu_tmp != NULL )
		{
			mem_free_list( menu_tmp );
			menu_tmp = NULL;
		}
		n++;
	}
	SetDialogTitle( wnd->dialog.window, wnd->pPrinterName );
	if( isShowPurchaseConsumablesRect(wnd) == FALSE )
	{
		HideWidget(wnd->dialog.window, PURCHASECONSUMABLES_VBOX);
	}
	return 0;
}


GtkWidget* getWidget(GtkWidget *window, const char* const name)
{
	return lookup_widget(window, name);
}

void SetDialogTitle(GtkWidget *window, gchar *title)
{
	if(title != NULL)
		gtk_window_set_title(GTK_WINDOW(window), title);
}

void SetWidgetSensitive(GtkWidget *window, const gchar* const widgetname, gboolean value)
{
	GtkWidget *widget;
	widget = getWidget(window, widgetname);
	gtk_widget_set_sensitive(widget, value);
}

#if 0
void SetJobMenuSensitive(UIStatusWnd *wnd, char **joblist, gboolean value)
{
	GtkWidget *window = UI_DIALOG(wnd)->window;
	int i=0;
	while(job_menu_list[i]!=NULL)
	{
		SetWidgetSensitive(window, job_menu_list[i], value);
		i++;
	}
}
#endif

gchar* InsertString( const char* const basestring, const char* const insertstring, const gint nIndex )
{
	GString* gCopyString = NULL;
	gchar* retChar = NULL;

	gCopyString = g_string_new_wrapper(basestring, __FILE__, __LINE__);
	if( gCopyString == NULL )
	{
		return retChar;
	}

	g_string_insert(gCopyString, nIndex, insertstring);
	retChar = gCopyString->str;
	g_string_free_wrapper(gCopyString, FALSE);
	return retChar;
}

char** SeparateString(char *pstr, const char delimiter)
{
	char **plist = NULL;
	char *ptmp = pstr;
	int cnt = 1;
	int i = 0;

	if( pstr == NULL )
	{
		return plist;
	}

	while(ptmp != NULL){
		if((*ptmp == CHARACTER_NEW_LINE) || (*ptmp == '\0')){
			break;
		}
		if(*ptmp == delimiter){
			cnt++;
		}
		ptmp++;
	}
	plist = (char **)mem_alloc(sizeof(char **) * ((unsigned int)cnt + 1u), __FILE__, __LINE__);

	ptmp = pstr;
	while(*ptmp != '\0')
	{
		if((*ptmp == CHARACTER_NEW_LINE) || (*ptmp == '\0')){
			break;
		}
		if((*ptmp == CHARACTER_DOUBLE_QUOTATION) && (*(ptmp+1) == '\0')){
			*ptmp = '\0';
			if(plist != NULL)
			{
				plist[i] = mem_strudup(pstr, __FILE__, __LINE__);
			}
			i++;
			break;
		}else if(*ptmp == CHARACTER_DOUBLE_QUOTATION){
			pstr++;
		}
		else{
			;
		}
		if(*ptmp == delimiter){
			*ptmp = '\0';
			if(plist != NULL)
			{
				plist[i] = mem_strudup(pstr, __FILE__, __LINE__);
			}
			pstr = ptmp+1;
			i++;
		}
		ptmp++;
	}

	if(plist != NULL)
	{
		plist[i] = NULL;
	}
#if 0
i=0;
while (plist[i]!=NULL)
{
	UI_DEBUG("line[%d]------%s\n",__LINE__,plist[i]);
	i++;
}
#endif
       return plist;
}

char* CompositionString( GList* const CompositList, const char* const strBaseString, const char* const strToken )
{
	GString* gsMultiString = NULL;
	char* strRet = NULL;
	const char* strExtra = strBaseString;
	unsigned int nIndex = 0;
	gboolean bSegmentFree = TRUE;
	const unsigned int nCompsitListLen = g_list_length(CompositList);

	UI_DEBUG("CompositionString strBaseString[%s]\n", strBaseString);

	if( (CompositList == NULL) || (strBaseString == NULL) || (strToken == NULL) )
	{
		return NULL;
	}

	strExtra = strstr(strExtra, strToken);
	if( strExtra == NULL )
	{
		UI_DEBUG("CompositionString strBaseString[%s] not find Token[%s]\n", strBaseString,strToken);
		return NULL;
	}

	gsMultiString = g_string_new_wrapper(NULL, __FILE__, __LINE__);
	if(gsMultiString == NULL)
	{
		return NULL;
	}

	if( strExtra != strBaseString )
	{
		const char* const strPreAppend = strBaseString;
		const int nLen = (int)(strExtra - strPreAppend);
		UI_DEBUG("CompositionString prepare strPreAppend[%s] Length[%d]\n", strPreAppend, nLen);
		g_string_append_len(gsMultiString, strPreAppend, nLen);

		UI_DEBUG("CompositionString append gsMultiString[%s]\n", gsMultiString->str);
	}

	while( strExtra != NULL )
	{
		int nLen = 0;
		unsigned int nDiffLength = 0;
		const char* strNext = NULL;
		const char* strAppend = NULL;

		if( nIndex < nCompsitListLen )
		{
			char* strComposit = g_list_nth_data(CompositList, nIndex);
			g_string_append(gsMultiString, strComposit);
		}
		else
		{
			UI_DEBUG("%s There is much number of tokens, from Line[%u] \n", __func__, __LINE__);
			break;
		}

		strAppend = strExtra + strlen( strToken );
		strNext = strstr(strAppend, strToken );

		if( strNext != NULL )
		{
			UI_DEBUG("CompositionString strNext[%s]\n", strNext);
			nLen = (int)(strNext - strAppend);
		}
		else
		{
			nDiffLength = (unsigned int)( strAppend - strBaseString );
			nLen = (int)(strlen( strBaseString ) - nDiffLength);

		}

		if( nLen > 0 )
		{
			g_string_append_len(gsMultiString, strAppend, nLen);
			UI_DEBUG("CompositionString append gsMultiString[%s]\n", gsMultiString->str);
		}
		strExtra = strNext;
		++nIndex;
	}

	if( (strExtra == NULL) && (nIndex == nCompsitListLen) )
	{
		strRet = gsMultiString->str;
		bSegmentFree = FALSE;
	}
	else
	{
		UI_DEBUG("CompositionString strExtra[%s], gsMultiString->str[%s], CompositList add string Num[%d] != string list Length[%d]\n", strExtra, gsMultiString->str, nIndex, nCompsitListLen);
	}

	g_string_free_wrapper(gsMultiString, bSegmentFree);

	return strRet;
}

void CatStrWithPunctuation(GString* const gsSrcStr, const char* const pAddStr, const char* const pPunc)
{
	if( (gsSrcStr == NULL) || (pAddStr == NULL) )
	{
		return;
	}

	if( (gsSrcStr->len != 0u) && (pPunc != NULL) )
	{
		g_string_append(gsSrcStr, pPunc);
	}
	g_string_append(gsSrcStr, pAddStr);
}

void AddNewLine(char** const ppSrcStr)
{
	if(ppSrcStr == NULL)
	{
		return;
	}

	GString* const glTmpStr = g_string_new_wrapper(*ppSrcStr, __FILE__, __LINE__);
	if(glTmpStr != NULL)
	{
		CatStrWithPunctuation(glTmpStr, STRING_NEWLINE, NULL);

		if(*ppSrcStr != NULL)
		{
			mem_free(*ppSrcStr);
		}
		*ppSrcStr = glTmpStr->str;
		g_string_free_wrapper(glTmpStr, FALSE);
	}
}

#define ZERO_NUM_STR "0"

GList* CreateIntGlistFromString(char * const pstr, const char delimiter)
{
	GList *pGlist = NULL;
	char **plist = NULL;
	int i = 0;

	int convNum = 0;


	if( pstr == NULL )
	{
		return pGlist;
	}

	plist =  SeparateString(pstr, delimiter);

	if( plist == NULL )
	{
		return pGlist;
	}

	for( i = 0; plist[i] != NULL; i++ )
	{
		gboolean bAdd = TRUE;

		convNum = atoi(plist[i]);

		if( convNum == 0 )
		{
			if( strncmp( ZERO_NUM_STR, plist[i], 1 ) != 0 )
			{
				bAdd = FALSE;
			}
		}

		if( bAdd == TRUE)
		{
			int *pnId = (int*)mem_alloc(sizeof(int), __FILE__, __LINE__);

			if( pnId != NULL )
			{
				*pnId = convNum;
				pGlist = g_list_append_wrapper( pGlist, pnId, __FILE__, __LINE__);
			}
		}
	}

	mem_free_list( plist );

	return pGlist;
}

GList* CreateGlist_ComboList( char * const * const ParamList )
{
	GList *pGlist = NULL;
	int i = 0;

	if( ParamList == NULL )
	{
		return pGlist;
	}

	for( i = 0; ParamList[i] != NULL; i++ )
	{
		pGlist = g_list_append_wrapper( pGlist, ParamList[i], __FILE__, __LINE__);
	}
	return pGlist;
}

GList* CreateGlist_ExceptBaseGlist(GList* const baseGlist, GList* dstGlist)
{
	GList *pGlist = NULL;

	if(dstGlist == NULL)
	{
		return NULL;
	}

	if(baseGlist == NULL)
	{
		pGlist = g_list_copy_wrapper(dstGlist, __FILE__, __LINE__);
	}
	else
	{
		while(dstGlist != NULL)
		{
			if( g_list_find_custom(baseGlist, dstGlist->data, (GCompareFunc)strcmp) == NULL )
			{
				pGlist = g_list_append_wrapper(pGlist, dstGlist->data, __FILE__, __LINE__);
			}

			dstGlist = g_list_next(dstGlist);
		}
	}

	return pGlist;
}

gboolean GetPPDValue_Integer( cngplpData* const pMod, const char* const pKey, int* const pValue )
{
	char* pTemp = NULL;
	gboolean bRet = FALSE;
	char** pIntValue = NULL;

	if( (pMod == NULL) || (pKey == NULL) || (pValue == NULL) )
	{
		return bRet;
	}

	pTemp = cngplpGetValue_Wrapper( pMod, pKey );
	if( pTemp == NULL )
	{
		return bRet;
	}

	pIntValue = SeparateString(pTemp,CHARACTER_COMMA);
	if( pIntValue != NULL )
	{
		*pValue = atoi(pIntValue[0]);
		UI_DEBUG("GetPPDValue_Integer pValue = %d\n",*pValue);
		mem_free_list( pIntValue );
		bRet = TRUE;
	}
	mem_free(pTemp);

	return bRet;
}

char* CngplpGetValue_AddPrefix(const UIStatusWnd* const wnd, const char* const baseKeyStr)
{
	GString *gsPPDKeyStr = NULL;
	char* pPPDValue = NULL;

	if( (wnd == NULL) || (baseKeyStr == NULL) )
	{
		return NULL;
	}

	gsPPDKeyStr = g_string_new_wrapper(PREFIX_PPDKEY, __FILE__, __LINE__);
	if(gsPPDKeyStr != NULL)
	{
		g_string_append(gsPPDKeyStr, baseKeyStr);
		pPPDValue = cngplpGetValue_Wrapper(wnd->pModData, gsPPDKeyStr->str);
		g_string_free_wrapper(gsPPDKeyStr, TRUE);
	}

	return pPPDValue;
}

char* CngplpGetValue_AddKeyStr(const UIStatusWnd* const wnd, const char* const baseKeyStr, const char* const addKeyStr)
{
	return CngplpGetValue_AddExtraKeyStr(wnd, baseKeyStr, addKeyStr, NULL);
}

char* CngplpGetValue_AddExtraKeyStr(const UIStatusWnd* const wnd, const char* const baseKeyStr, const char* const addKeyStr, const char* const extraKeyStr)
{
	GString *gsPPDKeyStr = NULL;
	char *pPPDValue = NULL;

	if( (wnd == NULL) || (baseKeyStr == NULL) )
	{
		return NULL;
	}

	gsPPDKeyStr = g_string_new_wrapper(baseKeyStr, __FILE__, __LINE__);
	if(gsPPDKeyStr != NULL)
	{
		if(addKeyStr != NULL)
		{
			g_string_append(gsPPDKeyStr, addKeyStr);
		}
		if(extraKeyStr != NULL)
		{
			g_string_append(gsPPDKeyStr, extraKeyStr);
		}
		pPPDValue = CngplpGetValue_AddPrefix(wnd, gsPPDKeyStr->str);
		g_string_free_wrapper(gsPPDKeyStr, TRUE);

	}

	return pPPDValue;
}

char* getMessageFromPPDKey(const UIStatusWnd* const wnd, const char* const ppdKey, const char* const appendKey)
{
	char *pMessageKey = NULL;
	char *pMessageStr = NULL;
	GString *gsMessageKey = NULL;

	if( (wnd == NULL) || (ppdKey == NULL) )
	{
		return NULL;
	}

	GString *gsExtraStr = NULL;
	gsExtraStr = g_string_new_wrapper(NULL, __FILE__, __LINE__);
	createCrgTypeXStr(wnd, ppdKey, appendKey, gsExtraStr);

	pMessageKey = CngplpGetValue_AddExtraKeyStr(wnd, ppdKey, appendKey, gsExtraStr->str);
	g_string_free_wrapper(gsExtraStr, TRUE);

	if(pMessageKey != NULL)
	{
		char** const pValueList = SeparateString( pMessageKey, CHARACTER_COMMA );
		mem_free(pMessageKey);
		if(pValueList != NULL)
		{
			if(*pValueList != NULL)
			{
				pMessageKey = mem_strudup(pValueList[0], __FILE__, __LINE__);
			}
			mem_free_list(pValueList);
		}
	}
	else
	{
		gsMessageKey = g_string_new_wrapper(ppdKey, __FILE__, __LINE__);
		if(gsMessageKey != NULL)
		{
			if(appendKey != NULL)
			{
				g_string_append(gsMessageKey, appendKey);
			}
			pMessageKey = gsMessageKey->str;
			g_string_free_wrapper(gsMessageKey, FALSE);
		}
	}

	if(pMessageKey != NULL)
	{
		pMessageStr = msgXmlGetString(wnd, pMessageKey);
		mem_free(pMessageKey);
	}

	return pMessageStr;
}
char * joinPPDValue(const char* value1, const char* value2)
{
	char* pJoinStr = NULL;
	GString* gsJoinVaule = NULL;
	gsJoinVaule = g_string_new_wrapper(value1, __FILE__, __LINE__);
	if(gsJoinVaule == NULL)
	{
		return NULL;
	}

	if (value2 != NULL && strlen(value2) > 0)
	{
		if(gsJoinVaule->str[gsJoinVaule->len-1] == CHARACTER_DOUBLE_QUOTATION)
		{
			g_string_truncate(gsJoinVaule, gsJoinVaule->len-1);
		}
		g_string_append_c(gsJoinVaule, CHARACTER_COMMA);
		if(value2[0] == CHARACTER_DOUBLE_QUOTATION)
		{
			value2++;
		}
		g_string_append(gsJoinVaule, value2);
	}

	pJoinStr = gsJoinVaule->str;
	g_string_free_wrapper(gsJoinVaule, FALSE);
	return pJoinStr;
}


char* getPPDValueAppendSuffixIndex(cngplpData *pModData, const char* pPPDKey)
{
	gboolean bTerminate = FALSE;
	char *pJoinValue = NULL;
	int nPPDKeySuffixIdx = 1;

	do {
		char *pPPDValueTmp = NULL;
		GString* gsPPDKey__n = NULL;
		gsPPDKey__n = g_string_new_wrapper(pPPDKey, __FILE__, __LINE__);
		if(gsPPDKey__n == NULL)
		{
			break;
		}
		g_string_append_printf(gsPPDKey__n, "__%d", nPPDKeySuffixIdx++);
		pPPDValueTmp = cngplpGetValue_Wrapper(pModData, gsPPDKey__n->str);

		if (pPPDValueTmp != NULL)
		{
			if (pJoinValue == NULL)
			{
				pJoinValue = pPPDValueTmp;
			}
			else
			{
				char* temp = joinPPDValue(pJoinValue, pPPDValueTmp);
				mem_free(pJoinValue);
				mem_free(pPPDValueTmp);
				pJoinValue = temp;
				if (temp == NULL)
				{
					bTerminate = TRUE;
				}
			}
		}
		else
		{
			bTerminate = TRUE;
		}
		g_string_free_wrapper(gsPPDKey__n, TRUE);
	} while(!bTerminate);

	return pJoinValue;
}

GList *CreateListFromPPDKey(cngplpData *pModData, const char *pPPDKey)
{
	GList *gList = NULL;

	if ((pModData != NULL) && (pPPDKey != NULL))
	{
		char *pPPDValue = NULL;

		pPPDValue = cngplpGetValue_Wrapper(pModData, pPPDKey);
		if(pPPDValue == NULL)
		{
			pPPDValue = getPPDValueAppendSuffixIndex(pModData, pPPDKey);
		}
		if (pPPDValue != NULL)
		{
			char **pValueList = NULL;

			pValueList = SeparateString(pPPDValue, CHARACTER_COMMA);
			if (pValueList != NULL)
			{
				gint i = 0;

				for (i = 0; pValueList[i] != NULL; i++ )
				{
					gList = g_list_append_wrapper(gList, pValueList[i], __FILE__, (unsigned int)__LINE__);
				}
				mem_free(pValueList);
			}
			mem_free( pPPDValue );
		}
	}
	return gList;
}

gboolean isCrgTypeDevice(const UIStatusWnd* const wnd)
{
	gboolean retval = FALSE;
	char* pCartridgeTypeList = crgTypeList(wnd);
	if (pCartridgeTypeList != NULL)
	{
		retval = TRUE;
		mem_free(pCartridgeTypeList);
	}
	return retval;
}

char* crgTypeList(const UIStatusWnd* const wnd)
{
	if (wnd == NULL)
	{
		return NULL;
	}

	return CngplpGetValue_AddKeyStr(wnd, "CrgTypeList", NULL);
}

char* crgTypeDefault(const UIStatusWnd* const wnd)
{
	if (wnd == NULL)
	{
		return NULL;
	}

	char* defaultKeyValue = CngplpGetValue_AddKeyStr(wnd, "CrgTypeDefault", NULL);
	char** sepStr = SeparateString(defaultKeyValue, CHARACTER_COMMA);
	mem_free(defaultKeyValue);

	if(sepStr == NULL)
	{
		return NULL;
	}

	char* defaultValue = mem_strudup(*sepStr, __FILE__, __LINE__);
	mem_free_list(sepStr);

	return defaultValue;
}

gboolean isEquipmentEnable(const UIStatusWnd* const wnd, const char* const pEquipment)
{
	GList *glEquipmentList = NULL;
	gboolean bEnableEquipment = FALSE;

	if ((wnd == NULL )|| (pEquipment == NULL) )
	{
		return FALSE;
	}

	glEquipmentList = GetDictValueGList_forKey(wnd->pStatusDict, KEY_EQUIPMENT);
	if (glEquipmentList != NULL )
	{
		if (g_list_find_custom(glEquipmentList, pEquipment, (GCompareFunc) strcmp) != NULL )
		{
			bEnableEquipment = TRUE;
		}
	}

	return bEnableEquipment;
}

gboolean existCrgTypeInEquipment(const UIStatusWnd* const wnd)
{
	gboolean isCrgType = FALSE;
	int count = 0;
	for(count = 0; ppdCrgTypeList[count] != NULL; count++)
	{
		isCrgType = isEquipmentEnable(wnd, ppdCrgTypeList[count]);
		if (isCrgType == TRUE)
		{
			break;
		}
	}

	return isCrgType;
}

void getEquipmentCrgTypeFromCNSUICrgTypeList(const UIStatusWnd* const wnd, char** outCrgTypeStr)
{
	char* pCartridgeTypeList = crgTypeList(wnd);
	if (pCartridgeTypeList == NULL)
	{
		return;
	}
	char** ppSeparateStr = NULL;
	ppSeparateStr = SeparateString(pCartridgeTypeList, CHARACTER_COMMA);
	mem_free(pCartridgeTypeList);

	if(ppSeparateStr == NULL)
	{
		return;
	}
	if( existCrgTypeInEquipment(wnd) == FALSE )
	{
		mem_free_list(ppSeparateStr);
		return;
	}

	gboolean hasCrg = FALSE;
	int idx = 0;
	for(idx = 0; ppSeparateStr[idx] != NULL; idx++)
	{
		hasCrg = isEquipmentEnable(wnd, (gpointer)ppSeparateStr[idx]);
		if (hasCrg == TRUE)
		{

			*outCrgTypeStr = mem_strudup(ppSeparateStr[idx], __FILE__, __LINE__);
			break;
		}
	}
	mem_free_list(ppSeparateStr);
}

void createCrgTypeXStr(const UIStatusWnd* const wnd, const char* const ppdKey, const char* const appendKey, GString *outGStr)
{
	char *pCrgTypeStr = NULL;
	char *pCrgTypeDefaultStr = NULL;
	getEquipmentCrgTypeFromCNSUICrgTypeList(wnd, &pCrgTypeStr);
	if (pCrgTypeStr == NULL)
	{
		return;
	}

	pCrgTypeDefaultStr = crgTypeDefault(wnd);
	if (pCrgTypeDefaultStr == NULL)
	{
		mem_free(pCrgTypeStr);
		return;
	}

	if (strcmp(pCrgTypeStr, pCrgTypeDefaultStr) == 0)
	{
		mem_free(pCrgTypeDefaultStr);
		mem_free(pCrgTypeStr);
		return;
	}

	g_string_append(outGStr, STRING_UNDERLINE);
	g_string_append(outGStr, pCrgTypeStr);
	mem_free(pCrgTypeDefaultStr);
	mem_free(pCrgTypeStr);

	gboolean isNewExtraKeyCreated = FALSE;
	char* pTempKey = CngplpGetValue_AddExtraKeyStr(wnd, ppdKey, appendKey, outGStr->str);
	if(pTempKey != NULL)
	{
		isNewExtraKeyCreated = TRUE;
		mem_free(pTempKey);
	}

	if (!isNewExtraKeyCreated)
	{
		g_string_erase(outGStr, 0, -1);
	}
}

gboolean CheckControlEnabled(CtrlTbl* const * const pPPDCtrlTbl, const int ctrlid)
{
	int i = 0;
	gboolean isEnable = FALSE;

	if (pPPDCtrlTbl != NULL)
	{
		for (i = 0; pPPDCtrlTbl[i] != NULL; i ++)
		{
			if (pPPDCtrlTbl[i]->ctrlid == ctrlid)
			{
				isEnable = TRUE;
				break;
			}
		}
	}

	return isEnable;
}

void HideWidget(GtkWidget *window, const gchar * const widget_name)
{
    GtkWidget *widget;

    widget = getWidget(window, widget_name);
    if(widget != NULL)
        gtk_widget_hide(widget);
}
void HideMonitor(UIStatusWnd *wnd)
{
	gtk_widget_hide(UI_DIALOG(wnd)->window);
	wnd->mode = 0;
	wnd->isHideNowWnd = TRUE;
}
void SetTextToLabel(GtkWidget *window, const gchar *label_name, const gchar *text)
{
	GtkWidget *label;
	label = getWidget(window, label_name);
	gtk_label_set_text(GTK_LABEL(label), text);
}

const gchar* GetStrLabel(GtkWidget* const window, const gchar* const label_name)
{
	const gchar *pRetStr = NULL;
	GtkWidget *widgetLabel = NULL;

	if( (window == NULL) || (label_name == NULL) )
	{
		return NULL;
	}

	widgetLabel = getWidget(window, label_name);
	if(widgetLabel != NULL)
	{
		GtkLabel * const txtLabel = GTK_LABEL(widgetLabel);
		pRetStr = gtk_label_get_text(txtLabel);
	}

	return pRetStr;
}

gboolean CompareStrLabel(GtkWidget* const window, const gchar* const label_name, const gchar* const compareStr)
{
	const gchar* labelWidgetStr = NULL;
	gboolean isSameStr = FALSE;

	if( (window == NULL) || (label_name == NULL) || (compareStr == NULL))
	{
		return FALSE;
	}

	labelWidgetStr = GetStrLabel(window, label_name);
	if(labelWidgetStr != NULL)
	{
		if( strcmp(labelWidgetStr, compareStr) == 0 )
		{
			isSameStr = TRUE;
		}
	}

	return isSameStr;
}

void SetTextToTextView(GtkWidget* const window, const gchar* const text_name, const gchar* const setString)
{
	GtkWidget *textView;
	GtkTextBuffer *textBuf;
	textView = getWidget(window, text_name);
	textBuf = gtk_text_view_get_buffer( GTK_TEXT_VIEW(textView) );
	gtk_text_buffer_set_text( textBuf, setString, -1 );
}

gchar* GetStrTextWidget(GtkWidget* const window, const gchar* const text_name)
{
	gchar *pRetStr = NULL;
	GtkWidget *widgetView = NULL;
	GtkTextView *textView = NULL;
	GtkTextBuffer *textBuf = NULL;
	GtkTextIter start_itr, end_itr;

	if( (window == NULL) || (text_name == NULL) )
	{
		return NULL;
	}

	widgetView = getWidget(window, text_name);
	if(widgetView != NULL)
	{
		textView = GTK_TEXT_VIEW(widgetView);
		textBuf = gtk_text_view_get_buffer( textView );
		if(textBuf != NULL)
		{
			gtk_text_buffer_get_start_iter(textBuf, &start_itr);
			gtk_text_buffer_get_end_iter(textBuf, &end_itr);
			pRetStr = gtk_text_buffer_get_text( textBuf, &start_itr, &end_itr, FALSE );
		}
	}

	return pRetStr;
}

gboolean CompareStrTextWidget(GtkWidget* const window, const gchar* const text_name, const gchar* const compareStr)
{
	gchar* textWidgetStr = NULL;
	gboolean isSameStr = FALSE;

	if( (window == NULL) || (text_name == NULL) || (compareStr == NULL))
	{
		return FALSE;
	}

	textWidgetStr = GetStrTextWidget(window, text_name);
	if(textWidgetStr != NULL)
	{
		if( strcmp(textWidgetStr, compareStr) == 0 )
		{
			isSameStr = TRUE;
		}
		mem_free( textWidgetStr );
	}

	return isSameStr;
}

gboolean GetToggleButtonActive(GtkWidget *window, const gchar *button_name, gboolean bInvert)
{
	GtkWidget *button;
	gboolean bRet = TRUE;

	button = getWidget(window, button_name);

	bRet =  gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(button));

	if( bInvert == TRUE )
	{
		bRet = !bRet;
	}
	return bRet;
}
void SetActiveCheckButton(GtkWidget *window, const gchar *button_name, gboolean on, gboolean bInvert)
{
	gboolean bValue = on;

	if( bInvert == TRUE )
	{
		bValue = !on;
	}
	GtkWidget *button;
	button = getWidget(window, button_name);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(button), bValue);
}

void SetSpinButtonFloat(GtkWidget *window, const gchar *spinbutton_name, gfloat value)
{
	GtkWidget *spin;
	spin = getWidget(window, spinbutton_name);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin), value);
}

gint GetSpinButtonValue(GtkWidget *window, const gchar *spinbutton_name, int value)
{
	GtkWidget *spin;

	spin = getWidget(window, spinbutton_name);

	if(value)
		return (gtk_spin_button_get_value_as_float(GTK_SPIN_BUTTON(spin)) * value);
	else
		return gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin));
}


gint GetCurrComboBoxIndex(GtkWidget * const window, const gchar * const combobox_name)
{
	GtkWidget *combowidget = NULL;
	GtkComboBox *combobox = NULL;
	gint nIndex = -1;

	if( (window == NULL) || (combobox_name == NULL) )
	{
		return nIndex;
	}

	combowidget = getWidget( window, combobox_name );

	if(combowidget != NULL)
	{
		combobox = GTK_COMBO_BOX(combowidget);
	}

	if( combobox != NULL )
	{
		nIndex = gtk_combo_box_get_active( combobox );
	}

	return nIndex;
}

void SetCurrComboBoxIndex(GtkWidget * const window, const gchar * const combobox_name, const gint nIndex)
{
	GtkWidget *combowidget = NULL;
	GtkComboBox *combobox = NULL;

	if( (window == NULL) || (combobox_name == NULL) )
	{
		return ;
	}

	combowidget = getWidget( window, combobox_name );

	if(combowidget != NULL)
	{
		combobox = GTK_COMBO_BOX(combowidget);
	}

	if( combobox != NULL )
	{
		gtk_combo_box_set_active( combobox, nIndex );
	}
}

void SetGListToComboBox(GtkWidget * const window, const gchar * const combobox_name, GList * const glist)
{
	GtkWidget *combowidget = NULL;
	GtkComboBox *combobox = NULL;
	GtkTreeModel *datatree = NULL;
	GtkListStore *liststore = NULL;
	unsigned int i = 0;

	if( (window == NULL) || (combobox_name == NULL) || (glist == NULL) )
	{
		return;
	}

	combowidget = getWidget( window, combobox_name );

	if(combowidget != NULL)
	{
		combobox = GTK_COMBO_BOX(combowidget);
	}

	if( combobox == NULL )
	{
		return;
	}

	datatree = gtk_combo_box_get_model(combobox);

	if(datatree != NULL)
	{
		liststore = GTK_LIST_STORE( datatree );
	}

	if( liststore == NULL )
	{
		return;
	}

	gtk_list_store_clear( liststore );


	for( i = 0; i < g_list_length( glist ); i++ )
	{
		gchar *pListItem = (gchar*)g_list_nth_data( glist, i );

		if( pListItem != NULL )
		{
			GtkTreeIter treeiter;
			gtk_list_store_append( liststore, &treeiter );
			if( gtk_list_store_iter_is_valid(liststore, &treeiter) == TRUE )
			{
				gtk_list_store_set( liststore, &treeiter, 0, pListItem, -1 );
			}
		}
	}
}

gint GetTextIndexFromComboBox(GtkWidget * const window, const gchar * const combobox_name, const gchar * const gtext)
{
	GtkWidget *combowidget = NULL;
	GtkComboBox *combobox = NULL;

	int i = 0;
	gint nPos = -1;

	gboolean bRet = FALSE;
	gboolean bFound = FALSE;

	GtkTreeModel *datatree = NULL;
	GtkTreeIter treeiter;

	if( (window == NULL) || (combobox_name == NULL) || (gtext == NULL) )
	{
		return nPos;
	}

	combowidget = getWidget( window, combobox_name );

	if(combowidget != NULL)
	{
		combobox = GTK_COMBO_BOX(combowidget);
	}

	if( combobox == NULL )
	{
		return nPos;
	}

	datatree = gtk_combo_box_get_model( combobox );

	if( datatree == NULL )
	{
		return nPos;
	}

	if( gtk_tree_model_get_iter_first(datatree, &treeiter) == TRUE )
	{
		do
		{
			gchar *pListItem = NULL;

			gtk_tree_model_get( datatree, &treeiter, 0, &pListItem, -1 );

			if( pListItem != NULL )
			{
				if( strcmp(pListItem, gtext) == 0 )
				{
					nPos = i;
					bFound = TRUE;
				}

				mem_free( pListItem );

				if( bFound == TRUE )
				{
					break;
				}
			}

			bRet = gtk_tree_model_iter_next( datatree, &treeiter );
			i++;

		} while( bRet == TRUE );
	}

	return nPos;
}

gboolean SetCurrComboBoxText(GtkWidget * const window, const gchar * const combobox_name, const gchar * const gtext)
{
	gboolean bRet = FALSE;
	const gint nPos = GetTextIndexFromComboBox( window, combobox_name, gtext );

	if(nPos > -1)
	{
		SetCurrComboBoxIndex( window, combobox_name, nPos );
		bRet = TRUE;
	}

	return bRet;
}

gchar* GetCurrComboBoxText(GtkWidget * const window, const gchar * const combobox_name)
{
	GtkWidget *combowidget = NULL;
	GtkComboBox *combobox = NULL;
	gchar *combotext = NULL;

	GtkTreeModel *datatree = NULL;
	GtkTreeIter treeiter;

	if( (window == NULL) || (combobox_name == NULL) )
	{
		return combotext;
	}

	combowidget = getWidget( window, combobox_name );

	if(combowidget != NULL)
	{
		combobox = GTK_COMBO_BOX(combowidget);
	}

	if( combobox == NULL )
	{
		return combotext;
	}

	datatree = gtk_combo_box_get_model( combobox );

	if( datatree == NULL )
	{
		return combotext;
	}

	if( gtk_combo_box_get_active_iter( combobox, &treeiter ) == TRUE )
	{
		gtk_tree_model_get( datatree, &treeiter, 0, &combotext, -1 );
	}

	return combotext;
}

void UpdateMainWindow(UIStatusWnd* const wnd, const char* const mainMessage, const char* const subMessage)
{
	GtkWidget *pWindow = NULL;
	UIDialog *pUidialog = NULL;
	char *pTmpStatusMain = NULL;
	char *pTmpStatusSub = NULL;
	gboolean isSameMessage = FALSE;

	if(wnd == NULL)
	{
		return;
	}

	pUidialog = &(wnd->dialog);
	pWindow = pUidialog->window;

	if(pWindow == NULL)
	{
		return;
	}

	if( (mainMessage == NULL) && (subMessage == NULL) )
	{
		pTmpStatusMain = msgXmlGetString(wnd, GETTINGSTATUS_XMLKEY);
		pTmpStatusSub = msgXmlGetString(wnd, GETTINGSTATUSSUB_XMLKEY);
		if( (pTmpStatusMain != NULL) && (pTmpStatusSub != NULL) )
		{
			SetTextToLabel(pWindow, "MainMessage_label", pTmpStatusMain);
			SetTextToTextView(pWindow, "AssistMessage_text", pTmpStatusSub);
		}
	}
	else
	{
		if(mainMessage == NULL)
		{
			return;
		}

		if(subMessage == NULL)
		{
			pTmpStatusSub = mem_strudup(BLANK_MESSAGE, __FILE__, __LINE__);
		}
		else
		{
			pTmpStatusSub = mem_strudup(subMessage, __FILE__, __LINE__);
		}

		if(pTmpStatusSub != NULL)
		{
			isSameMessage = CompareStrLabel(pWindow, "MainMessage_label", mainMessage);
			if(isSameMessage == FALSE)
			{
				UI_DEBUG("%s Set MainMessage[%s], from Line[%u] \n", __func__, mainMessage, __LINE__);
				SetTextToLabel(pWindow, "MainMessage_label", mainMessage);
			}
			isSameMessage = CompareStrTextWidget(pWindow, "AssistMessage_text", pTmpStatusSub);
			if(isSameMessage == FALSE)
			{
				UI_DEBUG("%s Set SubMessage[%s], from Line[%u] \n", __func__, pTmpStatusSub, __LINE__);
				SetTextToTextView(pWindow, "AssistMessage_text", pTmpStatusSub);
			}
		}
		if(isShowPurchaseConsumablesRect(wnd) != FALSE)
		{
			gboolean	buttonStatus = TRUE;
			const char*	pRegGroup = GetAreaInfo(wnd);
			if(pRegGroup == NULL)
			{
				buttonStatus = FALSE;
			}
			SetWidgetSensitive(pWindow, ACCESS_PURCHASING_SITE_BUTTON, buttonStatus);
		}
	}

	if(wnd->nShowDlgCnt == 0)
	{
		UpdateMainWindowMenu(wnd);
	}

	if(pTmpStatusMain != NULL)
	{
		mem_free(pTmpStatusMain);
	}
	if(pTmpStatusSub != NULL)
	{
		mem_free(pTmpStatusSub);
	}
}

static void UpdateMainWindowMenu(UIStatusWnd* const wnd)
{
	GtkWidget *pWindow = NULL;
	UIDialog *pUidialog = NULL;
	gboolean bSupportedPrinter = FALSE;
	gboolean bHideMainWindow = FALSE;

	if(wnd == NULL)
	{
		return;
	}

	pUidialog = &(wnd->dialog);
	pWindow = pUidialog->window;

	if(pWindow == NULL)
	{
		return;
	}

	HideWidget(pWindow, "warning_display_details");
	HideWidget(pWindow, "auto_shutdown_settings");

	bSupportedPrinter = isSupportedPrinter(wnd);
	if(bSupportedPrinter == TRUE)
	{
		SetJobMenuSensitive(wnd);
		SetOptionMenuSensitive(wnd);
		if(wnd->mode == 0)
		{
			bHideMainWindow = isHideMainWindow(wnd);
			if(bHideMainWindow != wnd->isHideNowWnd)
			{
				ChangeHideMainWindow(wnd);
			}
		}
	}
	else
	{
		SetEnableAllMenu(wnd, FALSE);
		SetWidgetSensitive(pWindow, "hide_statusmonitor", TRUE);
		SetWidgetSensitive(pWindow, "SMWndHide_button", TRUE);
	}
}

void SetJobMenuSensitive(UIStatusWnd* const wnd)
{
	GtkWidget *pWindow = NULL;
	UIDialog *pUidialog = NULL;
	gboolean bEnableJobCancel = FALSE;
	gboolean bEnableResume = FALSE;
	gboolean bEnableJob = FALSE;
	int procJobId = 0;

	if(wnd == NULL)
	{
		return;
	}

	pUidialog = &(wnd->dialog);
	pWindow = pUidialog->window;

	if(pWindow == NULL)
	{
		return;
	}

	bEnableJobCancel = isEnableJobCancel(wnd);
	bEnableJob = GetDictValueInt_forKey(wnd->pStatusDict, KEY_JOB_ID, &procJobId);
	if(bEnableJob)
	{
		bEnableResume = isOperationEnable(wnd, ERR_SKIP_STR);
	}
	SetJobWidgetSensitive(pWindow, bEnableResume, bEnableJobCancel);
	SetBtnWidgetSensitive(pWindow, bEnableResume, bEnableJobCancel);
}

static gboolean isShowMenu_AutoShutdownSettings(const UIStatusWnd* pWnd)
{
	gboolean bShowMenu_AutoShutdownSettings = TRUE;

	if( ( pWnd != NULL ) && ( pWnd->pModData != NULL ) )
	{
		GList*	pAreaList = CreateListFromPPDKey(pWnd->pModData, CNSUISHOWMENU_AREA_AUTOSHUTDOWNSETTINGS);

		if( pAreaList != NULL )
		{
			const char*	pArea = GetAreaInfo(pWnd);

			if( pArea != NULL )
			{
				if( g_list_find_custom(pAreaList, pArea, (GCompareFunc)strcmp) == NULL )
				{
					bShowMenu_AutoShutdownSettings = FALSE;
				}
			}
			else
			{
				bShowMenu_AutoShutdownSettings = FALSE;
			}
		}
		if( pAreaList != NULL )
		{
			g_list_foreach(pAreaList, (GFunc)mem_free, NULL);
			g_list_free_wrapper(pAreaList);
			pAreaList = NULL;
		}
	}

	return bShowMenu_AutoShutdownSettings;
}

void SetOptionMenuSensitive(UIStatusWnd* const wnd)
{
	GtkWidget* pWindow = NULL;
	UIDialog *pUidialog = NULL;
	gboolean bEnableMenu = FALSE;

	if(wnd == NULL)
	{
		return;
	}

	pUidialog = &(wnd->dialog);
	pWindow = pUidialog->window;

	if(pWindow == NULL)
	{
		return;
	}

	SetEnableAllOptionMenu(wnd, TRUE);

	bEnableMenu = isOperationEnable(wnd, CONSUMABLE_STR);
	if(bEnableMenu == FALSE)
	{
		SetWidgetSensitive(pWindow, "consumables_information", FALSE);
		SetWidgetSensitive(pWindow, "counters", FALSE);
	}
	bEnableMenu = isOperationEnable(wnd, CALIBRATION_STR);
	if(bEnableMenu == FALSE)
	{
		SetWidgetSensitive(pWindow, "calibration", FALSE);
		SetWidgetSensitive(pWindow, "color_mismatch_correction", FALSE);
	}
	bEnableMenu = isOperationEnable(wnd, UTILITY_STR);
	if(bEnableMenu == FALSE)
	{
        SetWidgetSensitive(pWindow, "cleaning", FALSE);
		SetWidgetSensitive(pWindow, "cleaning1", FALSE);
		SetWidgetSensitive(pWindow, "cleaning2", FALSE);
		SetWidgetSensitive(pWindow, "user_data_list", FALSE);
		SetWidgetSensitive(pWindow, "pcl_font_list", FALSE);
	}
	bEnableMenu = isOperationEnable(wnd, SETTING_STR);
	if(bEnableMenu == FALSE)
	{
		SetWidgetSensitive(pWindow, "switch_paper_feed_method", FALSE);
		SetWidgetSensitive(pWindow, "action_when_paper_size_mismatch_settings", FALSE);
		SetWidgetSensitive(pWindow, "paper_source_settings", FALSE);
		SetWidgetSensitive(pWindow, "settings_for_cancel_job_key", FALSE);
		SetWidgetSensitive(pWindow, "sleep_settings", FALSE);
		SetWidgetSensitive(pWindow, "auto_shutdown_settings", FALSE);
		SetWidgetSensitive(pWindow, "warning_display_settings", FALSE);
		SetWidgetSensitive(pWindow, "warning_display_details", FALSE);
		SetWidgetSensitive(pWindow, "image_quality_adjustment_settings", FALSE);
		SetWidgetSensitive(pWindow, "paper_size_override_settings", FALSE);
		SetWidgetSensitive(pWindow, "assisting_print_setting", FALSE);
		SetWidgetSensitive(pWindow, "mobile_print_settings", FALSE);
		SetWidgetSensitive(pWindow, "select_language_for_user_data_list", FALSE);
	}

	bEnableMenu = isOperationEnable(wnd, CHANGEFIRMUPDATEMODE_STR);
	if(bEnableMenu == FALSE)
	{
		SetWidgetSensitive(pWindow, "enter_cancel_firmware_update_mode", FALSE);
	}

	bEnableMenu = isWlanModel(wnd);
	if(bEnableMenu == FALSE)
	{
		SetWidgetSensitive(pWindow, "wireless_lan_status", FALSE);
		SetWidgetSensitive(pWindow, "settings_to_disable_wi_fi_key", FALSE);
	}
	else
	{
		bEnableMenu = isOperationEnable(wnd, SETTING_STR);
		if(bEnableMenu == FALSE)
		{
			SetWidgetSensitive(pWindow, "settings_to_disable_wi_fi_key", FALSE);
		}
	}

	{
		UIItem *item = FindUIItemWithWidgetName("auto_shutdown_settings");

		if ((item != NULL) && item->show_flag)
		{
			gboolean bShowMenu_AutoShutdownSettings = isShowMenu_AutoShutdownSettings(wnd);

			if(bShowMenu_AutoShutdownSettings)
			{
				ShowWidget(pWindow, "auto_shutdown_settings");
			}
		}
	}
	{
		UIItem *item = FindUIItemWithWidgetName("warning_display_details");

		if ((item != NULL) && item->show_flag)
		{
			gboolean bShowMenu = isOperationEnable(wnd, SHOWWARNINGDISPLAYDETAILS_STR);

			if (bShowMenu)
			{
				ShowWidget(pWindow, "warning_display_details");
			}
		}
	}
}

#define OPTION_MENU_NUM 28

void SetEnableAllOptionMenu(UIStatusWnd* const wnd, const gboolean isEnable)
{
	GtkWidget* pWindow = NULL;
	UIDialog *pUidialog = NULL;
	int idx = 0;
	char* const pOptionMenuList[OPTION_MENU_NUM] = {	"consumables_information",
							 	"counters",
							 	"wireless_lan_status",
							 	"calibration",
							 	"color_mismatch_correction",
                                "cleaning",
							 	"cleaning1",
							 	"cleaning2",
							 	"user_data_list",
							 	"pcl_font_list",
							 	"enter_cancel_firmware_update_mode",
								"switch_paper_feed_method",
								"action_when_paper_size_mismatch_settings",
							 	"paper_source_settings",
							 	"settings_for_cancel_job_key",
							 	"sleep_settings",
							 	"auto_shutdown_settings",
							 	"warning_display_settings",
							 	"warning_display_details",
							 	"image_quality_adjustment_settings",
							 	"paper_size_override_settings",
							 	"assisting_print_setting",
							 	"mobile_print_settings",
							 	"select_language_for_user_data_list",
							 	"settings_to_disable_wi_fi_key",
							 	"hide_statusmonitor",
							 	"SMWndHide_button",
							 	NULL };

	if(wnd == NULL)
	{
		return;
	}

	pUidialog = &(wnd->dialog);
	pWindow = pUidialog->window;

	if(pWindow == NULL)
	{
		return;
	}

	for(idx = 0; pOptionMenuList[idx] != NULL; idx++)
	{
		SetWidgetSensitive(pWindow, pOptionMenuList[idx], isEnable);
	}
}

void SetEnableAllMenu(UIStatusWnd* const wnd, const gboolean isEnable)
{
	GtkWidget* pWindow = NULL;
	UIDialog *pUidialog = NULL;

	if(wnd == NULL)
	{
		return;
	}

	pUidialog = &(wnd->dialog);
	pWindow = pUidialog->window;

	if(pWindow == NULL)
	{
		return;
	}

	SetJobWidgetSensitive(pWindow, isEnable, isEnable);
	SetBtnWidgetSensitive(pWindow, isEnable, isEnable);

	SetEnableAllOptionMenu(wnd, isEnable);
}

void SetButtonLabel(GtkWidget *window, const gchar *button_name, gchar *text)
{
    GtkWidget *button;
    button = getWidget(window, button_name);
#ifdef OLD_GTK
    gtk_label_set_text(GTK_LABEL(GTK_BUTTON(button)->child), text);
#else
    gtk_button_set_label(GTK_BUTTON(button), text);
#endif
}

void SetBtnWidgetSensitive(GtkWidget* const window, const gboolean resume, const gboolean cancel)
{
	SetWidgetSensitive(window, "ContinueRetry_button", resume);
	SetWidgetSensitive(window, "CancelJob_button", cancel);
}

void SetJobWidgetSensitive(GtkWidget* const window, const gboolean resume, const gboolean cancel)
{
	SetWidgetSensitive(window, "continue_retry", resume);
	SetWidgetSensitive(window, "cancel_job", cancel);
}

