/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */



#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "uimain.h"
#include "widgets.h"
#include "interface.h"
#include "consumablesdlg.h"

#include "callbacks.h"
#include "support.h"
#include "id_defines.h"
#include "commandcontroller.h"
#include "value_defines.h"
#include "key_defines.h"

#define CONSUMABLES_CTRL_TYPE_NUM 3
#define CONSUMABLES_CTRL_TBL_NUM 21
#define CONSUMABLES_STATUS_CONV_TBL_NUM 11
#define CONSUMABLES_COMMAND_VAL_CTR_TBL_NUM 10
#define CONSUMABLES_REMAIN_TBL_NUM 5
#define CONSUMABLES_CARTRIDGE_TBL_NUM 6
#define CONSUMABLES_COMMAND_VAL_TONER_CTR_TBL_NUM 2
#define CONSUMABLES_STATUS_NORMAL "StatusNormal"

struct _consumable_status_conv_t {
	char *statusKey;
	gchar *printStatus;
};

struct _consumable_commandVal_control_t {
	char *commandVal;
	char *control;
	int ctrlid;
	gboolean isEnable;
	gboolean isSet;
};

struct _consumable_remain_control_t {
	char *statusKey;
	char *control;
	int ctrlid;
};
struct _consumable_cartridge_control_t {
	char *ppdKey;
	char *control;
	int ctrlid;
	char *msgKey;
};

CtrlTbl* PPDCtrlTbl[CTRL_LIST_MAXNUM];

static int InitConsumablesDlgWidgets( UIStatusWnd *wnd );
static void CheckPPDValues( const UIStatusWnd* const wnd, CtrlTbl* const * const pPPDCtrlTbl, struct _consumable_commandVal_control_t* const pTbl );
static void AddPPDCtrlTbl( void );
static void SetConsumablesAmmount( const UIStatusWnd* const wnd, const struct _consumable_status_conv_t* const statusConvTbl, struct _consumable_commandVal_control_t* const cmdSetTbl );
static void SetConsumablesRemain(const UIStatusWnd* const wnd, CtrlTbl* const * const pPPDCtrlTbl, const struct _consumable_remain_control_t* const pTbl);
static void SetConsumablesCartridge(const UIStatusWnd* const wnd, CtrlTbl* const * const pPPDCtrlTbl, const struct _consumable_cartridge_control_t* const pTbl);

static CtrlTbl ctrlTbl[CONSUMABLES_CTRL_TBL_NUM] =
{
	{ ID_CONSUMABLES_DIALOG1, LABEL_TYPE_TITLE, NULL, N_("Consumables Information"), NULL, 0 },
	{ ID_CTRLTONERCARTRIDGEINFO, LABEL_TYPE_TEXT, "ConsumablesDlg_TonerCartridge_label", N_("Toner Cartridge Information"), NULL, 0 },
	{ ID_CTRLCYANINFO, LABEL_TYPE_TEXT, "ConsumablesDlg_CyanToner_label", N_("Cyan:"), "hbox64", 0 },
	{ ID_CTRLMAGENTAINFO, LABEL_TYPE_TEXT, "ConsumablesDlg_MagentaToner_label", N_("Magenta:"), "hbox65", 0 },
	{ ID_CTRLYELLOWINFO, LABEL_TYPE_TEXT, "ConsumablesDlg_YellowToner_label", N_("Yellow:"), "hbox66", 0 },
	{ ID_CTRLBLACKINFO, LABEL_TYPE_TEXT, "ConsumablesDlg_BlackToner_label", N_("Black:"), "hbox67", 0 },
	{ ID_CTRLCONSUMABLESDLG_TYPE1, LABEL_TYPE_BOX, NULL, NULL, "ConsumablesDlg_Type1_box", 0 },
	{ ID_CTRLCONSUMABLESDLG_TYPE2, LABEL_TYPE_BOX, NULL, NULL, "ConsumablesDlg_Type2_box", 0 },
	{ ID_CTRLBLACKTONERINFO, LABEL_TYPE_BOX, NULL, NULL, "ConsumablesDlg2_BlackToner_box", 0 },
	{ ID_CTRLBLACKCARTRIDGEINFO, LABEL_TYPE_BOX, NULL, NULL, "ConsumablesDlg2_BlackCartridge_box", 0 },
	{ ID_CTRLCONSUMABLESDLG_TYPE3, LABEL_TYPE_BOX, NULL, NULL, "ConsumablesDlg_Type3_box", 0 },
	{ ID_CTRLCT3TONERINFO, LABEL_TYPE_BOX, NULL, NULL, "ConsumablesDlg3_Toner_box", 0 },
	{ ID_CTRLCT3DRUMINFO, LABEL_TYPE_BOX, NULL, NULL, "ConsumablesDlg3_Drum_box", 0 },
	{ ID_CTRLCT3TONERCARTRIDGEINFO, LABEL_TYPE_BOX, NULL, NULL, "ConsumablesDlg3_TonerCartridge_box", 0 },
	{ ID_CTRLCT3DRUMCARTRIDGEINFO, LABEL_TYPE_BOX, NULL, NULL, "ConsumablesDlg3_DrumCartridge_box", 0 },

	{ ID_CTRLCONSUMABLESDLG_TYPE4, LABEL_TYPE_BOX, NULL, NULL, "ConsumablesDlg_Type4_box", 0 },
	{ ID_CTRLCT4TONERINFO, LABEL_TYPE_BOX, NULL, NULL, "ConsumablesDlg4_Toner_box", 0 },
	{ ID_CTRLCT4DRUMINFO, LABEL_TYPE_BOX, NULL, NULL, "ConsumablesDlg4_Drum_box", 0 },
	{ ID_CTRLCT4TONERCARTRIDGEINFO, LABEL_TYPE_BOX, NULL, NULL, "ConsumablesDlg4_TonerCartridge_box", 0 },
	{ ID_CTRLCT4DRUMCARTRIDGEINFO, LABEL_TYPE_BOX, NULL, NULL, "ConsumablesDlg4_DrumCartridge_box", 0 },
	{ -1, -1, NULL, NULL, NULL, -1 }
};

UIConsumablesDlg* CreateConsumablesDlg(UIDialog* const parent)
{
	UIConsumablesDlg *pDialog;

	pDialog = (UIConsumablesDlg *)CreateDialog(sizeof(UIConsumablesDlg), parent);

	if( pDialog != NULL )
	{
		UI_DIALOG(pDialog)->window = create_Consumables_dialog();
	}
	return pDialog;
}

void ShowConsumablesDlg( UIStatusWnd* const wnd )
{
	int nRet = 0;

	if( wnd == NULL )
	{
		return;
	}
	if( wnd->consumables_dlg == NULL )
	{
		wnd->consumables_dlg = CreateConsumablesDlg( UI_DIALOG( wnd ) );
	}

	SigDisable();
	nRet = InitConsumablesDlgWidgets( wnd );
	SigEnable();

	if( nRet == 0 )
	{
		ShowDialog( (UIDialog *)wnd->consumables_dlg, NULL );
	}
	else
	{
		ShowMsgDlg( wnd, ID_CONSUMABLEINFO_ERR_GET );
		if( wnd->consumables_dlg != NULL )
		{
			if( wnd->consumables_dlg->pDialogDict != NULL )
			{
				DeleteDict( wnd->consumables_dlg->pDialogDict );
				wnd->consumables_dlg->pDialogDict = NULL;
			}
			mem_free( wnd->consumables_dlg );
			wnd->consumables_dlg = NULL;
		}
	}
}

static int InitConsumablesDlgWidgets( UIStatusWnd* const wnd )
{
	GtkWidget *pWindow = NULL;
	int nRet = 0;
	if( wnd == NULL )
	{
		return -1;
	}

	if( wnd->consumables_dlg == NULL )
	{
		return -1;
	}
	else
	{
		pWindow = wnd->consumables_dlg->dialog.window;
	}

	GString *gsPpdKey = NULL;
	gsPpdKey = g_string_new_wrapper("CNSUICtrlConsumables", __FILE__, __LINE__);

	if (isCrgTypeDevice(wnd))
	{
		char* pCartridgeType = NULL;
		getEquipmentCrgTypeFromCNSUICrgTypeList(wnd, &pCartridgeType);
		if (pCartridgeType == NULL)
		{
			return -1;
		}
		mem_free(pCartridgeType);

		GString *gsExtraStr = NULL;
		gsExtraStr = g_string_new_wrapper(NULL, __FILE__, __LINE__);
		createCrgTypeXStr(wnd, "CtrlCRGLowThreshold", NULL, gsExtraStr);

		g_string_append(gsPpdKey, gsExtraStr->str);
		g_string_free_wrapper(gsExtraStr, TRUE);
	}
	const char* const ctrl_type[CONSUMABLES_CTRL_TYPE_NUM] = { "CNSUIConsumablesDlg", gsPpdKey->str, NULL };

	const struct _consumable_status_conv_t statusConvTable[CONSUMABLES_STATUS_CONV_TBL_NUM] = {
		{ KEY_ABSENT, N_("Insert Cartridge") },
		{ KEY_MISPLACE, N_("Insert Cartridge") },
		{ KEY_WARNING3, N_("Replace Cartridge") },
		{ KEY_WARNING5, N_("Replace Cartridge") },
		{ KEY_WARNING2, N_("Replace Cartridge") },
		{ KEY_MEMERROR, N_("Replace Cartridge") },
		{ KEY_SEALEDERROR, N_("Replace Cartridge") },
		{ KEY_MOUNTERROR, N_("Replace Cartridge") },
		{ KEY_WARNING1, N_("Replacement Needed Soon") },
		{ CONSUMABLES_STATUS_NORMAL, N_("Available") },
		{ NULL, NULL }
	};
	struct _consumable_commandVal_control_t commandValControlTable[CONSUMABLES_COMMAND_VAL_CTR_TBL_NUM] = {
		{ TONER_C_STR, "ConsumablesDlg_CyanTonerAmmount_label", ID_CTRLCYANINFO, FALSE, FALSE },
		{ TONER_M_STR, "ConsumablesDlg_MagentaTonerAmmount_label", ID_CTRLMAGENTAINFO, FALSE, FALSE },
		{ TONER_Y_STR, "ConsumablesDlg_YellowTonerAmmount_label", ID_CTRLYELLOWINFO, FALSE, FALSE },
		{ TONER_K_STR, "ConsumablesDlg_BlackTonerAmmount_label", ID_CTRLBLACKINFO, FALSE, FALSE },
		{ TONER_K_STR, "ConsumablesDlg2_BlackTonerAmount_label", ID_CTRLBLACKTONERINFO, FALSE, FALSE },
		{ TONER_K_STR, "ConsumablesDlg3_TonerAmount_label", ID_CTRLCT3TONERINFO, FALSE, FALSE },
		{ DRUM_K_STR, "ConsumablesDlg3_DrumAmount_label", ID_CTRLCT3DRUMINFO, FALSE, FALSE },
		{ TONER_K_STR, "ConsumablesDlg4_TonerAmount_label", ID_CTRLCT4TONERINFO, FALSE, FALSE },
		{ DRUM_K_STR, "ConsumablesDlg4_DrumAmount_label", ID_CTRLCT4DRUMINFO, FALSE, FALSE },
		{ NULL, NULL, -1, FALSE, FALSE }
	};

	const struct _consumable_status_conv_t statusConvTonerTable[CONSUMABLES_STATUS_CONV_TBL_NUM] = {
		{ KEY_ABSENT, N_("Not Available") },
		{ KEY_MISPLACE, N_("Not Available") },
		{ KEY_WARNING3, N_("Out") },
		{ KEY_WARNING5, N_("Out") },
		{ KEY_WARNING2, N_("Out") },
		{ KEY_MEMERROR, N_("Out") },
		{ KEY_SEALEDERROR, N_("Out") },
		{ KEY_MOUNTERROR, N_("Out") },
		{ KEY_WARNING1, N_("Low") },
		{ CONSUMABLES_STATUS_NORMAL, N_("Full") },
		{ NULL, NULL }
	};
	struct _consumable_commandVal_control_t commandValTonerControlTable[CONSUMABLES_COMMAND_VAL_TONER_CTR_TBL_NUM] = {
		{ TONER_K_STR, "ConsumablesDlg4_TonerRemaining_label", ID_CTRLCT4TONERINFO, FALSE, FALSE },
		{ NULL, NULL, -1, FALSE, FALSE }
	};

	const struct _consumable_remain_control_t remainTable[CONSUMABLES_REMAIN_TBL_NUM] = {
		{KEY_REMAIN_K, "ConsumablesDlg2_BlackTonerRemaining_label", ID_CTRLBLACKTONERINFO},
		{KEY_REMAIN_K, "ConsumablesDlg3_TonerRemaining_label", ID_CTRLCT3TONERINFO},
		{KEY_DRUMREMAIN_K, "ConsumablesDlg3_DrumRemaining_label", ID_CTRLCT3DRUMINFO},
		{KEY_DRUMREMAIN_K, "ConsumablesDlg4_DrumRemaining_label", ID_CTRLCT4DRUMINFO},
		{NULL, NULL, -1}
	};

	const struct _consumable_cartridge_control_t cartridgeTable[CONSUMABLES_CARTRIDGE_TBL_NUM] = {
		{"CNSUICARTRIDGEBLACK", "ConsumablesDlg2_BlackCartridgeName_label", ID_CTRLBLACKCARTRIDGEINFO, ""},
		{"CNSUICARTRIDGEBLACK", "ConsumablesDlg3_TonerCartridgeName_label", ID_CTRLCT3TONERCARTRIDGEINFO, "_Toner_CrgType1"},
		{"CNSUICARTRIDGEBLACK", "ConsumablesDlg3_DrumCartridgeName_label", ID_CTRLCT3DRUMCARTRIDGEINFO, "_Drum_CrgType1"},
		{"CNSUICARTRIDGEBLACK", "ConsumablesDlg4_TonerCartridgeName_label", ID_CTRLCT4TONERCARTRIDGEINFO, "_Toner_CrgType2"},
		{"CNSUICARTRIDGEBLACK", "ConsumablesDlg4_DrumCartridgeName_label", ID_CTRLCT4DRUMCARTRIDGEINFO, "_Drum_CrgType2"},
		{NULL, NULL, -1}
	};


	CreatePPDCtrlTbl( wnd, ctrl_type, ctrlTbl, PPDCtrlTbl );
	g_string_free_wrapper(gsPpdKey, TRUE);
	AddPPDCtrlTbl();

	SetLabel_HideWidget( pWindow, PPDCtrlTbl, ctrlTbl );

	if( wnd->consumables_dlg->pDialogDict != NULL )
	{
		UI_DEBUG("pDialogDict no mem_free, from Func[%s] Line[%u] \n", __func__, __LINE__);
		DeleteDict( wnd->consumables_dlg->pDialogDict );
	}

	wnd->consumables_dlg->pDialogDict = CreateDict_GetConsumable();
	if( wnd->consumables_dlg->pDialogDict == NULL )
	{
		return -1;
	}

	nRet = CommunicatePrinterData( wnd, NULL, wnd->consumables_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	if( nRet != 0 )
	{
		return -1;
	}

	CheckPPDValues( wnd, PPDCtrlTbl, commandValControlTable );
	SetConsumablesAmmount( wnd, statusConvTable, commandValControlTable );

	CheckPPDValues( wnd, PPDCtrlTbl, commandValTonerControlTable );
	SetConsumablesAmmount( wnd, statusConvTonerTable, commandValTonerControlTable );

	SetConsumablesRemain(wnd, PPDCtrlTbl, remainTable);
	SetConsumablesCartridge(wnd, PPDCtrlTbl, cartridgeTable);

	return nRet;
}

static void CheckPPDValues( const UIStatusWnd* const wnd, CtrlTbl* const * const pPPDCtrlTbl, struct _consumable_commandVal_control_t* const pTbl )
{
	int i = 0, j = 0;

	if( (wnd == NULL) || (pPPDCtrlTbl == NULL) || (pTbl == NULL ) )
	{
		return;
	}

	for( i = 0; pPPDCtrlTbl[i] != NULL; i++ )
	{
		for( j = 0; pTbl[j].commandVal != NULL; j++ )
		{
			if( pPPDCtrlTbl[i]->ctrlid == pTbl[j].ctrlid )
			{
				pTbl[j].isEnable = TRUE;
			}
		}
	}
}

static void AddPPDCtrlTbl( void )
{
	AddCtrlData( ID_CTRLTONERCARTRIDGEINFO, ctrlTbl, PPDCtrlTbl );

	if (!CheckControlEnabled(PPDCtrlTbl, ID_CTRLCONSUMABLESDLG_TYPE1) &&
		!CheckControlEnabled(PPDCtrlTbl, ID_CTRLCONSUMABLESDLG_TYPE2) &&
		!CheckControlEnabled(PPDCtrlTbl, ID_CTRLCONSUMABLESDLG_TYPE3) &&
		!CheckControlEnabled(PPDCtrlTbl, ID_CTRLCONSUMABLESDLG_TYPE4))
	{
		AddCtrlData(ID_CTRLCONSUMABLESDLG_TYPE1, ctrlTbl, PPDCtrlTbl);
	}
}

static void SetConsumablesAmmount( const UIStatusWnd* const wnd, const struct _consumable_status_conv_t* const statusConvTbl, struct _consumable_commandVal_control_t* const cmdSetTbl )
{
	int i = 0, j = 0, nIndex = 0;
	GtkWidget *pWindow = NULL;
	GList* pValues = NULL;
	Dict* pValueDict = NULL;

	if( (wnd == NULL) || (statusConvTbl == NULL) || (cmdSetTbl == NULL ) )
	{
		return;
	}

	pWindow = wnd->consumables_dlg->dialog.window;
	pValueDict = wnd->consumables_dlg->pDialogDict;
	for( i = 0; statusConvTbl[i].statusKey != NULL; i++ )
	{
		pValues = GetDictValueGList_forKey( pValueDict, statusConvTbl[i].statusKey );
		if( pValues != NULL )
		{
			for( nIndex = 0; (unsigned int )nIndex < g_list_length( pValues ); ++nIndex )
			{
				for( j = 0; cmdSetTbl[j].commandVal != NULL; j++ )
				{
					if( g_list_find_custom(pValues, cmdSetTbl[j].commandVal, (GCompareFunc)strcmp ) != NULL )
					{
						if( (cmdSetTbl[j].isEnable == TRUE) && (cmdSetTbl[j].isSet == FALSE) )
						{
							SetTextToLabel( pWindow, cmdSetTbl[j].control, _(statusConvTbl[i].printStatus) );
							cmdSetTbl[j].isSet = TRUE;
						}
					}
				}
			}
		}
	}

	for( i = 0; cmdSetTbl[i].commandVal != NULL; i++ )
	{
		if( (cmdSetTbl[i].isEnable == TRUE) && (cmdSetTbl[i].isSet == FALSE) )
		{
			SetTextToLabel( pWindow, cmdSetTbl[i].control, _(statusConvTbl[CONSUMABLES_STATUS_CONV_TBL_NUM-2].printStatus) );
		}
	}

}

static void SetConsumablesRemain(const UIStatusWnd* const wnd, CtrlTbl* const * const pPPDCtrlTbl, const struct _consumable_remain_control_t* const pTbl)
{
	int i = 0;
	int nValue = 255;
	GString *gsValue = NULL;

	if ((wnd == NULL) || (pTbl == NULL))
	{
		return;
	}

	gsValue = g_string_new_wrapper(NULL, __FILE__, __LINE__);
	if (gsValue == NULL)
	{
		return;
	}

	for (i = 0; pTbl[i].statusKey != NULL; i ++)
	{
		if (!CheckControlEnabled(pPPDCtrlTbl, pTbl[i].ctrlid))
		{
			continue;
		}

		if (GetDictValueInt_forKey(wnd->consumables_dlg->pDialogDict, pTbl[i].statusKey, &nValue))
		{
			if (255 == nValue)
			{
				;
			}
			else if (100 < nValue)
			{
				nValue = 100;
			}
			else if (0 > nValue)
			{
				nValue = 0;
			}
			else
			{
				nValue = ((nValue + 9) / 10) * 10;
			}
		}

		g_string_erase(gsValue, 0, gsValue->len);

		if (255 != nValue)
		{
			g_string_printf(gsValue, "%d", nValue);

			SetTextToLabel(wnd->consumables_dlg->dialog.window, pTbl[i].control, gsValue->str);
		}
	}

	g_string_free_wrapper(gsValue, TRUE);
}

static void SetConsumablesCartridge(const UIStatusWnd* const wnd, CtrlTbl* const * const pPPDCtrlTbl, const struct _consumable_cartridge_control_t* const pTbl)
{
	int i = 0;
	int j = 0;
	char *pPPDVal = NULL;
	char **ppPPDValList = NULL;
	char *pXMLVal = NULL;
	GString *gsPPDKey = NULL;
	const char *pArea = NULL;

	if ((wnd == NULL) || (pTbl == NULL))
	{
		return;
	}

	gsPPDKey = g_string_new_wrapper(NULL, __FILE__, __LINE__);
	if (gsPPDKey == NULL)
	{
		return;
	}

	for (i = 0; pTbl[i].ppdKey != NULL; i ++)
	{
		if (!CheckControlEnabled(pPPDCtrlTbl, pTbl[i].ctrlid))
		{
			continue;
		}

		g_string_erase(gsPPDKey, 0, gsPPDKey->len);

		g_string_append(gsPPDKey, pTbl[i].ppdKey);
		g_string_append(gsPPDKey, "_");
		pArea = GetAreaInfo(wnd);
		if (pArea)
		{
			g_string_append(gsPPDKey, pArea);
		}

		for (j = 0; j < gsPPDKey->len; j ++)
		{
			if (gsPPDKey->str[j] == ' ')
			{
				gsPPDKey->str[j] = '_';
			}
		}

		pPPDVal = cngplpGetValue(wnd->pModData, gsPPDKey->str);
		if (pPPDVal)
		{
			ppPPDValList = SeparateString(pPPDVal, CHARACTER_COMMA);
			if (ppPPDValList)
			{
				GString *gsMsgXmlKey = NULL;
				gsMsgXmlKey = g_string_new_wrapper(ppPPDValList[0], __FILE__, __LINE__);
				g_string_append(gsMsgXmlKey, pTbl[i].msgKey);

				pXMLVal = xmlGetString(wnd->pMsgXmlContext, gsMsgXmlKey->str);
				g_string_free_wrapper(gsMsgXmlKey, TRUE);
				if (pXMLVal)
				{
					SetTextToLabel(wnd->consumables_dlg->dialog.window, pTbl[i].control, pXMLVal);
					mem_free(pXMLVal);
				}

				mem_free_list(ppPPDValList);
			}

			mem_free(pPPDVal);
		}
	}

	g_string_free_wrapper(gsPPDKey, TRUE);
}

void DisposeConsumablesDlg( UIStatusWnd* const wnd )
{
	UIConsumablesDlg* ui_consumables_dlg = NULL;

	if(wnd == NULL)
	{
		return;
	}

	ui_consumables_dlg = wnd->consumables_dlg;
	if( ui_consumables_dlg != NULL )
	{
		if( ui_consumables_dlg->pDialogDict != NULL )
		{
			DeleteDict( ui_consumables_dlg->pDialogDict );
			ui_consumables_dlg->pDialogDict = NULL;
		}
		DisposeDialog( (UIDialog *)ui_consumables_dlg );
		wnd->consumables_dlg = NULL;
	}
}

