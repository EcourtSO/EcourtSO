/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */



#ifndef _KEY_DEFINENS
#define _KEY_DEFINENS

#define KEY_COMMAND					"Command"
#define KEY_ERROR					"Error"
#define	KEY_YEAR					"Year"
#define	KEY_MONTH					"Month"
#define	KEY_DAY						"Day"
#define	KEY_DAYOFWEEK				"DayofWeek"
#define	KEY_HOUR					"Hour"
#define	KEY_MINUTE					"Minute"
#define	KEY_SECOND					"Second"
#define	KEY_MILLISECOND				"MilliSecond"
#define KEY_OPERATION				"Operation"
#define KEY_JOB_ID					"JobID"
#define KEY_JOB_LIST				"JobList"
#define KEY_ITEM_LIST				"ItemList"
#define KEY_PAPER_SOURCE			"PaperSource"
#define KEY_PAPER_SIZE				"PaperSize"
#define KEY_PAPER_TYPE				"PaperType"
#define KEY_ORIENTATION				"Orientation"
#define KEY_CUSTOM_X                "CustomX"
#define KEY_CUSTOM_Y                "CustomY"
#define KEY_CUSTOM_UNIT             "CustomUnit"
#define KEY_CODE					"Code"
#define KEY_DOCUMENT				"Document"
#define KEY_USER					"User"
#define KEY_JOB_STATUS				"JobStatus"
#define KEY_TOTAL_PAGE				"TotalPage"
#define KEY_PRINTED_PAGE			"PrintedPage"
#define KEY_STATUS_GRP				"StatusGroup"
#define KEY_STATUS					"Status"
#define KEY_EQUIPMENT				"Equipment"
#define KEY_PAPER_WARNING			"PaperWarning"
#define KEY_DRUM_MEMORY_WARNING		"DrumMemoryWarning"
#define KEY_DRUM_LIFETIME_WARNING	"DrumLifenoticeWarning"
#define KEY_DRUMOUT2_WARNING		"DrumOUT2Warning"
#define KEY_DRUMOUT3_WARNING		"DrumOUT3Warning"
#define KEY_DRUMOUT1_WARNING		"DrumOUT1Warning"
#define KEY_TONER_LIFETIME_WARNING	"TonerLifenoticeWarning"
#define KEY_TONEROUT2_WARNING		"TonerOUT2Warning"
#define KEY_TONEROUT1_WARNING		"TonerOUT1Warning"
#define KEY_TONER_MEMORY_WARNING	"TonerMemoryWarning"
#define KEY_CONSUMABLE_ERROR		"ConsumableError"
#define KEY_JAM_ACCESS				"JamAccess"
#define KEY_COVER_POS				"CoverPos"
#define KEY_WAIT_DETAIL				"WaitDetail"
#define KEY_OTHER_WAR				"OtherWar"
#define KEY_TONEROUT3_WARNING		"TonerOUT3Warning"
#define KEY_TONER_ACCESS			"TonerAccess"
#define KEY_MODEL_CODE				"ModelCode"
#define KEY_ERROR_PAPER_STATUS		"ErrorPaperStatus"
#define KEY_PAPER_LIST				"PaperList"
#define KEY_SERVICE_ERROR_CODE		"ServiceErrorCode"
#define KEY_PARAM					"Param"
#define KEY_RESUlT					"Result"
#define KEY_WARNING1				"Warning1"
#define KEY_WARNING2				"Warning2"
#define KEY_WARNING3				"Warning3"
#define KEY_WARNING4				"Warning4"
#define KEY_ABSENT					"Absent"
#define KEY_MISPLACE				"Misplace"
#define KEY_MEMERROR				"MemError"
#define KEY_MOUNTERROR				"MountError"
#define KEY_SEALEDERROR				"SealedError"
#define KEY_WARNING5				"Warning5"
#define KEY_REMAIN_Y				"Remain_Y"
#define KEY_REMAIN_M				"Remain_M"
#define KEY_REMAIN_C				"Remain_C"
#define KEY_REMAIN_K				"Remain_K"
#define KEY_DRUMREMAIN_Y			"DrumRemain_Y"
#define KEY_DRUMREMAIN_M			"DrumRemain_M"
#define KEY_DRUMREMAIN_C			"DrumRemain_C"
#define KEY_DRUMREMAIN_K			"DrumRemain_K"
#define KEY_ID						"ID"
#define KEY_ID_LIST					"IDList"
#define KEY_ITEM					"Item"
#define KEY_DHALF_Y					"DHALF_Y"
#define KEY_DHALF_M					"DHALF_M"
#define KEY_DHALF_C					"DHALF_C"
#define KEY_DHALF_K					"DHALF_K"
#define KEY_CPR_K					"CPR_K"
#define KEY_CPR_C					"CPR_C"
#define KEY_CPR_M					"CPR_M"
#define KEY_CPR_Y					"CPR_Y"
#define KEY_DIGIREG_K				"DIGIREG_K"
#define KEY_DIGIREG_C				"DIGIREG_C"
#define KEY_DIGIREG_M				"DIGIREG_M"
#define KEY_DIGIREG_Y				"DIGIREG_Y"
#define KEY_CONNECT_STATUS          "ConnectStatus"
#define KEY_WLAN_STATUS				"WlanStatus"
#define KEY_WLAN_INFO               "WlanInfo"
#define KEY_WLAN_STATUS_BSSID		"WlanStatus_BSSID"
#define KEY_SSID					"SSID"
#define KEY_SECURITY				"Security"
#define KEY_RSSI					"Rssi"
#define KEY_CHANNEL					"Channel"
#define KEY_RESULT					"Result"
#define KEY_WPA_SECURITY			"WPASecurity"
#define KEY_PSK_INPUT				"PSKInput"
#define KEY_PSK						"PSK"
#define KEY_WEP_LENGTH				"WEPLength"
#define KEY_WEP_INPUT				"WEPInput"
#define KEY_WEP1					"WEP1"
#define KEY_WEP2					"WEP2"
#define KEY_WEP3					"WEP3"
#define KEY_WEP4					"WEP4"
#define KEY_WEPNUM					"WEPNum"
#define KEY_80211AUTH				"Auth80211"
#define KEY_GETAREAINFO				"GetAreaInfo"
#define KEY_AREAINFO				"AreaInfo"

#endif
