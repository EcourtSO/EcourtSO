#!/bin/sh
export PATH=$PATH:/usr/local/jdk1.8.0_181/bin
cd /opt/apps/com.digisigner.pdfsigner/files
/usr/local/jdk1.8.0_181/bin/java -jar PROXKeysigner.jar