/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#ifndef _ID_DEFINENS
#define _ID_DEFINENS

#define ID_DATA_TYPE_BINARY 1
#define ID_DATA_TYPE_LONG   2
#define ID_DATA_TYPE_STRING 3
#define ID_DATA_TYPE_OTHER  4

#define ID100013	100013
#define ID100023	100023
#define ID100033	100033
#define ID100043	100043
#define ID100053	100053

#define ID110012	110012
#define ID110022	110022
#define ID110032	110032
#define ID110042	110042
#define ID110052	110052
#define ID110062	110062
#define ID110072	110072
#define ID110082	110082
#define ID110092	110092
#define ID110102	110102
#define ID110112	110112
#define ID110122	110122
#define ID110132	110132
#define ID110142	110142
#define ID110152	110152
#define ID110162	110162
#define ID110172	110172
#define ID110182	110182
#define ID110192	110192
#define ID110202	110202
#define ID110212	110212
#define ID110222	110222
#define ID110232	110232
#define ID110242	110242
#define ID110252	110252
#define ID110262	110262
#define ID110272	110272

#define ID112	112
#define ID122	122
#define ID132	132
#define ID143	143
#define ID153	153
#define ID163	163
#define ID173	173
#define ID183	183
#define ID192	192
#define ID202	202
#define ID212	212
#define ID222	222
#define ID232	232
#define ID242	242
#define ID252	252
#define ID262	262
#define ID272	272
#define ID282	282
#define ID292	292
#define ID302	302
#define ID312	312
#define ID323	323
#define ID333	333
#define ID343	343
#define ID353	353
#define ID362	362
#define ID393	393
#define ID402	402
#define ID412	412
#define ID422	422
#define ID432	432
#define ID442	442
#define ID452	452
#define ID462	462
#define ID472	472
#define ID482	482
#define ID492	492
#define ID502	502
#define ID512	512
#define ID522	522
#define ID532	532
#define ID542	542
#define ID552	552
#define ID562	562
#define ID572	572
#define ID582	582
#define ID592	592
#define ID602	602
#define ID612	612
#define ID622	622
#define ID632	632
#define ID642	642
#define ID652	652
#define ID662	662
#define ID672	672
#define ID673	673
#define ID682	682
#define ID683	683
#define ID692	692
#define ID702	702
#define ID713	713
#define ID722	722
#define ID732	732
#define ID742	742
#define ID752	752
#define ID764	764
#define ID772	772
#define ID793	793
#define ID803	803
#define ID812	812
#define ID822	822
#define ID832	832
#define ID842	842
#define ID852	852
#define ID862	862
#define ID872	872
#define ID882	882
#define ID894	894
#define ID924	924
#define ID934	934
#define ID942	942
#define ID954	954
#define ID964	964
#define ID974	974
#define ID992	992
#define ID1002	1002
#define ID1012	1012
#define ID1022	1022
#define ID1032	1032
#define ID1042	1042
#define ID1052	1052
#define ID1062	1062
#define ID1072	1072
#define ID1082	1082
#define ID1092	1092
#define ID1122	1122
#define ID1192	1192
#define ID1202	1202
#define ID1422	1422
#define ID1664	1664
#define ID1674	1674
#define ID1684	1684
#define ID1694	1694
#define ID1722	1722
#define ID1732	1732
#define ID1742	1742
#define ID1793	1793
#define ID1803	1803
#define ID1813	1813
#define ID1823	1823
#define ID1833	1833
#define ID2033	2033
#define ID2042	2042
#define ID2373	2373
#define ID2392	2392
#define ID2402	2402
#define ID2412	2412
#define ID2422	2422

#define ID120013	120013
#define ID120023	120023
#define ID120073	120073
#define ID120083	120083
#define ID120093	120093
#define ID120103	120103
#define ID120113	120113
#define ID120123	120123
#define ID120153	120153
#define ID120163	120163
#define ID120193	120193
#define ID120303	120303
#define ID120313	120313
#define ID120383	120383
#define ID120523	120523
#define ID120533	120533
#define ID120623	120623
#define ID120643	120643
#define ID120653	120653
#define ID120663	120663
#define ID120673	120673
#define ID120692	120692
#define ID120702	120702
#define ID120712	120712
#define ID120722	120722
#define ID120732	120732
#define ID120764	120764
#define ID120774	120774
#define ID120782	120782
#define ID120794	120794
#define ID120803	120803
#define ID120813	120813
#define ID120843	120843
#define ID120893	120893
#define ID120903	120903
#define ID120913	120913
#define ID120933	120933
#define ID120983	120983
#define ID120993	120993
#define ID121003	121003
#define ID121023	121023
#define ID121073	121073
#define ID121083	121083
#define ID121093	121093
#define ID121173	121173
#define ID121183	121183
#define ID121193	121193
#define ID121373	121373
#define ID121472	121472
#define ID121742	121742
#define ID121783	121783
#define ID121793	121793
#define ID122342	122342

#endif
