﻿=================================================================================
Canon MF/LBP Network Setup Tool Versione 2.31

LEGGERE QUESTO DOCUMENTO ATTENTAMENTE
=================================================================================

AVVERTENZE

Notare i seguenti limiti quando si utilizza il software.

1. Il software può rilevare fino a 10 punti di accesso LAN wireless ricercando i punti di accesso LAN wireless. 

2. Il software non riesce a rilevare i punti di accesso LAN wireless ricercando i punti di accesso LAN wireless quando questi utilizzano la funzione non rilevabile. 

3. Quando di aggiorna il firmware della stampante, o immediatamente dopo che il tasto di alimentazione è ACCESO o SPENTO, o quando la stampante è in stampa, non è possibile creare impostazioni di configurazione usando questo software. 

4. Secondo l'ambiente operativo, la funzione "Consigli utili" non può essere visualizzata direttamente da questo software.
In questo caso, seguire il messaggio su schermo per mostrare la funzione "Consigli utili" dal browser web che si utilizza.

=================================================================================
                                                        Copyright CANON INC. 2014

