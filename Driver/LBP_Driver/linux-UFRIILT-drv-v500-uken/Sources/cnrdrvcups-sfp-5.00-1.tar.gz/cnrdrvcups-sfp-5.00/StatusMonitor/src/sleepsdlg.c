/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */



#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "uimain.h"
#include "widgets.h"
#include "interface.h"
#include "sleepsdlg.h"
#include "callbacks.h"
#include "support.h"
#include "id_defines.h"
#include "commandcontroller.h"
#include "value_defines.h"

#define SLEEP_TIME_CNT 32
#define SLEEP_CTRL_TYPE_NUM 3
#define SLEEP_TIME_TBL_NUM 11
#define SLEEP_CTRL_TBL_NUM 5

static int InitSleepSettingDlgWidgets( UIStatusWnd* const wnd );
static unsigned int SetItemValue_SleepSettingDlgOK( const UIStatusWnd* const wnd );

CtrlTbl* PPDCtrlTbl[CTRL_LIST_MAXNUM];

static char *SleepTimeTbl[SLEEP_TIME_TBL_NUM] =
{
	"1", "5", "10", "15", "30", "60", "90", "120", "150", "180", NULL
};

static CtrlTbl ctrlTbl[SLEEP_CTRL_TBL_NUM] =
{
	{ ID_SLEEPSETTING_DIALOG1, LABEL_TYPE_TITLE, NULL, N_("Sleep Settings"), NULL, 0 },
	{ ID_CTRLSLEEPENABLE, LABEL_TYPE_BUTTON, "SleepSDlg_Use_checkbutton", N_("Auto Sleep after Fixed Period"), "SleepSDlg_Use_checkbutton", ID1052 },
	{ ID_CTRLSLEEPTIME, LABEL_TYPE_TEXT, "label157", N_("Auto Sleep After:"), "hbox61", ID112 },
	{ ID_CTRLSLEEPTIME_MIN, LABEL_TYPE_TEXT, "label158", N_("min."), NULL, 0 },
	{ -1, -1, NULL, NULL, NULL, -1 }
};

UISleepSettingDlg* CreateSleepSettingDlg(UIDialog * const parent)
{
	UISleepSettingDlg *pDialog;

	pDialog = (UISleepSettingDlg *)CreateDialog(sizeof(UISleepSettingDlg), parent);

	if( pDialog != NULL )
	{
		UI_DIALOG(pDialog)->window = create_SleepS_dialog();
	}
	return pDialog;
}

void ShowSleepSettingDlg( UIStatusWnd* const wnd )
{
	int nRet = 0;

	if( wnd == NULL )
	{
		return;
	}
	if( wnd->sleeps_dlg == NULL )
	{
		wnd->sleeps_dlg = CreateSleepSettingDlg( UI_DIALOG( wnd ) );
	}

	SigDisable();
	nRet = InitSleepSettingDlgWidgets( wnd );
	SigEnable();

	if( nRet == 0 )
	{
		ShowDialog( (UIDialog *)wnd->sleeps_dlg, NULL );
	}
	else
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_GET );
		if( wnd->sleeps_dlg != NULL )
		{
			if( wnd->sleeps_dlg->pDialogDict != NULL )
			{
				DeleteDict( wnd->sleeps_dlg->pDialogDict );
				wnd->sleeps_dlg->pDialogDict = NULL;
			}
			mem_free( wnd->sleeps_dlg );
			wnd->sleeps_dlg = NULL;
		}
	}
}

static unsigned int SetItemValue_SleepSettingDlgOK( const UIStatusWnd* const wnd )
{
	int i = 0;
	int nValue = 0;
	char *pValue = NULL;
	unsigned int unRet = 0;
	GtkWidget *pWindow = NULL;

	if( wnd == NULL )
	{
		return DICT_SET_RETURN_ERROR;
	}
	pWindow = wnd->sleeps_dlg->dialog.window;

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		switch( PPDCtrlTbl[i]->dbid )
		{
		case ID1052:
			nValue = GetToggleButtonActive( pWindow, "SleepSDlg_Use_checkbutton", FALSE );
			unRet |= SetItemValuetype_int( wnd->sleeps_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, nValue );
			break;
		case ID112:
			pValue = GetCurrComboBoxText( pWindow, "SleepSDlg_Time_combo" );
			if( pValue == NULL )
			{
				unRet |= DICT_SET_RETURN_ERROR;
			}
			else
			{
				nValue = atoi(pValue);
				mem_free(pValue);
				unRet |= SetItemValuetype_int( wnd->sleeps_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, nValue );
			}
			break;
		default:
			break;
		}
		if( (unRet & DICT_SET_RETURN_ERROR) == DICT_SET_RETURN_ERROR )
		{
			break;
		}
	}
	return unRet;
}

void SleepSettingDlgOK( UIStatusWnd* const wnd )
{
	int nRet = 0;
	unsigned int unRet = 0;

	if( wnd == NULL )
	{
		return;
	}

	nRet = CreateDict_SetData( wnd->sleeps_dlg->pDialogDict );

	if( nRet == 0 )
	{
		unRet = SetItemValue_SleepSettingDlgOK( wnd );
		if( (unRet & DICT_SET_RETURN_ERROR) == DICT_SET_RETURN_ERROR )
		{
			nRet = -1;
		}
	}

	if( ( nRet == 0 ) && ( unRet == DICT_SET_RETURN_CHANGE ) )
	{
		nRet = CommunicatePrinterData( wnd, (UIDialog *)wnd->sleeps_dlg, wnd->sleeps_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	}

	HideDialog( (UIDialog *)wnd->sleeps_dlg );

	if( nRet != 0 )
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_SET );
	}

	return;
}

void UpdateSleepSettingDlgWidgets(const UIStatusWnd * const wnd, const int use_sleep)
{
	if(wnd == NULL)
	{
		return;
	}

	GtkWidget * const pWindow = UI_DIALOG(wnd->sleeps_dlg)->window;

	if( pWindow != NULL )
	{
		SetWidgetSensitive(pWindow, "hbox61", use_sleep);
	}
}

static int InitSleepSettingDlgWidgets( UIStatusWnd* const wnd )
{
	GtkWidget *pWindow = NULL;
	GList *pGlist = NULL;
	char strValue[SLEEP_TIME_CNT];
	int nValue = 0;
	int i = 0;
	int nRet = 0;
	const char* const ctrl_type[SLEEP_CTRL_TYPE_NUM] = { "CNSUISleepDlg", "CNSUICtrlSleep", NULL };


	if( wnd == NULL )
	{
		return -1;
	}

	if( wnd->sleeps_dlg == NULL )
	{
		return -1;
	}
	else
	{
		pWindow = wnd->sleeps_dlg->dialog.window;
	}
	memset( strValue, 0, sizeof(strValue) );

	CreatePPDCtrlTbl( wnd, ctrl_type, ctrlTbl, PPDCtrlTbl );

	SetLabel_HideWidget( pWindow, PPDCtrlTbl, ctrlTbl );

	pGlist = CreateGlist_DbId( PPDCtrlTbl );

	if( wnd->sleeps_dlg->pDialogDict != NULL )
	{
		UI_DEBUG("pDialogDict no mem_free, from Func[%s] Line[%u] \n", __func__, __LINE__);
		DeleteDict( wnd->sleeps_dlg->pDialogDict );
	}
	wnd->sleeps_dlg->pDialogDict = CretateDict_GetData( pGlist );
	g_list_free_wrapper( pGlist );

	if( wnd->sleeps_dlg->pDialogDict == NULL )
	{
		return -1;
	}

	nRet = CommunicatePrinterData( wnd, NULL, wnd->sleeps_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	if( nRet != 0 )
	{
		return -1;
	}

	if( wnd->sleeps_dlg->pSleepTimeList == NULL )
	{
		char * const pTmp = cngplpGetValue_Wrapper( wnd->pModData, "CNSUISleepTimeList" );
		if( pTmp != NULL )
		{
			wnd->sleeps_dlg->pSleepTimeList = SeparateString( pTmp, CHARACTER_COMMA );
			mem_free( pTmp );
		}
	}

	if( wnd->sleeps_dlg->pSleepTimeList != NULL )
	{
		pGlist = CreateGlist_ComboList( wnd->sleeps_dlg->pSleepTimeList );
	}
	else
	{
		pGlist = CreateGlist_ComboList( SleepTimeTbl );
	}

	if(pGlist != NULL)
	{
		SetGListToComboBox( pWindow, "SleepSDlg_Time_combo", pGlist );
		g_list_free_wrapper( pGlist );
	}

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		switch( PPDCtrlTbl[i]->dbid )
		{
		case ID1052:
			GetItemValueType_int( wnd->sleeps_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, &nValue );
			SetActiveCheckButton( pWindow, "SleepSDlg_Use_checkbutton", nValue, FALSE );
			SetWidgetSensitive( pWindow, "hbox61", nValue );
			break;
		case ID112:
			GetItemValueType_int( wnd->sleeps_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, &nValue );
			if( nValue < 0 )
			{
				nRet = -1;
			}
			else
			{
				snprintf( strValue, (sizeof(strValue)-1), "%d", nValue );
				SetCurrComboBoxText(pWindow, "SleepSDlg_Time_combo", strValue);
			}
			break;
		default:
			break;
		}
		if( nRet != 0 )
		{
			break;
		}
	}
	return nRet;
}

void DisposeSleepSettingDlg( UIStatusWnd* const wnd )
{
	UISleepSettingDlg *ui_sleeps_dlg = NULL;

	if(wnd == NULL)
	{
		return;
	}

	ui_sleeps_dlg = wnd->sleeps_dlg;
	if( ui_sleeps_dlg != NULL)
	{
		if( ui_sleeps_dlg->pSleepTimeList != NULL )
		{
			mem_free_list( ui_sleeps_dlg->pSleepTimeList );
			ui_sleeps_dlg->pSleepTimeList = NULL;
		}
		if( ui_sleeps_dlg->pDialogDict != NULL )
		{
			DeleteDict( ui_sleeps_dlg->pDialogDict );
			ui_sleeps_dlg->pDialogDict = NULL;
		}
		DisposeDialog( (UIDialog *)ui_sleeps_dlg );
		wnd->sleeps_dlg = NULL;
	}
}

