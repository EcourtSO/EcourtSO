/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2015 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "uicomboboxitem.h"
#include "widgets.h"
#include "support.h"


struct _UIComboBoxItem
{
	GtkComboBox	*combobox;
	GList *valueList;
};

static gint GetIndexFromValue(GList * const pValueList, const char *pValue)
{
	gint nIndex = 0;
	gint i = 0;

	for (i = 0; i < (gint)g_list_length(pValueList); ++i)
	{
		const char *pListValue = NULL;

		pListValue = g_list_nth_data(pValueList, i);
		if (pListValue != NULL)
		{
			if (strcmp(pValue, pListValue) == 0)
			{
				nIndex = i;
				break;
			}
		}
	}
	return nIndex;
}

static const char *GetValueFromIndex(GList * const pValueList, guint nIndex)
{
	const char *pValue = NULL;

	if (nIndex < g_list_length(pValueList))
	{
		pValue = (const char *)g_list_nth_data(pValueList, nIndex);
	}
	return pValue;
}

static const gchar *GetComboBoxMessageIDFromValue(const ComboBoxContent *pComboBoxContent, const char *pValue)
{
	const gchar	*pMessageID = NULL;
	gint i = 0;

	for (i = 0; pComboBoxContent[i].pMessageID != NULL; i++)
	{
		if(strcmp(pValue, pComboBoxContent[i].pValue) == 0)
		{
			pMessageID = pComboBoxContent[i].pMessageID;
			break;
		}
	}
	return pMessageID;
}

static GList *CreateDisplayListFromComboBoxContent(const ComboBoxContent *pComboBoxContent, GList * const pValueList)
{
	GList *gList = NULL;
	gint i = 0;

	for (i = 0; i < (gint)g_list_length(pValueList); ++i)
	{
		const char *pValue = NULL;

		pValue = g_list_nth_data(pValueList, i);
		if (pValue != NULL)
		{
			const gchar *messageID = NULL;

			messageID = GetComboBoxMessageIDFromValue(pComboBoxContent, pValue);
			if (messageID != NULL)
			{
				gList = g_list_append_wrapper(gList, _(messageID), __FILE__, (unsigned int)__LINE__);
			}
		}
	}

	return gList;
}

UIComboBoxItem *CreateComboBoxItem(GtkWidget *pWindow, cngplpData *pModData, const char *pPPDKey, const char *pComboboxName, const ComboBoxContent *pComboBoxContent)
{
	UIComboBoxItem	*comboboxItem	= NULL;

	if ((pWindow != NULL) && (pModData != NULL) && (pPPDKey != NULL) && (pComboboxName != NULL) && (pComboBoxContent != NULL))
	{
		comboboxItem = (UIComboBoxItem *)mem_alloc(sizeof(UIComboBoxItem), __FILE__, (unsigned int)__LINE__);
		if (comboboxItem != NULL)
		{
			comboboxItem->valueList = CreateListFromPPDKey(pModData, pPPDKey);

			if (comboboxItem->valueList != NULL)
			{
				GList *pDisplayList = NULL;

				pDisplayList = CreateDisplayListFromComboBoxContent(pComboBoxContent, comboboxItem->valueList);
				if (pDisplayList != NULL)
				{
					SetGListToComboBox((GtkWidget * const)pWindow, pComboboxName, pDisplayList);
					g_list_free_wrapper(pDisplayList);
				}
			}

			{
				GtkWidget *widget = NULL;

				widget = getWidget(pWindow, pComboboxName);
				if (widget != NULL)
				{
					comboboxItem->combobox = GTK_COMBO_BOX(widget);
				}
			}

			if ((comboboxItem->valueList == NULL) || (comboboxItem->combobox == NULL))
			{
				DisposeComboBoxItem(comboboxItem);
				comboboxItem = NULL;
			}
		}
	}
	return comboboxItem;
}

void SetComboBoxSelectedValue(UIComboBoxItem *comboboxItem, const char *pValue)
{
	if ((comboboxItem != NULL) && (pValue != NULL))
	{
		const gint nIndex = GetIndexFromValue(comboboxItem->valueList, pValue);

		gtk_combo_box_set_active(comboboxItem->combobox, nIndex);
	}
}

const char *GetComboBoxSelectedValue(UIComboBoxItem *comboboxItem)
{
	const char *pValue	= NULL;

	if (comboboxItem != NULL)
	{
		const gint nIndex = gtk_combo_box_get_active(comboboxItem->combobox);

		if (nIndex != -1)
		{
			pValue = GetValueFromIndex(comboboxItem->valueList, nIndex);
		}
	}
	return pValue;
}

void DisposeComboBoxItem(UIComboBoxItem *comboboxItem)
{
	if (comboboxItem != NULL)
	{
		if( comboboxItem->valueList != NULL )
		{
			g_list_foreach(comboboxItem->valueList, (GFunc)mem_free, NULL );
			g_list_free_wrapper(comboboxItem->valueList);
			comboboxItem->valueList = NULL;
		}

		mem_free(comboboxItem);
	}
}
