/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */



#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "uimain.h"
#include "widgets.h"
#include "interface.h"
#include "cancelkeydlg.h"

#include "callbacks.h"
#include "support.h"
#include "id_defines.h"
#include "commandcontroller.h"
#include "value_defines.h"

#define CANCEL_KEY_CTRL_TYPE_NUM 3
#define CANCEL_KEY_CTRL_TBL_NUM 3

static int InitCancelJobKeyDlgWidgets( UIStatusWnd *wnd );
static unsigned int SetItemValue_CancelJobKeyDlgOK( const UIStatusWnd* const wnd );

CtrlTbl* PPDCtrlTbl[CTRL_LIST_MAXNUM];

static CtrlTbl ctrlTbl[CANCEL_KEY_CTRL_TBL_NUM] =
{
	{ ID_JOBCANCELSETTING_DIALOG1, LABEL_TYPE_TITLE, NULL, N_("Settings for Cancel Job Key"), NULL, 0 },
	{ ID_CTRLJOBCANCELENABLE, LABEL_TYPE_BUTTON, "CJKDlg_ErrorJob_checkbutton", N_("Allow Cancel Job Key to Be Used"), "CJKDlg_ErrorJob_checkbutton", ID1012 },
	{ -1, -1, NULL, NULL, NULL, -1 }
};

UICancelJobKeyDlg* CreateCancelJobKeyDlg(UIDialog* const parent)
{
	UICancelJobKeyDlg *pDialog;

	pDialog = (UICancelJobKeyDlg *)CreateDialog(sizeof(UICancelJobKeyDlg), parent);

	if(pDialog != NULL)
	{
		UI_DIALOG(pDialog)->window = create_CancelJobKeyDlg_dialog();
	}

	return pDialog;
}

void ShowCancelJobKeyDlg( UIStatusWnd* const wnd )
{
	int nRet = 0;

	if( wnd == NULL )
	{
		return;
	}
	if( wnd->cancelkey_dlg == NULL )
	{
		wnd->cancelkey_dlg = CreateCancelJobKeyDlg( UI_DIALOG( wnd ) );
	}

	SigDisable();
	nRet = InitCancelJobKeyDlgWidgets( wnd );
	SigEnable();

	if( nRet == 0 )
	{
		ShowDialog( (UIDialog *)wnd->cancelkey_dlg, NULL );
	}
	else
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_GET );
		if( wnd->cancelkey_dlg != NULL )
		{
			if( wnd->cancelkey_dlg->pDialogDict != NULL )
			{
				DeleteDict( wnd->cancelkey_dlg->pDialogDict );
				wnd->cancelkey_dlg->pDialogDict = NULL;
			}
			mem_free( wnd->cancelkey_dlg );
			wnd->cancelkey_dlg = NULL;
		}
	}
}

static unsigned int SetItemValue_CancelJobKeyDlgOK( const UIStatusWnd* const wnd )
{
	int i = 0;
	int nValue = 0;
	unsigned int unRet = 0;
	GtkWidget *pWindow = NULL;

	if( wnd == NULL )
	{
		return DICT_SET_RETURN_ERROR;
	}
	pWindow = wnd->cancelkey_dlg->dialog.window;

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		switch( PPDCtrlTbl[i]->dbid )
		{
		case ID1012:
			nValue = GetToggleButtonActive( pWindow, "CJKDlg_ErrorJob_checkbutton", TRUE );
			unRet |= SetItemValuetype_int( wnd->cancelkey_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, nValue );
			break;
		default:
			break;
		}
		if( (unRet & DICT_SET_RETURN_ERROR) == DICT_SET_RETURN_ERROR )
		{
			break;
		}
	}
	return unRet;
}

void CancelJobKeyDlgOK( UIStatusWnd* const wnd )
{
	int nRet = 0;
	unsigned int unRet = 0;

	if( wnd == NULL )
	{
		return;
	}

	nRet = CreateDict_SetData( wnd->cancelkey_dlg->pDialogDict );

	if( nRet == 0 )
	{
		unRet = SetItemValue_CancelJobKeyDlgOK( wnd );
		if( (unRet & DICT_SET_RETURN_ERROR) == DICT_SET_RETURN_ERROR )
		{
			nRet = -1;
		}
	}

	if( ( nRet == 0 ) && ( unRet == DICT_SET_RETURN_CHANGE ) )
	{
		nRet = CommunicatePrinterData( wnd, (UIDialog *)wnd->cancelkey_dlg, wnd->cancelkey_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	}

	HideDialog( (UIDialog *)wnd->cancelkey_dlg );

	if( nRet != 0 )
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_SET );
	}

	return;
}

static int InitCancelJobKeyDlgWidgets( UIStatusWnd* const wnd )
{
	GtkWidget *pWindow = NULL;
	GList *pGlist = NULL;
	int nValue = 1;
	int i = 0;
	int nRet = 0;
	const char* const ctrl_type[CANCEL_KEY_CTRL_TYPE_NUM] = { "CNSUIJobCancelDlg", "CNSUICtrlJobCancel", NULL };

	if( wnd == NULL )
	{
		return -1;
	}

	if( wnd->cancelkey_dlg == NULL )
	{
		return -1;
	}
	else
	{
		pWindow = wnd->cancelkey_dlg->dialog.window;
	}

	CreatePPDCtrlTbl( wnd, ctrl_type, ctrlTbl, PPDCtrlTbl );

	SetLabel_HideWidget( pWindow, PPDCtrlTbl, ctrlTbl );

	pGlist = CreateGlist_DbId( PPDCtrlTbl );

	if( wnd->cancelkey_dlg->pDialogDict != NULL )
	{
		UI_DEBUG("pDialogDict no mem_free, from Func[%s] Line[%u] \n", __func__, __LINE__);
		DeleteDict( wnd->cancelkey_dlg->pDialogDict );
	}
	wnd->cancelkey_dlg->pDialogDict = CretateDict_GetData( pGlist );
	g_list_free_wrapper( pGlist );
	pGlist = NULL;

	if( wnd->cancelkey_dlg->pDialogDict == NULL )
	{
		return -1;
	}

	nRet = CommunicatePrinterData( wnd, NULL, wnd->cancelkey_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	if( nRet != 0 )
	{
		return -1;
	}

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		switch( PPDCtrlTbl[i]->dbid )
		{
		case ID1012:
			GetItemValueType_int( wnd->cancelkey_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, &nValue );
			SetActiveCheckButton( pWindow, "CJKDlg_ErrorJob_checkbutton" , nValue, TRUE );
			break;
		default:
			break;
		}
	}
	return nRet;
}

void DisposeJobCancelKeyDlg( UIStatusWnd* const wnd )
{
	UICancelJobKeyDlg* ui_cancelkey_dlg = NULL;

	if(wnd == NULL)
	{
		return;
	}

	ui_cancelkey_dlg = wnd->cancelkey_dlg;
	if( ui_cancelkey_dlg != NULL )
	{
		if( ui_cancelkey_dlg->pDialogDict != NULL )
		{
			DeleteDict( ui_cancelkey_dlg->pDialogDict );
			ui_cancelkey_dlg->pDialogDict = NULL;
		}
		DisposeDialog( (UIDialog *)ui_cancelkey_dlg );
		wnd->cancelkey_dlg = NULL;
	}
}

