/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2015 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "uimain.h"
#include "widgets.h"
#include "interface.h"
#include "warningdisplaydlg.h"

#include "callbacks.h"
#include "support.h"
#include "id_defines.h"
#include "commandcontroller.h"
#include "value_defines.h"

static int InitWarningDisplayDlgWidgets( UIStatusWnd* const wnd );
static unsigned int SetItemValue_WarningDisplayDlgOK( const UIStatusWnd* const wnd );

CtrlTbl* PPDCtrlTbl[CTRL_LIST_MAXNUM];

static CtrlTbl ctrlTbl[] =
{
	{ ID_WARNINGDISPLAY_DIALOG1, LABEL_TYPE_TITLE, NULL,
		N_("Warning Display Settings"), NULL, 0 },

	{ ID_CTRLDISPLAYTONERLOW, LABEL_TYPE_BUTTON, "WarningDisplayDlg_DisplayTonerLow_checkbutton",
		N_("Display Cartridge Replacement Notice"), "WarningDisplayDlg_DisplayTonerLow_box", ID752 },

	{ -1, -1, NULL, NULL, NULL, -1 }
};

UIWarningDisplayDlg* CreateWarningDisplayDlg(UIDialog* const parent)
{
	UIWarningDisplayDlg *pDialog = NULL;

	pDialog = (UIWarningDisplayDlg *)CreateDialog(sizeof(UIWarningDisplayDlg), parent);
	if( pDialog != NULL )
	{
		UI_DIALOG(pDialog)->window = create_WarningDisplay_dialog();
	}
	return pDialog;
}

void ShowWarningDisplayDlg( UIStatusWnd* const wnd )
{
	int nRet = 0;

	if( wnd == NULL )
	{
		return;
	}
	if( wnd->warningdisplay_dlg == NULL )
	{
		wnd->warningdisplay_dlg = CreateWarningDisplayDlg( UI_DIALOG( wnd ) );
	}

	SigDisable();
	nRet = InitWarningDisplayDlgWidgets( wnd );
	SigEnable();

	if( nRet == 0 )
	{
		ShowDialog( (UIDialog *)wnd->warningdisplay_dlg, NULL );
	}
	else
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_GET );
		if( wnd->warningdisplay_dlg != NULL )
		{
			if( wnd->warningdisplay_dlg->pDialogDict != NULL )
			{
				DeleteDict( wnd->warningdisplay_dlg->pDialogDict );
				wnd->warningdisplay_dlg->pDialogDict = NULL;
			}
			mem_free( wnd->warningdisplay_dlg );
			wnd->warningdisplay_dlg = NULL;
		}
	}
}

static unsigned int SetItemValue_WarningDisplayDlgOK( const UIStatusWnd* const wnd )
{
	int i = 0;
	int nValue = 0;
	unsigned int unRet = 0;
	GtkWidget *pWindow = NULL;

	if( wnd == NULL )
	{
		UI_DEBUG("SetItemValue_WarningDisplayDlgOK PPDCtrlTbl[%p] pWindow[%p]\n", PPDCtrlTbl, pWindow);
		return DICT_SET_RETURN_ERROR;
	}
	pWindow = wnd->warningdisplay_dlg->dialog.window;

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		switch( PPDCtrlTbl[i]->dbid )
		{
		case ID752:
			nValue = GetToggleButtonActive( pWindow, "WarningDisplayDlg_DisplayTonerLow_checkbutton", TRUE );
			unRet |= SetItemValuetype_int( wnd->warningdisplay_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, nValue );
			UI_DEBUG("SetItemValue_WarningDisplayDlgOK unRet[%d]\n", unRet);
			break;
		default:
			break;
		}
		if( (unRet & DICT_SET_RETURN_ERROR) == DICT_SET_RETURN_ERROR )
		{
			break;
		}
	}
	return unRet;
}

void WarningDisplayDlgOK( UIStatusWnd* const wnd )
{
	int nRet = 0;
	unsigned int unRet = 0;

	if( wnd == NULL )
	{
		return;
	}
	else
	{
		nRet = CreateDict_SetData( wnd->warningdisplay_dlg->pDialogDict );
	}

	if( nRet == 0 )
	{
		unRet = SetItemValue_WarningDisplayDlgOK( wnd );
		if( (unRet & DICT_SET_RETURN_ERROR) == DICT_SET_RETURN_ERROR )
		{
			nRet = -1;
		}
	}

	if( ( nRet == 0 ) && ( unRet == DICT_SET_RETURN_CHANGE ) )
	{
		nRet = CommunicatePrinterData( wnd, (UIDialog *)wnd->warningdisplay_dlg, wnd->warningdisplay_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	}

	HideDialog( (UIDialog *)wnd->warningdisplay_dlg );

	if( nRet != 0 )
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_SET );
	}

	return;
}

static int InitWarningDisplayDlgWidgets( UIStatusWnd* const wnd )
{
	GtkWidget *pWindow = NULL;
	GList *pGlist = NULL;
	int nValue = 1;
	int i = 0;
	int nRet = 0;
	const char* const ctrl_type[] = { "CNSUIWarningDisplayDlg", "CNSUICtrlDisplayTonerLow", NULL };

	if( wnd == NULL )
	{
		return -1;
	}

	if( wnd->warningdisplay_dlg == NULL )
	{
		return -1;
	}
	else
	{
		pWindow = wnd->warningdisplay_dlg->dialog.window;
	}

	CreatePPDCtrlTbl( wnd, ctrl_type, ctrlTbl, PPDCtrlTbl );

	SetLabel_HideWidget( pWindow, PPDCtrlTbl, ctrlTbl );

	pGlist = CreateGlist_DbId( PPDCtrlTbl );

	if( wnd->warningdisplay_dlg->pDialogDict != NULL )
	{
		UI_DEBUG("pDialogDict no mem_free, from Func[%s] Line[%u] \n", __func__, __LINE__);
		DeleteDict( wnd->warningdisplay_dlg->pDialogDict );
	}
	wnd->warningdisplay_dlg->pDialogDict = CretateDict_GetData( pGlist );
	g_list_free_wrapper( pGlist );
	pGlist = NULL;

	if( wnd->warningdisplay_dlg->pDialogDict == NULL )
	{
		return -1;
	}

	nRet = CommunicatePrinterData( wnd, NULL, wnd->warningdisplay_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	if( nRet != 0 )
	{
		return -1;
	}

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		switch( PPDCtrlTbl[i]->dbid )
		{
		case ID752:
			GetItemValueType_int( wnd->warningdisplay_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, &nValue );
			SetActiveCheckButton( pWindow, "WarningDisplayDlg_DisplayTonerLow_checkbutton" , nValue, TRUE );
			break;
		default:
			break;
		}
	}

	return nRet;
}

void DisposeWarningDisplayDlg( UIStatusWnd* const wnd )
{
	UIWarningDisplayDlg* ui_dialog = NULL;

	if(wnd == NULL)
	{
		return;
	}

	ui_dialog = wnd->warningdisplay_dlg;
	if( ui_dialog != NULL )
	{
		if( ui_dialog->pDialogDict != NULL )
		{
			DeleteDict( ui_dialog->pDialogDict );
			ui_dialog->pDialogDict = NULL;
		}
		DisposeDialog( (UIDialog *)ui_dialog );
		wnd->warningdisplay_dlg = NULL;
	}
}

