﻿=================================================================================
Canon MF/LBP Network Setup Tool Version 2.31

LESEN SIE DIESES DOKUMENT SORGFÄLTIG DURCH
=================================================================================

VORSICHTSMASSNAHMEN

Beachten Sie bitte die folgenden Einschränkungen bei Verwendung dieser Software.

1. Die Software kann bis zu 10 WLAN-Zugangspunkte durch die Suche nach WLAN-Zugangspunkten erfassen. 

2. Die Software kann keine WLAN-Zugangspunkte durch die Suche nach WLAN-Zugangspunkten erfassen, wenn die WLAN-Zugangspunkte eine Stealth-Funktion verwenden. 

3. Wenn die Druckerfirmware aktualisiert wird oder sofort nachdem der Netzschalter auf EIN oder AUS gesetzt wird oder wenn der Drucker druckt, können keine Konfigurationseinstellungen mit dieser Software durchgeführt werden. 

4. Je nach Betriebsumgebung können die "Praktischen Tipps" von dieser Software nicht direkt angezeigt werden.
Befolgen Sie in diesem Fall die Meldung auf dem Bildschirm, um die "Praktischen Tipps" über den von Ihnen verwendeten Webbrowser anzuzeigen.

=================================================================================
                                                        Copyright CANON INC. 2014

