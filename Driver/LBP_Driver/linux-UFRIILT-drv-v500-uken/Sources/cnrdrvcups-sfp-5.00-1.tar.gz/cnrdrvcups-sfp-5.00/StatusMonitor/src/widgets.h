/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */



#ifndef _WIDGETS
#define	_WIDGETS

#include "dialog.h"
#include "uimain.h"

void SigInit(void);
gboolean SigEnable(void);
gboolean SigDisable(void);
int CreateStatusWidgets(UIStatusWnd *wnd);
GtkWidget* getWidget(GtkWidget *window, const char* const name);
void SetDialogTitle(GtkWidget *window, gchar *title);
void SetWidgetSensitive(GtkWidget *window, const gchar* const widgetname, gboolean value);
gchar* InsertString( const char* const basestring, const char* const insertstring, const gint nIndex );
char** SeparateString(char *pstr, char delimiter);
char* CompositionString( GList* const CompositList, const char* const strBaseString, const char* const strToken );
void CatStrWithPunctuation(GString* const gsSrcStr, const char* const pAddStr, const char* const pPunc);
void AddNewLine(char** const ppSrcStr);
GList* CreateIntGlistFromString(char * const pstr, const char delimiter);
GList* CreateGlist_ComboList( char * const * const ParamList );
GList* CreateGlist_ExceptBaseGlist(GList* const baseGlist, GList* dstGlist);
gboolean GetPPDValue_Integer( cngplpData* const pMod, const char* const pKey, int* const pValue );
char* CngplpGetValue_AddPrefix(const UIStatusWnd* const wnd, const char* const baseKeyStr);
char* CngplpGetValue_AddKeyStr(const UIStatusWnd* const wnd, const char* const baseKeyStr, const char* const addKeyStr);
char* getMessageFromPPDKey(const UIStatusWnd* const wnd, const char* const ppdKey, const char* const appendKey);

GList *CreateListFromPPDKey(cngplpData *pModData, const char *pPPDKey);
gboolean isCrgTypeDevice(const UIStatusWnd* const wnd);
char* crgTypeList(const UIStatusWnd* const wnd);
char* crgTypeDefault(const UIStatusWnd* const wnd);
gboolean isEquipmentEnable(const UIStatusWnd* const wnd, const char* const pEquipment);
gboolean existCrgTypeInEquipment(const UIStatusWnd* const wnd);
void getEquipmentCrgTypeFromCNSUICrgTypeList(const UIStatusWnd* const wnd, char** outCrgTypeStr);
void createCrgTypeXStr(const UIStatusWnd* const wnd, const char* const ppdKey, const char* const appendKey, GString *outGStr);
gboolean CheckControlEnabled(CtrlTbl* const * const pPPDCtrlTbl, const int ctrlid);

void ShowWidget(GtkWidget *window, const gchar* const widget_name);
void ChangeHideMainWindow(UIStatusWnd* const wnd);
void HideWidget(GtkWidget *window, const gchar* const widget_name);
void HideMonitor(UIStatusWnd *wnd);
void SetTextToLabel(GtkWidget *window, const gchar *label_name, const gchar *text);
const gchar* GetStrLabel(GtkWidget* const window, const gchar* const label_name);
gboolean CompareStrLabel(GtkWidget* const window, const gchar* const label_name, const gchar* const compareStr);
void SetTextToTextView(GtkWidget* const window, const gchar* const text_name, const gchar* const setString);
gchar* GetStrTextWidget(GtkWidget* const window, const gchar* const text_name);
gboolean CompareStrTextWidget(GtkWidget* const window, const gchar* const text_name, const gchar* const compareStr);

void SetSpinButtonFloat(GtkWidget *window, const gchar *spinbutton_name, gfloat value);
gint GetSpinButtonValue(GtkWidget *window, const gchar *spinbutton_name, int value);
gint GetCurrComboBoxIndex(GtkWidget * const window, const gchar * const combobox_name);
void SetCurrComboBoxIndex(GtkWidget * const window, const gchar * const combobox_name, const gint nIndex);
void SetGListToComboBox(GtkWidget *const window, const gchar * const combobox_name, GList * const glist);
gint GetTextIndexFromComboBox(GtkWidget * const window, const gchar * const combobox_name, const gchar * const gtext);
gboolean SetCurrComboBoxText(GtkWidget * const window, const gchar * const combobox_name, const gchar * const gtext);
gchar* GetCurrComboBoxText(GtkWidget * const window, const gchar * const combobox_name);

void UpdateMainWindow(UIStatusWnd* const wnd, const char* const mainMessage, const char* const subMessage);
void SetJobMenuSensitive(UIStatusWnd* const wnd);
void SetOptionMenuSensitive(UIStatusWnd* const wnd);
void SetEnableAllOptionMenu(UIStatusWnd* const wnd, const gboolean isEnable);
void SetEnableAllMenu(UIStatusWnd* const wnd, const gboolean isEnable);

void SetButtonLabel(GtkWidget *window, const gchar *button_name, gchar *text);
gboolean GetToggleButtonActive(GtkWidget *window, const gchar *button_name, gboolean bInvert);
void SetActiveCheckButton(GtkWidget *window, const gchar *button_name, gboolean on, gboolean bInvert);
void SetTextToLabel(GtkWidget *window, const gchar *label_name, const gchar *text);

void SetBtnWidgetSensitive(GtkWidget* const window, const gboolean resume, const gboolean cancel);
void SetJobWidgetSensitive(GtkWidget* const window, const gboolean resume, const gboolean cancel);
#endif

