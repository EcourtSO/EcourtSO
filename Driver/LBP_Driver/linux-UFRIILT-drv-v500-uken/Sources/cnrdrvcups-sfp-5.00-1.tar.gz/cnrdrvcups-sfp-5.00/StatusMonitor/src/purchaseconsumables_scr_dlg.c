/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2015 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "uimain.h"
#include "widgets.h"
#include "interface.h"
#include "purchaseconsumables_scr_dlg.h"

#include "callbacks.h"
#include "support.h"
#include "id_defines.h"
#include "commandcontroller.h"
#include "value_defines.h"
#include "key_defines.h"


CtrlTbl* PPDCtrlTbl[CTRL_LIST_MAXNUM];

#define	COMMANDLINE_BUFFER_SIZE			2048
#define	SHORT_STRING_BUFFER_SIZE		256
#define	REGTABLE_INDEX_INIT_VALUE		-1
#define	DEVICENAME_KEY					"CNSUIPC_DeviceName"
#define	DEVICENAME_KEY_WITHOUT_CUSUI	"PC_DeviceName"
#define	CPCA_EXP_AUSTRIA				"1"
#define	CPCA_EXP_BELARUS				"2"
#define	CPCA_EXP_BELGIUM				"3"
#define	CPCA_EXP_CZECH					"4"
#define	CPCA_EXP_DENMARK				"5"
#define	CPCA_EXP_EGYPT					"6"
#define	CPCA_EXP_FINLAND				"7"
#define	CPCA_EXP_FRANCE					"8"
#define	CPCA_EXP_GERMANY				"9"
#define	CPCA_EXP_GREECE					"10"
#define	CPCA_EXP_HUNGRY					"11"
#define	CPCA_EXP_IRELAND				"12"
#define	CPCA_EXP_ITALY					"13"
#define	CPCA_EXP_JORDAN					"14"
#define	CPCA_EXP_LUXEM					"15"
#define	CPCA_EXP_NETHERLAND				"16"
#define	CPCA_EXP_NORWAY					"17"
#define	CPCA_EXP_POLAND					"18"
#define	CPCA_EXP_PORTUGAL				"19"
#define	CPCA_EXP_RUSSIA					"20"
#define	CPCA_EXP_SAUDI					"21"
#define	CPCA_EXP_SLOVENIA				"22"
#define	CPCA_EXP_S_AFRICA				"23"
#define	CPCA_EXP_SPAIN					"24"
#define	CPCA_EXP_SWEDEN					"25"
#define	CPCA_EXP_SWISS					"26"
#define	CPCA_EXP_UKRAINA				"27"
#define	CPCA_EXP_UK						"28"
#define	CPCA_EXP_OTHER_EUROPE			"29"
#define	CPCA_EXP_AUSTRALIA				"30"
#define	CPCA_EXP_NZ						"31"
#define	CPCA_EXP_OTHER_OCEANIA			"32"
#define	CPCA_EXP_HONGKONG				"33"
#define	CPCA_EXP_SINGAPORE				"34"
#define	CPCA_EXP_MALAYSIA				"35"
#define	CPCA_EXP_VIETNAM				"36"
#define	CPCA_EXP_ARGENTINA				"37"
#define	CPCA_EXP_OTHER_ASIA				"38"
#define	CPCA_EXP_OTHER_LATIN			"39"
#define	CPCA_EXP_USA					"40"
#define	CPCA_EXP_CANADA					"41"
#define	CPCA_EXP_BRAZIL					"42"
#define	CPCA_EXP_MEXICO					"43"
#define	CPCA_EXP_OTHER_USA				"44"
#define	CPCA_EXP_NO_SETTING				"45"
#define	CPCA_EXP_JAPAN					"46"
#define	CPCA_EXP_KOREA					"47"
#define	CPCA_EXP_CHINA					"48"
#define	CPCA_EXP_TAIWAN					"49"
#define	CPCA_EXP_THAILAND				"50"
#define	CPCA_EXP_INDIA					"51"
#define	CPCA_EXP_PHILIPPINES			"52"
#define	CPCA_EXP_TERMINATE				"-1"

#define	CNM_RES_AUSTRIA					"AUSTRIA"
#define	CNM_RES_BELARUS					"BELARUS"
#define	CNM_RES_BELGIUM					"BELGIUM"
#define	CNM_RES_CZECH					"CZECH"
#define	CNM_RES_DENMARK					"DENMARK"
#define	CNM_RES_EGYPT					"EGYPT"
#define	CNM_RES_FINLAND					"FINLAND"
#define	CNM_RES_FRANCE					"FRANCE"
#define	CNM_RES_GERMANY					"GERMANY"
#define	CNM_RES_GREECE					"GREECE"
#define	CNM_RES_HUNGARY					"HUNGARY"
#define	CNM_RES_IRELAND					"IRELAND"
#define	CNM_RES_ITALY					"ITALY"
#define	CNM_RES_JORDAN					"JORDAN"
#define	CNM_RES_LUXEMBOURG				"LUXEMBOURG"
#define	CNM_RES_NETHERLANDS				"N_L_"
#define	CNM_RES_NORWAY					"NORWAY"
#define	CNM_RES_POLAND					"POLAND"
#define	CNM_RES_PORTUGAL 				"PORTUGAL"
#define	CNM_RES_RUSSIA					"RUSSIA"
#define	CNM_RES_SAUDI_ARABIA 			"SAUDIARAB"
#define	CNM_RES_SLOVENIA 				"SLOVENIA"
#define	CNM_RES_SOUTH_AFRICA 			"SAF"
#define	CNM_RES_SPAIN					"SPAIN"
#define	CNM_RES_SWEDEN					"SWEDEN"
#define	CNM_RES_SWITZERLAND				"SWISS"
#define	CNM_RES_UKRAINE					"UKRAINE"
#define	CNM_RES_UNITED_KINGDOM			"U_K_"
#define	CNM_RES_OTHERS_EUROPE			"OTHER_EU"
#define	CNM_RES_AUSTRALIA				"AUSTRALIA"
#define	CNM_RES_NZ						"NZ"
#define	CNM_RES_OTHER_OCEANIA			"OTHER_OCEANIA"
#define	CNM_RES_HONGKONG				"HONGKONG"
#define	CNM_RES_SINGAPORE				"SINGAPORE"
#define	CNM_RES_MALAYSIA				"MALAYSIA"
#define	CNM_RES_VIETNAM					"VIETNAM"
#define	CNM_RES_ARGENTINA				"ARG"
#define	CNM_RES_OTHERS_ASIA				"OTHER_ASIA"
#define	CNM_RES_OTHERS_LATIN			"OTHER_L"
#define	CNM_RES_USA 					"USA"
#define	CNM_RES_CANADA					"CANADA"
#define	CNM_RES_BRAZIL					"BRA"
#define	CNM_RES_MEXICO					"MEXICO"
#define	CNM_RES_OTHERS_USA				"OTHER_USA"
#define	CNM_RES_NO_SETTING				"NO SETTING"
#define	CNM_RES_JAPAN 					"JAPAN"
#define	CNM_RES_KOREA					"KOREA"
#define	CNM_RES_CHINA					"CHINA"
#define	CNM_RES_TAIWAN					"TAIWAN"
#define	CNM_RES_THAILAND				"THAI"
#define	CNM_RES_INDIA					"INDIA"
#define	CNM_RES_PHILIPPINES				"PHILIP"

#define	REG_NAME_AUSTRIA				N_("Austria")
#define	REG_NAME_BELARUS				N_("Belarus")
#define	REG_NAME_BELGIUM				N_("Belgium")
#define	REG_NAME_CZECH					N_("Czech Republic")
#define	REG_NAME_DENMARK				N_("Denmark")
#define	REG_NAME_EGYPT					N_("Egypt")
#define	REG_NAME_FINLAND				N_("Finland")
#define	REG_NAME_FRANCE 				N_("France")
#define	REG_NAME_GERMANY				N_("Germany")
#define	REG_NAME_GREECE 				N_("Greece")
#define	REG_NAME_HUNGARY				N_("Hungary")
#define	REG_NAME_IRELAND				N_("Ireland")
#define	REG_NAME_ITALY					N_("Italy")
#define	REG_NAME_JORDAN 				N_("Jordan")
#define	REG_NAME_LUXEMBOURG 			N_("Luxembourg")
#define	REG_NAME_NETHERLANDS			N_("Netherlands")
#define	REG_NAME_NORWAY 				N_("Norway")
#define	REG_NAME_POLAND 				N_("Poland")
#define	REG_NAME_PORTUGAL				N_("Portugal")
#define	REG_NAME_RUSSIA 				N_("Russia")
#define	REG_NAME_SAUDI_ARABIA			N_("Saudi Arabia")
#define	REG_NAME_SLOVENIA				N_("Slovenia")
#define	REG_NAME_SOUTH_AFRICA			N_("South Africa")
#define	REG_NAME_SPAIN					N_("Spain")
#define	REG_NAME_SWEDEN 				N_("Sweden")
#define	REG_NAME_SWITZERLAND			N_("Switzerland")
#define	REG_NAME_UKRAINE				N_("Ukraine")
#define	REG_NAME_UNITED_KINGDOM			N_("United Kingdom")
#define	REG_NAME_OTHERS_EUROPE 			N_("Others")
#define	REG_NAME_AUSTRALIA				N_("Australia")
#define	REG_NAME_NZ						N_("New Zealand")
#define	REG_NAME_OTHER_OCEANIA			N_("Others")
#define	REG_NAME_HONGKONG				N_("Hong Kong")
#define	REG_NAME_SINGAPORE				N_("Singapore")
#define	REG_NAME_MALAYSIA 				N_("Malaysia")
#define	REG_NAME_VIETNAM				N_("Vietnam")
#define	REG_NAME_ARGENTINA				N_("Argentina")
#define	REG_NAME_OTHERS_ASIA			N_("Others (Asia)")
#define	REG_NAME_OTHERS_LATIN 			N_("Others (Latin America)")
#define	REG_NAME_USA					N_("USA")
#define	REG_NAME_CANADA					N_("Canada")
#define	REG_NAME_BRAZIL					N_("Brazil")
#define	REG_NAME_MEXICO					N_("Mexico")
#define	REG_NAME_OTHERS_USA				N_("Others")
#define	REG_NAME_NO_SETTING				N_("No Setting")
#define	REG_NAME_JAPAN					N_("Japan")
#define	REG_NAME_KOREA					N_("Korea")
#define	REG_NAME_CHINA					N_("China")
#define	REG_NAME_TAIWAN					N_("Taiwan")
#define	REG_NAME_THAILAND				N_("Thailand")
#define	REG_NAME_INDIA					N_("India")
#define	REG_NAME_PHILIPPINES			N_("Philippines")

#define	PURCHASE_BROWSER_START_COMMAND	"xdg-open \"http://pdisp01.c-wss.com/myprinter/rdindex?CNM_FNC=%s&CNM_DRC=%s&CNM_RES=%s&CNM_STL=%s&CNM_OSV=%s&CNM_PSC=%s&CNM_DEV=%s\" &"
#define	PURCHASE_FUNCIDENTIFICATION 	"OIP_SFP"
#define	PURCHASE_DEVICEDESTINATIONCODE	"zzzzz"
#define	PURCHASE_SYSTEMLOCALE			"zzzzz"
#define	PURCHASE_OSVERSION				"zzzzz"
#define	PURCHASE_STATUSID				"zzzzz"

static regGroup regGroupTable[] = {
	{CPCA_EXP_AUSTRIA,		CNM_RES_AUSTRIA, 		REG_NAME_AUSTRIA},
	{CPCA_EXP_BELARUS,		CNM_RES_BELARUS, 		REG_NAME_BELARUS},
	{CPCA_EXP_BELGIUM,		CNM_RES_BELGIUM, 		REG_NAME_BELGIUM},
	{CPCA_EXP_CZECH,		CNM_RES_CZECH,			REG_NAME_CZECH},
	{CPCA_EXP_DENMARK,		CNM_RES_DENMARK, 		REG_NAME_DENMARK},
	{CPCA_EXP_EGYPT,		CNM_RES_EGYPT,			REG_NAME_EGYPT},
	{CPCA_EXP_FINLAND,		CNM_RES_FINLAND, 		REG_NAME_FINLAND},
	{CPCA_EXP_FRANCE,		CNM_RES_FRANCE,			REG_NAME_FRANCE},
	{CPCA_EXP_GERMANY,		CNM_RES_GERMANY, 		REG_NAME_GERMANY},
	{CPCA_EXP_GREECE,		CNM_RES_GREECE,			REG_NAME_GREECE},
	{CPCA_EXP_HUNGRY,		CNM_RES_HUNGARY, 		REG_NAME_HUNGARY},
	{CPCA_EXP_IRELAND,		CNM_RES_IRELAND, 		REG_NAME_IRELAND},
	{CPCA_EXP_ITALY,		CNM_RES_ITALY,			REG_NAME_ITALY},
	{CPCA_EXP_JORDAN,		CNM_RES_JORDAN,			REG_NAME_JORDAN},
	{CPCA_EXP_LUXEM,		CNM_RES_LUXEMBOURG,		REG_NAME_LUXEMBOURG},
	{CPCA_EXP_NETHERLAND,	CNM_RES_NETHERLANDS, 	REG_NAME_NETHERLANDS},
	{CPCA_EXP_NORWAY,		CNM_RES_NORWAY,			REG_NAME_NORWAY},
	{CPCA_EXP_POLAND,		CNM_RES_POLAND,			REG_NAME_POLAND},
	{CPCA_EXP_PORTUGAL,		CNM_RES_PORTUGAL,		REG_NAME_PORTUGAL},
	{CPCA_EXP_RUSSIA,		CNM_RES_RUSSIA,			REG_NAME_RUSSIA},
	{CPCA_EXP_SAUDI,		CNM_RES_SAUDI_ARABIA,	REG_NAME_SAUDI_ARABIA},
	{CPCA_EXP_SLOVENIA,		CNM_RES_SLOVENIA,		REG_NAME_SLOVENIA},
	{CPCA_EXP_S_AFRICA,		CNM_RES_SOUTH_AFRICA,	REG_NAME_SOUTH_AFRICA},
	{CPCA_EXP_SPAIN,		CNM_RES_SPAIN,			REG_NAME_SPAIN},
	{CPCA_EXP_SWEDEN,		CNM_RES_SWEDEN,			REG_NAME_SWEDEN},
	{CPCA_EXP_SWISS,		CNM_RES_SWITZERLAND, 	REG_NAME_SWITZERLAND},
	{CPCA_EXP_UKRAINA,		CNM_RES_UKRAINE, 		REG_NAME_UKRAINE},
	{CPCA_EXP_UK,			CNM_RES_UNITED_KINGDOM,	REG_NAME_UNITED_KINGDOM},
	{CPCA_EXP_OTHER_EUROPE,	CNM_RES_OTHERS_EUROPE,	REG_NAME_OTHERS_EUROPE},
	{CPCA_EXP_AUSTRALIA,	CNM_RES_AUSTRALIA,		REG_NAME_AUSTRALIA},
	{CPCA_EXP_NZ,			CNM_RES_NZ,				REG_NAME_NZ},
	{CPCA_EXP_OTHER_OCEANIA,CNM_RES_OTHER_OCEANIA,	REG_NAME_OTHER_OCEANIA},
	{CPCA_EXP_HONGKONG,		CNM_RES_HONGKONG,		REG_NAME_HONGKONG},
	{CPCA_EXP_SINGAPORE,	CNM_RES_SINGAPORE,		REG_NAME_SINGAPORE},
	{CPCA_EXP_MALAYSIA,		CNM_RES_MALAYSIA,		REG_NAME_MALAYSIA},
	{CPCA_EXP_VIETNAM,		CNM_RES_VIETNAM,		REG_NAME_VIETNAM},
	{CPCA_EXP_ARGENTINA,	CNM_RES_ARGENTINA,		REG_NAME_ARGENTINA},
	{CPCA_EXP_OTHER_ASIA,	CNM_RES_OTHERS_ASIA,	REG_NAME_OTHERS_ASIA},
	{CPCA_EXP_OTHER_LATIN,	CNM_RES_OTHERS_LATIN,	REG_NAME_OTHERS_LATIN},
	{CPCA_EXP_USA,			CNM_RES_USA,			REG_NAME_USA},
	{CPCA_EXP_CANADA,		CNM_RES_CANADA, 		REG_NAME_CANADA},
	{CPCA_EXP_BRAZIL,		CNM_RES_BRAZIL, 		REG_NAME_BRAZIL},
	{CPCA_EXP_MEXICO,		CNM_RES_MEXICO, 		REG_NAME_MEXICO},
	{CPCA_EXP_OTHER_USA,	CNM_RES_OTHERS_USA, 	REG_NAME_OTHERS_USA},
	{CPCA_EXP_NO_SETTING,	CNM_RES_NO_SETTING,		REG_NAME_NO_SETTING},
	{CPCA_EXP_JAPAN,		CNM_RES_JAPAN,			REG_NAME_JAPAN},
	{CPCA_EXP_KOREA,		CNM_RES_KOREA,			REG_NAME_KOREA},
	{CPCA_EXP_CHINA,		CNM_RES_CHINA,			REG_NAME_CHINA},
	{CPCA_EXP_TAIWAN,		CNM_RES_TAIWAN,			REG_NAME_TAIWAN},
	{CPCA_EXP_THAILAND,		CNM_RES_THAILAND,		REG_NAME_THAILAND},
	{CPCA_EXP_INDIA,		CNM_RES_INDIA, 			REG_NAME_INDIA},
	{CPCA_EXP_PHILIPPINES,	CNM_RES_PHILIPPINES,	REG_NAME_PHILIPPINES},
	{CPCA_EXP_TERMINATE,	NULL,					NULL}
};

static	const char*	regGroupKey_Asia = "CNSUIPCCR_Asia";
static	const char*	regGroupKey_China = "CNSUIPCCR_China";
static	const char*	regGroupKey_Europe = "CNSUIPCCR_Europe";
static	const char*	regGroupKey_NorthAmerica = "CNSUIPCCR_NorthAmerica";
static CtrlTbl ctrlTbl[] =
{
	{ ID_PC_SCR_DIALOG1,			LABEL_TYPE_TITLE,	NULL,					N_("Select Country/Region"),	NULL,						0},
	{ ID_CTRLPC_SCR_DIALOG_LABEL,	LABEL_TYPE_TEXT,	"pc_scr_dialog_label",	N_("Country/Region:"),			"pc_scr_dialog_upper_hbox",	ID2042},
	{ -1,							-1,					NULL,					NULL,							NULL,						-1}
};

static	int				InitPurchaseConsumablesDlgWidgets(UIStatusWnd* const wnd);
static	const char*		GetRegGroupKey(UIStatusWnd* const wnd);
static	unsigned int	SetItemValue_PurchaseConsumables_scr_dlgOK(const UIStatusWnd* const wnd, int*);

UIPurchaseConsumables_scr_dlg* CreatePurchaseConsumables_scr_dlg(UIDialog* const parent)
{
	UIPurchaseConsumables_scr_dlg*	pDialog = NULL;

	pDialog = (UIPurchaseConsumables_scr_dlg*)CreateDialog(sizeof(UIPurchaseConsumables_scr_dlg), parent);
	if( pDialog != NULL )
	{
		UI_DIALOG(pDialog)->window = create_PurchaseConsumables_scr_dialog();
	}
	return pDialog;
}

void ShowPurchaseConsumables_scr_dlg(UIStatusWnd* const wnd)
{
	int nRet = 0;

	if( wnd == NULL )
	{
		return;
	}
	if( wnd->purchaseconsumables_scr_dlg == NULL )
	{
		wnd->purchaseconsumables_scr_dlg = CreatePurchaseConsumables_scr_dlg(UI_DIALOG(wnd));
	}

	SigDisable();
	nRet = InitPurchaseConsumablesDlgWidgets(wnd);
	SigEnable();

	if( nRet == 0 )
	{
		ShowDialog((UIDialog*)wnd->purchaseconsumables_scr_dlg, NULL);
	}
	else
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_GET );
		if( wnd->purchaseconsumables_scr_dlg != NULL )
		{
			if( wnd->purchaseconsumables_scr_dlg->pDialogDict != NULL )
			{
				DeleteDict(wnd->purchaseconsumables_scr_dlg->pDialogDict);
				wnd->purchaseconsumables_scr_dlg->pDialogDict = NULL;
			}
			mem_free( wnd->purchaseconsumables_scr_dlg );
			wnd->purchaseconsumables_scr_dlg = NULL;
		}
	}
}

static unsigned int SetItemValue_PurchaseConsumables_scr_dlgOK(const UIStatusWnd* const wnd, int* pRegTableIndex)
{
	int 			i = 0;
	unsigned int	unRet = 0;
	int				regTableIndex = REGTABLE_INDEX_INIT_VALUE;
	if( ( wnd == NULL ) || ( pRegTableIndex == NULL ) )
	{
		UI_DEBUG("SetItemValue_PurchaseConsumables_scr_dlgOK PPDCtrlTbl[%p] pWindow[%p]\n", PPDCtrlTbl, wnd->purchaseconsumables_scr_dlg->dialog.window);
		return DICT_SET_RETURN_ERROR;
	}

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		switch( PPDCtrlTbl[i]->dbid )
		{
		case ID2042:
			{
				const char* pValue = NULL;

				pValue = GetComboBoxSelectedValue(wnd->purchaseconsumables_scr_dlg->pCR_ComboBoxItem);
				if( pValue != NULL )
				{
					int	nVale = atoi(pValue);
					regTableIndex = nVale - 1;
					unRet |= SetItemValuetype_int(wnd->purchaseconsumables_scr_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, nVale);
					UI_DEBUG("SetItemValue_PurchaseConsumables_scr_dlgOK unRet[%d]\n", unRet);
				}
			}
			break;
		default:
			break;
		}
		if( ( unRet & DICT_SET_RETURN_ERROR ) == DICT_SET_RETURN_ERROR )
		{
			break;
		}
	}
	if( regTableIndex != REGTABLE_INDEX_INIT_VALUE )
	{
		*pRegTableIndex = regTableIndex;
	}

	return unRet;
}

void PurchaseConsumables_scr_dlgOK(UIStatusWnd* const wnd)
{
	int				nRet = 0;
	int				regTableIndex = REGTABLE_INDEX_INIT_VALUE;
	unsigned int	unRet = 0;

	if( wnd == NULL )
	{
		return;
	}
	else
	{
		nRet = CreateDict_SetData(wnd->purchaseconsumables_scr_dlg->pDialogDict);
	}

	if( nRet == 0 )
	{
		unRet = SetItemValue_PurchaseConsumables_scr_dlgOK(wnd, &regTableIndex);
		if( ( unRet & DICT_SET_RETURN_ERROR ) == DICT_SET_RETURN_ERROR )
		{
			nRet = -1;
		}
	}

	if( nRet == 0 )
	{
		nRet =  CommunicatePrinterData(wnd, (UIDialog*)wnd->purchaseconsumables_scr_dlg, wnd->purchaseconsumables_scr_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE);
	}

	HideDialog((UIDialog*)wnd->purchaseconsumables_scr_dlg);

	if( nRet == 0 )
	{
		char	commandline[COMMANDLINE_BUFFER_SIZE] = {0};


		GString *gsExtraStr = NULL;
		gsExtraStr = g_string_new_wrapper(NULL, __FILE__, __LINE__);
		createCrgTypeXStr(wnd, DEVICENAME_KEY_WITHOUT_CUSUI, NULL, gsExtraStr);

		GString *gsPpdKey = NULL;
		gsPpdKey = g_string_new_wrapper(DEVICENAME_KEY, __FILE__, __LINE__);
		g_string_append(gsPpdKey, gsExtraStr->str);

		char*	pPPDValue = cngplpGetValue_Wrapper(wnd->pModData, gsPpdKey->str);
		g_string_free_wrapper(gsPpdKey, TRUE);
		g_string_free_wrapper(gsExtraStr, TRUE);

		if( ( pPPDValue != NULL ) && ( regTableIndex != REGTABLE_INDEX_INIT_VALUE ) )
		{
			snprintf(
				commandline,
				sizeof(commandline) - 1,
				(const char*)PURCHASE_BROWSER_START_COMMAND,
				PURCHASE_FUNCIDENTIFICATION,
				PURCHASE_DEVICEDESTINATIONCODE,
				regGroupTable[regTableIndex].regRes,
				PURCHASE_SYSTEMLOCALE,
				PURCHASE_OSVERSION,
				PURCHASE_STATUSID,
				pPPDValue
			);
			mem_free(pPPDValue);
			pPPDValue = NULL;
			system(commandline);
		}
	}
	else
	{
		ShowMsgDlg(wnd, ID_COMMUNICATION_ERR_SET);
	}

	return;
}

static const char*	GetRegGroupKey(UIStatusWnd* const wnd)
{
	const char*	pCRGroupKey = NULL;

	EnterCriticalSection(&g_StatusSection);
	{
		const char*	pCRGroup = GetAreaInfo(wnd);

		if( pCRGroup != NULL )
		{
			if( strcmp(pCRGroup, AREA_INFO_ASIA) == 0 )
			{
				pCRGroupKey = regGroupKey_Asia;
			}
			else if( strcmp(pCRGroup, AREA_INFO_CHINA) == 0 )
			{
				pCRGroupKey = regGroupKey_China;
			}
			else if( strcmp(pCRGroup, AREA_INFO_EU) == 0 )
			{
				pCRGroupKey = regGroupKey_Europe;
			}
			else if( strcmp(pCRGroup, AREA_INFO_NORTH_AMERICA) == 0 )
			{
				pCRGroupKey = regGroupKey_NorthAmerica;
			}
		}
	}
	LeaveCriticalSection(&g_StatusSection);

	return pCRGroupKey;
}

static int InitPurchaseConsumablesDlgWidgets(UIStatusWnd* const wnd)
{
	const char* const ctrl_type[] = { "CNSUIPC_scr_dialog", "CNSUICtrlPC_scr_label", NULL };
	int			i = 0;
	int			nRet = -1;

	if( wnd == NULL )
	{
		return nRet;
	}

	if( wnd->purchaseconsumables_scr_dlg != NULL )
	{
		GList*		pGlist = NULL;
		CreatePPDCtrlTbl(wnd, ctrl_type, ctrlTbl, PPDCtrlTbl);
		SetLabel_HideWidget(wnd->purchaseconsumables_scr_dlg->dialog.window, PPDCtrlTbl, ctrlTbl);
		if( wnd->purchaseconsumables_scr_dlg->pDialogDict != NULL )
		{
			DeleteDict(wnd->purchaseconsumables_scr_dlg->pDialogDict);
		}
		pGlist = CreateGlist_DbId(PPDCtrlTbl);
		if( pGlist != NULL )
		{
			wnd->purchaseconsumables_scr_dlg->pDialogDict = CretateDict_GetData(pGlist);
			if( wnd->purchaseconsumables_scr_dlg->pDialogDict != NULL )
			{
				nRet = CommunicatePrinterData(wnd, NULL, wnd->purchaseconsumables_scr_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE);
			}
			else
			{
				nRet = -1;
			}
			g_list_free_wrapper( pGlist );
			pGlist = NULL;
		}
	}

	if( nRet == 0 )
	{
		for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
		{
			switch( PPDCtrlTbl[i]->dbid )
			{
			case ID2042:
				{
					ComboBoxContent*	country_region_contents = NULL;
					const char*			pRegGroupKey = NULL;
					int					combo_item_count = 0;
					if( wnd->purchaseconsumables_scr_dlg->pCR_ComboBoxItem != NULL )
					{
						DisposeComboBoxItem(wnd->purchaseconsumables_scr_dlg->pCR_ComboBoxItem);
						wnd->purchaseconsumables_scr_dlg->pCR_ComboBoxItem = NULL;
					}
					pRegGroupKey = GetRegGroupKey(wnd);
					if( pRegGroupKey != NULL )
					{
						GList*	regNumList = CreateListFromPPDKey(wnd->pModData, pRegGroupKey);
						if( regNumList != NULL )
						{
							country_region_contents = mem_alloc((sizeof(ComboBoxContent) * g_list_length(regNumList)), NULL, 0);
							if( country_region_contents != NULL )
							{
								int		tbl_index = 0;
								for( tbl_index = 0; ( strcmp(regGroupTable[tbl_index].regNum, CPCA_EXP_TERMINATE) != 0 ); tbl_index++ )
								{
									if( g_list_find_custom(regNumList, regGroupTable[tbl_index].regNum, (GCompareFunc)strcmp) != NULL )
									{
										country_region_contents[combo_item_count].pMessageID = regGroupTable[tbl_index].regName;
										country_region_contents[combo_item_count].pValue = regGroupTable[tbl_index].regNum;
										combo_item_count++;
									}
								}
							}
							g_list_foreach(regNumList, (GFunc)mem_free, NULL);
							g_list_free_wrapper(regNumList);
							regNumList = NULL;
						}
					}
					if( combo_item_count != 0 )
					{
						int			nValue = -1;
						wnd->purchaseconsumables_scr_dlg->pCR_ComboBoxItem =
							CreateComboBoxItem(
								wnd->purchaseconsumables_scr_dlg->dialog.window,
								wnd->pModData,
								pRegGroupKey,
								"pc_scr_dialog_combobox",
								country_region_contents
							);
						SetWidgetSensitive(wnd->purchaseconsumables_scr_dlg->dialog.window, "pc_scr_dialog_ok_button", TRUE);
						GetItemValueType_int(wnd->purchaseconsumables_scr_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, &nValue);
						if( nValue < 0 )
						{
							nRet = -1;
						}
						else
						{
							char value[SHORT_STRING_BUFFER_SIZE] = { 0 };
							snprintf(value, sizeof(value) - 1, "%d", nValue);
							SetComboBoxSelectedValue(wnd->purchaseconsumables_scr_dlg->pCR_ComboBoxItem, value);
						}
					}
					if( country_region_contents != NULL )
					{
						mem_free(country_region_contents);
						country_region_contents = NULL;
					}
				}
				break;
			default:
				break;
			}
		}
	}

	return nRet;
}

void DisposePurchaseConsumables_scr_dlg(UIStatusWnd* const wnd)
{
	UIPurchaseConsumables_scr_dlg* ui_dialog = NULL;

	if( wnd == NULL )
	{
		return;
	}

	ui_dialog = wnd->purchaseconsumables_scr_dlg;
	if( ui_dialog != NULL )
	{
		if( ui_dialog->pCR_ComboBoxItem != NULL )
		{
			DisposeComboBoxItem(ui_dialog->pCR_ComboBoxItem);
			ui_dialog->pCR_ComboBoxItem = NULL;
		}

		if( ui_dialog->pDialogDict != NULL )
		{
			DeleteDict(ui_dialog->pDialogDict);
			ui_dialog->pDialogDict = NULL;
		}

		DisposeDialog((UIDialog*)ui_dialog);
		wnd->purchaseconsumables_scr_dlg = NULL;
	}
}

