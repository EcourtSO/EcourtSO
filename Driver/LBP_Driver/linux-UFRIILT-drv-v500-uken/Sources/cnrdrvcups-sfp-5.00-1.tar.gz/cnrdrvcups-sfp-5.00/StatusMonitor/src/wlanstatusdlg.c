/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */



#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "uimain.h"
#include "widgets.h"
#include "interface.h"
#include "wlanstatusdlg.h"

#include "callbacks.h"
#include "support.h"
#include "id_defines.h"
#include "commandcontroller.h"
#include "value_defines.h"
#include "key_defines.h"



#define WLAN_STATUS_CTRL_TYPE_NUM 3
#define WLAN_STATUS_CTRL_TBL_NUM 3

CtrlTbl* PPDCtrlTbl[CTRL_LIST_MAXNUM];

static int InitWLANStatusDlgWidgets( UIStatusWnd* const wnd );

static CtrlTbl ctrlTbl[WLAN_STATUS_CTRL_TBL_NUM] =
{
	{ ID_WLANSTATUS_DIALOG1, LABEL_TYPE_TITLE, NULL, N_("Wireless LAN Status"), NULL, 0 },
	{ ID_CTRLWLANSTATUS, LABEL_TYPE_TEXT, "WLANStatusDlg_Status_label", N_("Wireless LAN Status:"), "WLANStatusDlg_Status_label", ID120764 },
	{ -1, -1, NULL, NULL, NULL, -1 }
};

UIWLANStatusDlg* CreateWLANStatusDlg(UIDialog* const parent)
{
	UIWLANStatusDlg *pDialog;

	pDialog = (UIWLANStatusDlg *)CreateDialog(sizeof(UIWLANStatusDlg), parent);
	if( pDialog != NULL )
	{
		UI_DIALOG(pDialog)->window = create_WLanStatus_dialog();
	}
	return pDialog;
}

void ShowWLANStatusDlg( UIStatusWnd* const wnd )
{
	int nRet = 0;

	if( wnd == NULL )
	{
		return;
	}
	if( wnd->wlanstatus_dlg == NULL )
	{
		wnd->wlanstatus_dlg = CreateWLANStatusDlg( UI_DIALOG( wnd ) );
	}

	SigDisable();
	nRet = InitWLANStatusDlgWidgets( wnd );
	SigEnable();

	if( nRet == 0 )
	{
		ShowDialog( (UIDialog *)wnd->wlanstatus_dlg, NULL );
	}
	else
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_GET );
		if( wnd->wlanstatus_dlg != NULL )
		{
			if( wnd->wlanstatus_dlg->pDialogDict != NULL )
			{
				DeleteDict( wnd->wlanstatus_dlg->pDialogDict );
				wnd->wlanstatus_dlg->pDialogDict = NULL;
			}
			mem_free( wnd->wlanstatus_dlg );
			wnd->wlanstatus_dlg = NULL;
		}
	}
}

static int InitWLANStatusDlgWidgets( UIStatusWnd* const wnd )
{
	GtkWidget *pWindow = NULL;
	GList *pGlist = NULL;
	int nRet = 0;
	const char* const ctrl_type[WLAN_STATUS_CTRL_TYPE_NUM] = { "CNSUIWLanStateDlg", "CNSUICtrlWLANStatus", NULL };
	int i = 0;

	if( wnd == NULL )
	{
		return -1;
	}

	if( wnd->wlanstatus_dlg == NULL )
	{
		return -1;
	}
	else
	{
		pWindow = wnd->wlanstatus_dlg->dialog.window;
	}

	CreatePPDCtrlTbl( wnd, ctrl_type, ctrlTbl, PPDCtrlTbl );

	SetLabel_HideWidget( pWindow, PPDCtrlTbl, ctrlTbl );

	pGlist = CreateGlist_DbId( PPDCtrlTbl );

	if( wnd->wlanstatus_dlg->pDialogDict != NULL )
	{
		UI_DEBUG("pDialogDict no mem_free, from Func[%s] Line[%u] \n", __func__, __LINE__);
		DeleteDict( wnd->wlanstatus_dlg->pDialogDict );
	}

	wnd->wlanstatus_dlg->pDialogDict = CretateDict_GetData( pGlist );
	g_list_free_wrapper( pGlist );
	pGlist = NULL;

	if( wnd->wlanstatus_dlg->pDialogDict == NULL )
	{
		return -1;
	}

	nRet = CommunicatePrinterData( wnd, NULL, wnd->wlanstatus_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );

	if( nRet != 0 )
	{
		return -1;
	}

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		Dict *pValueDict = NULL;

		switch( PPDCtrlTbl[i]->dbid )
		{
		case ID120764:
			pValueDict = GetItemValueType_dict( wnd->wlanstatus_dlg->pDialogDict, PPDCtrlTbl[i]->dbid );
			if( pValueDict != NULL )
			{
				GList *connectList = NULL;
				GList *wlanList = NULL;

				connectList = GetDictValueGList_forKey( pValueDict, KEY_CONNECT_STATUS );
				if( connectList != NULL )
				{
					if( g_list_find_custom(connectList, WLAN_STATUS_STOP, (GCompareFunc)strcmp ) != NULL )
					{
						SetTextToLabel( pWindow, "WLANStatus_Status", _(N_("Inactive")) );
					}
					else if( g_list_find_custom(connectList, WLAN_STATUS_DISCONNECT, (GCompareFunc)strcmp ) != NULL )
					{
						SetTextToLabel( pWindow, "WLANStatus_Status", _(N_("Disconnected")) );
					}
					else if( g_list_find_custom(connectList, WLAN_STATUS_CONNECT, (GCompareFunc)strcmp ) != NULL )
					{
						wlanList = GetDictValueGList_forKey( pValueDict, KEY_WLAN_STATUS );
						if( wlanList != NULL )
						{
							if( g_list_find_custom(wlanList, WLAN_RSSI_VERY_BAD, (GCompareFunc)strcmp ) != NULL )
							{
								SetTextToLabel( pWindow, "WLANStatus_Status", _(N_("Very Bad")) );
							}
							else if( g_list_find_custom(wlanList, WLAN_RSSI_BAD, (GCompareFunc)strcmp ) != NULL )
							{
								SetTextToLabel( pWindow, "WLANStatus_Status", _(N_("Bad")) );
							}
							else if( g_list_find_custom(wlanList, WLAN_RSSI_NORMAL, (GCompareFunc)strcmp ) != NULL )
							{
								SetTextToLabel( pWindow, "WLANStatus_Status", _(N_("Normal")) );
							}
							else if( g_list_find_custom(wlanList, WLAN_RSSI_GOOD, (GCompareFunc)strcmp ) != NULL )
							{
								SetTextToLabel( pWindow, "WLANStatus_Status", _(N_("Good")) );
							}
							else if( g_list_find_custom(wlanList, WLAN_RSSI_VERY_GOOD, (GCompareFunc)strcmp ) != NULL )
							{
								SetTextToLabel( pWindow, "WLANStatus_Status", _(N_("Very Good")) );
							}
							else
							{
								UI_DEBUG(" wlanList is not correct %s, from func %s from Line[%u]\n", (char*)wlanList->data, __func__, __LINE__);
								nRet = -1;
							}
						}
						else
						{
							UI_DEBUG("wlanList is not get, from func %s from Line[%u]\n", __func__, __LINE__);
							nRet = -1;
						}
					}
					else
					{
						UI_DEBUG("connectList is not correct %s, from func %s from Line[%u]\n", (char*)connectList->data, __func__, __LINE__);
						nRet = -1;
					}
				}
				else
				{
					UI_DEBUG("connectList is not get, from func %s from Line[%u]\n", __func__, __LINE__);
					nRet = -1;
				}
			}
			break;
		default:
			break;
		}
	}

	return nRet;
}


void DisposeWlansStatusDlg( UIStatusWnd* const wnd )
{
	UIWLANStatusDlg* ui_wlanstatus_dlg = NULL;

	if(wnd == NULL)
	{
		return;
	}

	ui_wlanstatus_dlg = wnd->wlanstatus_dlg;
	if( ui_wlanstatus_dlg != NULL )
	{
		if( ui_wlanstatus_dlg->pDialogDict != NULL )
		{
			DeleteDict( ui_wlanstatus_dlg->pDialogDict );
			ui_wlanstatus_dlg->pDialogDict = NULL;
		}
		DisposeDialog( (UIDialog *)ui_wlanstatus_dlg );
		wnd->wlanstatus_dlg = NULL;
	}
}

