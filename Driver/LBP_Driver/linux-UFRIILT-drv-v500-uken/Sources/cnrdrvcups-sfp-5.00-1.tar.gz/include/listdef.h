
#ifndef	_LISTDEF_H
#define _LISTDEF_H

typedef	struct ca_option_list_s{
	char *pKey;
	char *pValue;
	struct ca_option_list_s *next;
}CAOptList;

#endif
