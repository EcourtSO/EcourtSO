/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "uimain.h"
#include "widgets.h"
#include "interface.h"
#include "pfeedunitdlg.h"
#include "callbacks.h"
#include "support.h"
#include "id_defines.h"
#include "commandcontroller.h"
#include "value_defines.h"
#include "key_defines.h"
#include "statusinfo.h"

#define CS1PSW_STR "CS1PSW"
#define CS2PSW_STR "CS2PSW"
#define CS3PSW_STR "CS3PSW"
#define CS4PSW_STR "CS4PSW"

#define PPDKEY_CTRLFEEDUNITMAXSLOT "CNSUICtrlFeedUnitMaxSlot"
#define PPDVALUE_CTRLFEEDUNITMAXSLOT_DEF	1

static int InitPFeedUnitDlgWidgets( UIStatusWnd * const wnd );
static char* CreatePfeedUnitCtrlString( const char* const pCtrlStr, const char* const pSource );
static unsigned int SetCombobox_Value( GtkWidget * const gtkwidget_Pfeed, const char* const pCtrl, Dict* const pSetDict, const char* const pKeyName, GList* const gList );
static unsigned int SetItemValue_PfeedUnitDlgOK_PaperInfo( const UIStatusWnd * const wnd, GtkWidget * const gtkwidget_Pfeed, const PaperUnitInformation* const pPaperInfo, const int nDBID );
static unsigned int SetItemValue_PfeedUnitDlgOK( const UIStatusWnd* const wnd );
static GList* PFeedUnitDlgMakePaperList( const UIStatusWnd* const wnd, const char* const pPrefix, char* const ppdKey );
static GList* PFeedUnitDlgMakeComboList( const UIStatusWnd * const wnd, GList* const gKeyList );
static gboolean PFeedUnitDlgAddPPDCtrlTbl_AutoSelectInfo( const UIStatusWnd * const wnd, AutoSelectInformation* const pAutoSelectInfo, CtrlTbl * const pSourceTbl );
static gboolean PFeedUnitDlgAddPPDCtrlTbl_PaperInfo( const UIStatusWnd * const wnd, PaperUnitInformation* const pPaperInfo, CtrlTbl * const pSourceTbl );
static gboolean PFeedUnitDlgAddPPDCtrlTbl( const UIStatusWnd * const wnd, CtrlTbl** const pSUCtrlTbl );
static gboolean UpdatePaperFeedComboCtrl( const char * const pSelectSize, GList* const gFeedList );
static int SetDrawerCtrl( GtkWidget * const gtkwidget_Pfeed, Dict* const pBaseDict, GList* const gCtrlList, GList* const gDispList, const char* const pKeyName, const char* const pCtrlName, int* const pPos );
static int DrawerCtrlInitSetting( GtkWidget * const gtkwidget_Pfeed, const PaperUnitInformation* const pPaperInfo, Dict* const pDict );
static void DisposePaperUnitStruct( PaperUnitInformation* const pPaperInfo );


CtrlTbl* PPDCtrlTbl[CTRL_LIST_MAXNUM];

#define PFEEDUNITDLG_CTRLTBLNUM 11

static CtrlTbl ctrlTbl[PFEEDUNITDLG_CTRLTBLNUM] =
{
	{ ID_PFEEDUNIT_DIALOG1, LABEL_TYPE_TITLE, NULL, N_("Paper Source Settings"), NULL, 0 },
	{ ID_CTRLCS1FRAME_TEXT,  LABEL_TYPE_TEXT, N_("PFeedUnitDlg_CS1_label"), N_("Drawer 1"), "PFeedUnitDlg_CS1frame", ID954 },
	{ ID_CTRLMPTRAYFRAME_TEXT,  LABEL_TYPE_TEXT, N_("PFeedUnitDlg_MPTray_label"), N_("Multi-purpose Tray"), "PFeedUnitDlg_MPTrayframe", ID974 },
	{ ID_CTRLCS1PSWFRAME_TEXT,  LABEL_TYPE_TEXT, N_("PFeedUnitDlg_CS1PSW_label"), N_("Drawer 1"), "PFeedUnitDlg_CS1PSWframe", ID1664 },
	{ ID_CTRLCS2PSWFRAME_TEXT,  LABEL_TYPE_TEXT, N_("PFeedUnitDlg_CS2PSW_label"), N_("Drawer 2"), "PFeedUnitDlg_CS2PSWframe", ID1674 },
	{ ID_CTRLCS3PSWFRAME_TEXT,  LABEL_TYPE_TEXT, N_("PFeedUnitDlg_CS3PSW_label"), N_("Drawer 3"), "PFeedUnitDlg_CS3PSWframe", ID1684 },
	{ ID_CTRLCS4PSWFRAME_TEXT,  LABEL_TYPE_TEXT, N_("PFeedUnitDlg_CS4PSW_label"), N_("Drawer 4"), "PFeedUnitDlg_CS4PSWframe", ID1694 },
	{ ID_CTRLASFRAME_TEXT,  LABEL_TYPE_TEXT, N_("PFeedUnitDlg_AutoSelect_label"), N_("Paper Sources to Auto Select"), "PFeedUnitDlg_AutoSelectframe", 0 },
	{ ID_CTRLPFEEDHELPFRAME_TEXT,  LABEL_TYPE_TEXT, N_("PFeedUnitDlg_Help_label"), N_(" "), "PFeedUnitDlg_Helpframe", 0 },
	{ -1, -1, NULL, NULL, NULL, -1 }
};

#define PFEEDUNITDLG_CS1_CTRLTBLNUM 5
#define PFEEDUNITDLG_PSW_CTRLTBLNUM 4
#define PFEEDUNITDLG_AutoSelect_CTRLTBLNUM 6

static CtrlTbl CS1CtrlTbl[PFEEDUNITDLG_CS1_CTRLTBLNUM] =
{
	{ ID_CTRLSIZE_TEXT, LABEL_TYPE_TEXT, "PFeedUnitDlg_CS1Size_label", N_("Paper Size:"), "PFeedUnitDlg_CS1Size_box", 0 },
	{ ID_CTRLTYPE_TEXT, LABEL_TYPE_TEXT, "PFeedUnitDlg_CS1Type_label", N_("Paper Type:"), "PFeedUnitDlg_CS1Type_box", 0 },
	{ ID_CTRLFEED_TEXT, LABEL_TYPE_TEXT, "PFeedUnitDlg_CS1Feed_label", N_("Paper Feed Direction:"), "PFeedUnitDlg_CS1Feed_box", 0 },
	{ ID_CTRLROUGH, LABEL_TYPE_BUTTON, "PFeedUnitDlg_CS1Rough_checkbutton", N_("Use Rough Paper"), "PFeedUnitDlg_CS1Rough_checkbutton", ID852 },
	{ -1, -1, NULL, NULL, NULL, -1 }
};

static CtrlTbl CS1PSWCtrlTbl[PFEEDUNITDLG_PSW_CTRLTBLNUM] =
{
	{ ID_CTRLSIZE_TEXT, LABEL_TYPE_TEXT, "PFeedUnitDlg_CS1PSWSize_label", N_("Paper Size:"), "PFeedUnitDlg_CS1PSWSize_box", 0 },
	{ ID_CTRLTYPE_TEXT, LABEL_TYPE_TEXT, "PFeedUnitDlg_CS1PSWType_label", N_("Paper Type:"), "PFeedUnitDlg_CS1PSWType_box", 0 },
	{ ID_CTRLFEED_TEXT, LABEL_TYPE_TEXT, "PFeedUnitDlg_CS1PSWFeed_label", N_("Paper Feed Direction:"), "PFeedUnitDlg_CS1PSWFeed_box", 0 },
	{ -1, -1, NULL, NULL, NULL, -1 }
};

static CtrlTbl CS2PSWCtrlTbl[PFEEDUNITDLG_PSW_CTRLTBLNUM] =
{
	{ ID_CTRLSIZE_TEXT, LABEL_TYPE_TEXT, "PFeedUnitDlg_CS2PSWSize_label", N_("Paper Size:"), "PFeedUnitDlg_CS2PSWSize_box", 0 },
	{ ID_CTRLTYPE_TEXT, LABEL_TYPE_TEXT, "PFeedUnitDlg_CS2PSWType_label", N_("Paper Type:"), "PFeedUnitDlg_CS2PSWType_box", 0 },
	{ ID_CTRLFEED_TEXT, LABEL_TYPE_TEXT, "PFeedUnitDlg_CS2PSWFeed_label", N_("Paper Feed Direction:"), "PFeedUnitDlg_CS2PSWFeed_box", 0 },
	{ -1, -1, NULL, NULL, NULL, -1 }
};

static CtrlTbl CS3PSWCtrlTbl[PFEEDUNITDLG_PSW_CTRLTBLNUM] =
{
	{ ID_CTRLSIZE_TEXT, LABEL_TYPE_TEXT, "PFeedUnitDlg_CS3PSWSize_label", N_("Paper Size:"), "PFeedUnitDlg_CS3PSWSize_box", 0 },
	{ ID_CTRLTYPE_TEXT, LABEL_TYPE_TEXT, "PFeedUnitDlg_CS3PSWType_label", N_("Paper Type:"), "PFeedUnitDlg_CS3PSWType_box", 0 },
	{ ID_CTRLFEED_TEXT, LABEL_TYPE_TEXT, "PFeedUnitDlg_CS3PSWFeed_label", N_("Paper Feed Direction:"), "PFeedUnitDlg_CS3PSWFeed_box", 0 },
	{ -1, -1, NULL, NULL, NULL, -1 }
};

static CtrlTbl CS4PSWCtrlTbl[PFEEDUNITDLG_PSW_CTRLTBLNUM] =
{
	{ ID_CTRLSIZE_TEXT, LABEL_TYPE_TEXT, "PFeedUnitDlg_CS4PSWSize_label", N_("Paper Size:"), "PFeedUnitDlg_CS4PSWSize_box", 0 },
	{ ID_CTRLTYPE_TEXT, LABEL_TYPE_TEXT, "PFeedUnitDlg_CS4PSWType_label", N_("Paper Type:"), "PFeedUnitDlg_CS4PSWType_box", 0 },
	{ ID_CTRLFEED_TEXT, LABEL_TYPE_TEXT, "PFeedUnitDlg_CS4PSWFeed_label", N_("Paper Feed Direction:"), "PFeedUnitDlg_CS4PSWFeed_box", 0 },
	{ -1, -1, NULL, NULL, NULL, -1 }
};

static CtrlTbl MPTrayCtrlTbl[PFEEDUNITDLG_PSW_CTRLTBLNUM] =
{
	{ ID_CTRLSIZE_TEXT, LABEL_TYPE_TEXT, "PFeedUnitDlg_MPTraySize_label", N_("Paper Size:"), "PFeedUnitDlg_MPTraySize_box", 0 },
	{ ID_CTRLTYPE_TEXT, LABEL_TYPE_TEXT, "PFeedUnitDlg_MPTrayType_label", N_("Paper Type:"), "PFeedUnitDlg_MPTrayType_box", 0 },
	{ ID_CTRLFEED_TEXT, LABEL_TYPE_TEXT, "PFeedUnitDlg_MPTrayFeed_label", N_("Paper Feed Direction:"), "PFeedUnitDlg_MPTrayFeed_box", 0 },
 	{ -1, -1, NULL, NULL, NULL, -1 }
};

static CtrlTbl ASCtrlTbl[PFEEDUNITDLG_AutoSelect_CTRLTBLNUM] =
{
	{ID_CTRLSOURCE_MPT, LABEL_TYPE_BUTTON, "PFeedUnitDlg_AutoSelectMPT_checkbutton", N_("Multi-purpose Tray"), "PFeedUnitDlg_AutoSelectMPT_checkbutton", ID812 },
	{ID_CTRLSOURCE_CS1, LABEL_TYPE_BUTTON, "PFeedUnitDlg_AutoSelectCS1_checkbutton", N_("Drawer 1"), "PFeedUnitDlg_AutoSelectCS1_checkbutton", ID822 },
	{ID_CTRLSOURCE_CS2, LABEL_TYPE_BUTTON, "PFeedUnitDlg_AutoSelectCS2_checkbutton", N_("Drawer 2"), "PFeedUnitDlg_AutoSelectCS2_checkbutton", ID832 },
	{ID_CTRLSOURCE_CS3, LABEL_TYPE_BUTTON, "PFeedUnitDlg_AutoSelectCS3_checkbutton", N_("Drawer 3"), "PFeedUnitDlg_AutoSelectCS3_checkbutton", ID1192 },
	{ID_CTRLSOURCE_CS4, LABEL_TYPE_BUTTON, "PFeedUnitDlg_AutoSelectCS4_checkbutton", N_("Drawer 4"), "PFeedUnitDlg_AutoSelectCS4_checkbutton", ID1202 },

	{ -1, -1, NULL, NULL, NULL, -1 }
};

typedef struct _PaperUnitInfomationTbl{
	int nIdx;
	int nDBID;
	char* pFeedComboBox;
	int nCtrlID;
	CtrlTbl* pFrameCtrlTbl;
	char* pSourceStr;
}PaperUnitInfomationTbl;

static PaperUnitInfomationTbl paperUnitInfomationTbl[] =
{ {0,ID954,"PFeedUnitDlg_CS1Feed_combo",ID_CTRLCS1FRAME_TEXT,CS1CtrlTbl, CS1_STR},
  {0,ID1664,"PFeedUnitDlg_CS1PSWFeed_combo",ID_CTRLCS1PSWFRAME_TEXT,CS1PSWCtrlTbl, CS1PSW_STR},
  {1,ID1674,"PFeedUnitDlg_CS2PSWFeed_combo",ID_CTRLCS2PSWFRAME_TEXT,CS2PSWCtrlTbl, CS2PSW_STR},
  {2,ID1684,"PFeedUnitDlg_CS3PSWFeed_combo",ID_CTRLCS3PSWFRAME_TEXT,CS3PSWCtrlTbl, CS3PSW_STR},
  {3,ID1694,"PFeedUnitDlg_CS4PSWFeed_combo",ID_CTRLCS4PSWFRAME_TEXT,CS4PSWCtrlTbl, CS4PSW_STR},
  {4,ID974,"PFeedUnitDlg_MPTrayFeed_combo",ID_CTRLMPTRAYFRAME_TEXT,MPTrayCtrlTbl, MPTRAY_STR}
};

typedef struct _CHECKBOX_ID
{
	int	nDbID;
	char*	pCtrlName;
}CHECKBOX_ID;

static CHECKBOX_ID checkBox_IDs[] =
{
	{ID852,		"PFeedUnitDlg_CS1Rough_checkbutton"},
	{ID812,		"PFeedUnitDlg_AutoSelectMPT_checkbutton"},
	{ID822,		"PFeedUnitDlg_AutoSelectCS1_checkbutton"},
	{ID832,		"PFeedUnitDlg_AutoSelectCS2_checkbutton"},
	{ID1192,	"PFeedUnitDlg_AutoSelectCS3_checkbutton"},
	{ID1202,	"PFeedUnitDlg_AutoSelectCS4_checkbutton"}
};


UIPfeedUnitDlg* CreatePFeedUnitDlg(UIDialog* const parent, int maxSlot)
{
	UIPfeedUnitDlg *pDialog;

    if( maxSlot <= 0 )
    {
        return NULL;
    }

	pDialog = (UIPfeedUnitDlg *)CreateDialog(sizeof(UIPfeedUnitDlg), parent);

	if( pDialog != NULL )
	{
		pDialog->nMaxSlot = maxSlot;
		pDialog->pPaperUnitInformation = (PaperUnitInformation *)calloc(pDialog->nMaxSlot,sizeof(PaperUnitInformation));
		memset( &(pDialog->ASInformation), 0, sizeof( pDialog->ASInformation ) );
		UI_DIALOG(pDialog)->window = create_PFeedUnit_dialog();
	}
	return pDialog;
}

void ShowPfeedUnitSettingDlg( UIStatusWnd * const wnd )
{
	int nRet = 0;

	if( wnd == NULL )
	{
		return;
	}
	if( wnd->pfeedunit_dlg == NULL )
	{
		int maxSlot = 0;
		if ( FALSE == GetPPDValue_Integer( wnd->pModData, PPDKEY_CTRLFEEDUNITMAXSLOT, &maxSlot) )
		{
			maxSlot = PPDVALUE_CTRLFEEDUNITMAXSLOT_DEF;
		}
        if( maxSlot <= 0 )
        {
            maxSlot = PPDVALUE_CTRLFEEDUNITMAXSLOT_DEF;
        }
		wnd->pfeedunit_dlg = CreatePFeedUnitDlg( UI_DIALOG( wnd ), maxSlot );
	}

	SigDisable();
	nRet = InitPFeedUnitDlgWidgets( wnd );
	SigEnable();

	if( nRet == 0 )
	{
		ShowDialog( (UIDialog *)wnd->pfeedunit_dlg, NULL );
	}
	else
	{
		ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_GET );
		if( wnd->pfeedunit_dlg != NULL )
		{
			if( wnd->pfeedunit_dlg->pDialogDict != NULL )
			{
				DeleteDict( wnd->pfeedunit_dlg->pDialogDict );
				wnd->pfeedunit_dlg->pDialogDict = NULL;
			}
			int nLoop = 0;
			if( NULL != wnd->pfeedunit_dlg->pPaperUnitInformation )
			{
				for( nLoop = 0; nLoop < wnd->pfeedunit_dlg->nMaxSlot; nLoop++ )
				{
					DisposePaperUnitStruct( &(wnd->pfeedunit_dlg->pPaperUnitInformation[nLoop]) );
				}
				free(wnd->pfeedunit_dlg->pPaperUnitInformation);
				wnd->pfeedunit_dlg->pPaperUnitInformation = NULL;
			}
			mem_free( wnd->pfeedunit_dlg );
			wnd->pfeedunit_dlg = NULL;
		}
	}
}

#define PFEEDUNITDLG_CTRL_PREFIX "PFeedUnitDlg_"

static char* CreatePfeedUnitCtrlString( const char* const pCtrlStr, const char* const pSource )
{
	char* pRetStr = NULL;
	GString* gCtrlString = NULL;

	if( (pCtrlStr == NULL) || (pSource == NULL) )
	{
		return pRetStr;
	}

	gCtrlString = g_string_new_wrapper( PFEEDUNITDLG_CTRL_PREFIX, __FILE__, __LINE__);
	if( gCtrlString == NULL )
	{
		return pRetStr;
	}
	g_string_append( gCtrlString, pSource );
	g_string_append( gCtrlString, pCtrlStr );

	pRetStr = gCtrlString->str;
	g_string_free_wrapper(gCtrlString, FALSE );
	return pRetStr;
}


static unsigned int SetCombobox_Value( GtkWidget * const gtkwidget_Pfeed, const char* const pCtrl, Dict* pSetDict, const char* const pKeyName, GList* const gList )
{
	unsigned int unRet = DICT_SET_RETURN_ERROR;
	int nSelectIndex = 0;
	char* pValue = NULL;
	Dict* pDict = NULL;

	if( (gtkwidget_Pfeed == NULL) || (pCtrl == NULL) || (pSetDict == NULL) || (pKeyName == NULL) || (gList == NULL) )
	{
		return unRet;
	}
	nSelectIndex = GetCurrComboBoxIndex( gtkwidget_Pfeed, pCtrl );
	if( nSelectIndex == -1 )
	{
		return unRet;
	}
	pValue = (char*)g_list_nth_data( gList, (unsigned int)nSelectIndex );

	pDict = GetDict_forkey(pSetDict, pKeyName);
	if( pDict == NULL )
	{
		return unRet;
	}
	unRet = SetDictValuetype_char(pDict, pValue);

	return unRet;
}

static unsigned int SetItemValue_PfeedUnitDlgOK_PaperInfo( const UIStatusWnd * const wnd, GtkWidget * const gtkwidget_Pfeed, const PaperUnitInformation* const pPaperInfo, const int nDBID )
{
	unsigned int unRet = 0;
	Dict* pInfoDict = NULL;
	int nCtrlIndex = 0;

	if( (wnd == NULL) || (wnd->pfeedunit_dlg == NULL)  || (pPaperInfo == NULL) )
	{
		return DICT_SET_RETURN_ERROR;
	}

	pInfoDict = GetItemValueType_dict( wnd->pfeedunit_dlg->pDialogDict, nDBID );
	if( pInfoDict == NULL )
	{
		return DICT_SET_RETURN_ERROR;
	}

	for( nCtrlIndex = 0; pPaperInfo->PaperUnitPPDCtrlTbl[nCtrlIndex] != NULL; ++nCtrlIndex )
	{
		switch( pPaperInfo->PaperUnitPPDCtrlTbl[nCtrlIndex]->ctrlid )
		{
			case ID_CTRLSIZE_TEXT:
			{
				char* pCtrlStr = NULL;

				pCtrlStr = CreatePfeedUnitCtrlString( "Size_combo", pPaperInfo->pSourceStr );
				unRet |= SetCombobox_Value( gtkwidget_Pfeed, pCtrlStr, pInfoDict, KEY_PAPER_SIZE, pPaperInfo->SizeList );
				mem_free( pCtrlStr );
				break;
			}
			case ID_CTRLTYPE_TEXT:
			{
				char* pCtrlStr = NULL;

				pCtrlStr = CreatePfeedUnitCtrlString( "Type_combo", pPaperInfo->pSourceStr );
				unRet |= SetCombobox_Value( gtkwidget_Pfeed, pCtrlStr, pInfoDict, KEY_PAPER_TYPE, pPaperInfo->TypeList );
				mem_free( pCtrlStr );
				break;
			}
			case ID_CTRLFEED_TEXT:
			{
				char* pCtrlStr = NULL;

				pCtrlStr = CreatePfeedUnitCtrlString( "Feed_combo", pPaperInfo->pSourceStr );
				unRet |= SetCombobox_Value( gtkwidget_Pfeed, pCtrlStr, pInfoDict, KEY_ORIENTATION, pPaperInfo->FeedList );
				mem_free( pCtrlStr );
				break;
			}
			default:
			{
				UI_DEBUG("SetItemValue_PfeedUnitDlgOK_PaperInfo Source[%s] Ctrl[%d] do not check\n", pPaperInfo->pSourceStr, pPaperInfo->PaperUnitPPDCtrlTbl[nCtrlIndex]->ctrlid);
				break;
			}
		}
		if( (unRet & DICT_SET_RETURN_ERROR) == DICT_SET_RETURN_ERROR )
		{
			UI_DEBUG("%s unRet error, from Line[%u]\n", __func__, __LINE__);
			break;
		}
	}
	if( unRet == DICT_SET_RETURN_SAME  )
	{
		if( SetData_ItemDelete( wnd->pfeedunit_dlg->pDialogDict, nDBID ) == -1 )
		{
			unRet = DICT_SET_RETURN_ERROR;
			UI_DEBUG("%s SetData_ItemDelete error, from Line[%u]\n", __func__, __LINE__);
		}
	}

	return unRet;
}

static unsigned int SetItemValue_PfeedUnitDlgOK( const UIStatusWnd* const wnd )
{
	int i = 0;
	int nValue = 0;
	int nLoop = 0;
	char* pCtrlName = NULL;
	unsigned int unRet = 0;
	GtkWidget *gtkwidget_Pfeed = NULL;

	if( (wnd == NULL) || (wnd->pfeedunit_dlg == NULL) )
	{
		return DICT_SET_RETURN_ERROR;
	}
	gtkwidget_Pfeed = wnd->pfeedunit_dlg->dialog.window;

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		switch( PPDCtrlTbl[i]->dbid )
		{
			case ID852:
			case ID812:
			case ID822:
			case ID832:
			case ID1192:
			case ID1202:
			{
				pCtrlName = NULL;
				for( nLoop = 0; nLoop < (sizeof( checkBox_IDs ) / sizeof( checkBox_IDs[0] )); nLoop++ )
				{
					if( PPDCtrlTbl[i]->dbid == checkBox_IDs[nLoop].nDbID )
					{
						pCtrlName = checkBox_IDs[nLoop].pCtrlName;
						break;
					}
				}
				if( NULL != pCtrlName )
				{
					nValue = GetToggleButtonActive( gtkwidget_Pfeed, pCtrlName, FALSE );
					unRet |= SetItemValuetype_int( wnd->pfeedunit_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, nValue );
				}
				break;
			}
			case ID954:
			case ID1664:
			case ID1674:
			case ID1684:
			case ID1694:
			case ID974:
			{
				PaperUnitInformation* paperUnitInfomation = NULL;

				for( nLoop = 0; nLoop < (sizeof( paperUnitInfomationTbl ) / sizeof( paperUnitInfomationTbl[0] )); nLoop++ )
				{
					if( PPDCtrlTbl[i]->dbid == paperUnitInfomationTbl[nLoop].nDBID )
					{
						paperUnitInfomation = &(wnd->pfeedunit_dlg->pPaperUnitInformation[paperUnitInfomationTbl[nLoop].nIdx]);
						break;
					}
				}

				if(NULL != paperUnitInfomation)
				{
					unRet |= SetItemValue_PfeedUnitDlgOK_PaperInfo( wnd, gtkwidget_Pfeed, paperUnitInfomation, PPDCtrlTbl[i]->dbid );
				}
				break;
			}
			default:
			{
				UI_DEBUG("SetItemValue_PfeedUnitDlgOK Ctrl[%d] do not Item\n",PPDCtrlTbl[i]->ctrlid);
				break;
			}
		}
		if( (unRet & DICT_SET_RETURN_ERROR) == DICT_SET_RETURN_ERROR )
		{
			break;
		}
	}
	return unRet;
}

enum {
	pfeedunitdlg_ok_check_none = 0,
	pfeedunitdlg_ok_check_autoselect
};

static int PfeedUnitSettingDlgOK_beforeCheck( UIStatusWnd *wnd )
{
	int nRet = 0;

	gboolean nValue = FALSE;
	int index = 0;
	GtkWidget *gtkwidget_Pfeed = NULL;
	int nCheckKind = pfeedunitdlg_ok_check_none;

	char* ppdValue = NULL;
	char** pppdList = NULL;


	if( (wnd == NULL) || (NULL == wnd->pfeedunit_dlg) )
	{
		return DICT_SET_RETURN_ERROR;
	}

	ppdValue = cngplpGetValue( wnd->pModData, "CNSUICtrlFeedUnit" );
	if( ppdValue != NULL )
	{
		pppdList = SeparateString( ppdValue, CHARACTER_COMMA );
		mem_free( ppdValue );
	}

	if( NULL != pppdList )
	{
		for( index = 0; pppdList[index] != NULL; index++ )
		{
			if( strcmp(pppdList[index], "CtrlFUAutoSelect") == 0)
			{
				nCheckKind = pfeedunitdlg_ok_check_autoselect;
				break;
			}
		}

		mem_free_list( pppdList );
		pppdList = NULL;
	}

	if( nCheckKind == pfeedunitdlg_ok_check_autoselect )
	{
		nRet = DICT_SET_RETURN_CHECKERROR;
		gtkwidget_Pfeed = wnd->pfeedunit_dlg->dialog.window;

		for( index = 0; ASCtrlTbl[index].ctrlbox != NULL; index++)
		{
			nValue = GetToggleButtonActive( gtkwidget_Pfeed, ASCtrlTbl[index].ctrlbox, FALSE );

			if( TRUE == nValue )
			{
				nRet = 0;
				break;
			}
		}
	}

	return nRet;
}

void PfeedUnitSettingDlgOK( UIStatusWnd *wnd )
{
	int nRet = 0;
	unsigned int unRet = 0;

	if( wnd == NULL )
	{
		return;
	}

	nRet = PfeedUnitSettingDlgOK_beforeCheck( wnd );

	if( DICT_SET_RETURN_CHECKERROR != nRet )
	{
		nRet = CreateDict_SetData( wnd->pfeedunit_dlg->pDialogDict );

		if( nRet == 0 )
		{
			unRet = SetItemValue_PfeedUnitDlgOK( wnd );
			if( (unRet & DICT_SET_RETURN_ERROR) == DICT_SET_RETURN_ERROR )
			{
				nRet = -1;
				UI_DEBUG("%s SetItemValue_PfeedUnitDlgOK error, from Line[%u]\n", __func__, __LINE__);
			}
		}

		if( ( nRet == 0 ) && ( unRet == DICT_SET_RETURN_CHANGE ) )
		{
			nRet = CommunicatePrinterData( wnd, (UIDialog *)wnd->pfeedunit_dlg, wnd->pfeedunit_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
		}

		HideDialog( (UIDialog *)wnd->pfeedunit_dlg );

		if( nRet != 0 )
		{
			ShowMsgDlg( wnd, ID_COMMUNICATION_ERR_SET );
		}
	}
	else
	{
		ShowMsgDlg( wnd, ID_AUTOSELECT_ERR );
	}

	return;
}

static gboolean UpdatePaperFeedComboCtrl( const char * const pSelectSize, GList* const gFeedList )
{
	gboolean bVirtical = FALSE;

	if( (gFeedList == NULL) || (pSelectSize == NULL))
	{
		UI_DEBUG("UpdatePaperFeedComboCtrl gFeedList[%p] Select Size[%s]\n",gFeedList, pSelectSize);
		return bVirtical;
	}

	if( g_list_find_custom( gFeedList, pSelectSize, (GCompareFunc)strcmp ) != NULL )
	{
		bVirtical = TRUE;
	}
	return bVirtical;
}

enum {
	PFEEDUNITDLG_FEED_SHORT = 0,
	PFEEDUNITDLG_FEED_LONG
};

void UpdatePFeedUnitDlgChangeFeedCtrl( const UIStatusWnd * const wnd, const int nIndex, const char* const pCtrl )
{
	GtkWidget *gtkwidget_Pfeed = NULL;
	int nIdx = 0;
	int nLoop = 0;
	int nDisabelIdx = PFEEDUNITDLG_FEED_SHORT;
	gboolean bFeedCombo = FALSE;
	PaperUnitInformation* pPaperInfo = NULL;

	if( (wnd == NULL) || (wnd->pfeedunit_dlg == NULL) || (pCtrl == NULL) )
	{
		return;
	}

	if( nIndex < 0 )
	{
		return;
	}

	gtkwidget_Pfeed = wnd->pfeedunit_dlg->dialog.window;

	for(nLoop = 0; nLoop < (sizeof( paperUnitInfomationTbl ) / sizeof( paperUnitInfomationTbl[0] )); nLoop++)
	{
		if( strcmp( pCtrl, paperUnitInfomationTbl[nLoop].pFeedComboBox ) == 0 )
		{
			bFeedCombo = TRUE;
			nIdx = paperUnitInfomationTbl[nLoop].nIdx;
			pPaperInfo = &(wnd->pfeedunit_dlg->pPaperUnitInformation[nIdx]);
			break;
		}
	}

	if( (TRUE == bFeedCombo) && (NULL != pPaperInfo) )
	{
		const char *pSize = NULL;
		gboolean bEnable = FALSE;

		if( nIndex < (int)g_list_length( pPaperInfo->SizeList ) )
		{
			pSize = (char *)g_list_nth_data( pPaperInfo->SizeList, (unsigned int)nIndex );
			if( pSize != NULL )
			{
				bEnable = UpdatePaperFeedComboCtrl( pSize, pPaperInfo->FeedPosList );
				if( bEnable == FALSE )
				{
					nDisabelIdx = PFEEDUNITDLG_FEED_SHORT;
					if( NULL != pPaperInfo->FeedPosHorList )
					{
						bEnable = UpdatePaperFeedComboCtrl( pSize, pPaperInfo->FeedPosHorList );
						if( bEnable == TRUE )
						{
							nDisabelIdx = PFEEDUNITDLG_FEED_LONG;
						}
					}
					SetCurrComboBoxIndex( gtkwidget_Pfeed, pCtrl, nDisabelIdx );
					bEnable = FALSE;
				}
			}
			SetWidgetSensitive( gtkwidget_Pfeed, pCtrl, bEnable );
		}
	}
}

static GList* PFeedUnitDlgMakePaperList( const UIStatusWnd* const wnd, const char* const pPrefix, char* const ppdKey )
{
	char* ppdValue = NULL;
	char** pppdList = NULL;
	GList* gList = NULL;

	if( wnd == NULL )
	{
		return NULL;
	}
	ppdValue = cngplpGetValue( wnd->pModData, ppdKey );
	if( ppdValue != NULL )
	{
		pppdList = SeparateString( ppdValue, CHARACTER_COMMA );
		mem_free( ppdValue );
	}
	if( pppdList != NULL )
	{
		int nIndex = 0;

		for( nIndex = 0; pppdList[nIndex] != NULL; nIndex++ )
		{
			char* pName = NULL;
			pName = InsertString( pppdList[nIndex], pPrefix, 0 );
			gList = g_list_append_wrapper( gList, pName, __FILE__, __LINE__);
		}
		mem_free_list( pppdList );
	}

	return gList;
}

static GList* PFeedUnitDlgMakeComboList( const UIStatusWnd * const wnd, GList* const gKeyList )
{
	unsigned int nIndex = 0;
	GList* gDispList = NULL;

	if( gKeyList == NULL )
	{
		return NULL;
	}

	for( nIndex = 0; nIndex < g_list_length(gKeyList); ++nIndex )
	{
		char* pKey = NULL;

		pKey = g_list_nth_data( gKeyList, nIndex );
		if( pKey != NULL )
		{
			char* pValueName = NULL;
			pValueName = getMessageFromPPDKey( wnd, pKey, NULL);
			if( pValueName != NULL )
			{
				gDispList = g_list_append_wrapper( gDispList, pValueName, __FILE__, __LINE__);
			}
		}
	}
	return gDispList;
}

#define SIZE_PREFIX "Size_"
#define TYPE_PREFIX "Type_"
#define FEED_PREFIX "Orientation_"

#define PFEEDUNITDLG_PPD_PREFIX "CNSUICtrlFU"

static gboolean PFeedUnitDlgAddPPDCtrlTbl_AutoSelectInfo( const UIStatusWnd * const wnd, AutoSelectInformation* const pAutoSelectInfo, CtrlTbl * const pSourceTbl )
{
	gboolean bRet = TRUE;
	int nCtrlIndex = 0;

	if( (wnd == NULL) || (pAutoSelectInfo == NULL) || (pSourceTbl == NULL))
	{
		UI_DEBUG("%s Augment error, from Line[%u]\n", __func__, __LINE__);
		return FALSE;
	}
	for( nCtrlIndex = 0; pSourceTbl[nCtrlIndex].ctrlid != -1; ++nCtrlIndex )
	{
		pAutoSelectInfo->PaperUnitPPDCtrlTbl[nCtrlIndex] = &(pSourceTbl[nCtrlIndex]);
	}
	pAutoSelectInfo->PaperUnitPPDCtrlTbl[nCtrlIndex + 1] = NULL;

	return bRet;
}

static gboolean PFeedUnitDlgAddPPDCtrlTbl_PaperInfo( const UIStatusWnd * const wnd, PaperUnitInformation* const pPaperInfo, CtrlTbl * const pSourceTbl )
{
	GString* gCtrl_type = NULL;
	int nCtrlList[CTRL_LIST_MAXNUM];
	int nCtrlNum = 0;
	int nIndex = 0;
	gboolean bRet = TRUE;

	if( (wnd == NULL) || (pPaperInfo == NULL) || (pSourceTbl == NULL))
	{
		UI_DEBUG("%s Augment error, from Line[%u]\n", __func__, __LINE__);
		return FALSE;
	}
	gCtrl_type = g_string_new_wrapper( PFEEDUNITDLG_PPD_PREFIX, __FILE__, __LINE__);
	if( gCtrl_type == NULL )
	{
		return FALSE;
	}
	g_string_append( gCtrl_type, pPaperInfo->pSourceStr );

	nCtrlNum = GetCtrlIdList( wnd, gCtrl_type->str, nCtrlList );
	g_string_free_wrapper( gCtrl_type, TRUE );
	if( nCtrlNum > 0 )
	{
		int nPPDIndex = 0;
		int nAddCtrl = 0;

		for( nPPDIndex = 0; nPPDIndex < nCtrlNum; ++nPPDIndex )
		{
			int nCtrlIndex = 0;

			for( nCtrlIndex = 0; pSourceTbl[nCtrlIndex].ctrlid != -1; ++nCtrlIndex )
			{
				if( nCtrlList[nPPDIndex] == pSourceTbl[nCtrlIndex].ctrlid )
				{
					pPaperInfo->PaperUnitPPDCtrlTbl[nAddCtrl] = &(pSourceTbl[nCtrlIndex]);
					nAddCtrl = nAddCtrl + 1;
					break;
				}
			}
			pPaperInfo->PaperUnitPPDCtrlTbl[nAddCtrl + 1] = NULL;
		}
	}

	for( nIndex = 0; pPaperInfo->PaperUnitPPDCtrlTbl[nIndex] != NULL; ++nIndex )
	{
		switch( pPaperInfo->PaperUnitPPDCtrlTbl[nIndex]->ctrlid )
		{
			case ID_CTRLSIZE_TEXT:
			{
				if( pPaperInfo->SizeList == NULL )
				{
					GString* gPPDString = NULL;

					gPPDString = g_string_new_wrapper( PFEEDUNITDLG_PPD_PREFIX, __FILE__, __LINE__);
					if ( gPPDString == NULL )
					{
						bRet = FALSE;
						UI_DEBUG("%s Do not create PPD key for paper size\n", __func__);
						break;
					}
					g_string_append( gPPDString, pPaperInfo->pSourceStr );
					g_string_append( gPPDString, "SizeList" );

					pPaperInfo->SizeList = PFeedUnitDlgMakePaperList( wnd, SIZE_PREFIX, gPPDString->str );
					g_string_free_wrapper( gPPDString, TRUE );
				}
				if( pPaperInfo->SizeDispList == NULL )
				{
					pPaperInfo->SizeDispList = PFeedUnitDlgMakeComboList( wnd, pPaperInfo->SizeList );
					if( g_list_length( pPaperInfo->SizeList ) != g_list_length( pPaperInfo->SizeDispList ) )
					{
						UI_DEBUG("%s Paper Size do not equal SizeList[%d] and DisplayList[%d]\n", __func__, g_list_length( pPaperInfo->SizeList ),g_list_length( pPaperInfo->SizeDispList ));
						bRet = FALSE;
						break;
					}
				}
				break;
			}
			case ID_CTRLTYPE_TEXT:
			{
				if( pPaperInfo->TypeList == NULL )
				{
					GString* gPPDString = NULL;
					gPPDString = g_string_new_wrapper( PFEEDUNITDLG_PPD_PREFIX, __FILE__, __LINE__);
					if ( gPPDString == NULL )
					{
						bRet = FALSE;
						UI_DEBUG("%s Do not create PPD key for paper type\n", __func__);
						break;
					}
					g_string_append( gPPDString, pPaperInfo->pSourceStr );
					g_string_append( gPPDString, "TypeList" );

					pPaperInfo->TypeList = PFeedUnitDlgMakePaperList( wnd, TYPE_PREFIX, gPPDString->str );
					g_string_free_wrapper( gPPDString, TRUE );
				}
				if( pPaperInfo->TypeDispList == NULL )
				{
					pPaperInfo->TypeDispList = PFeedUnitDlgMakeComboList( wnd, pPaperInfo->TypeList );
					if( g_list_length( pPaperInfo->TypeList ) != g_list_length( pPaperInfo->TypeDispList ) )
					{
						UI_DEBUG("%s Paper Type do not equal TypeList[%d] and DisplayList[%d]\n", __func__, g_list_length( pPaperInfo->TypeList ),g_list_length( pPaperInfo->TypeDispList ));
						bRet = FALSE;
						break;
					}
				}
				break;
			}
			case ID_CTRLFEED_TEXT:
			{
				if( pPaperInfo->FeedList == NULL )
				{
					GString* gPPDString = NULL;

					gPPDString = g_string_new_wrapper( PFEEDUNITDLG_PPD_PREFIX, __FILE__, __LINE__);
					if ( gPPDString == NULL )
					{
						bRet = FALSE;
						UI_DEBUG("%s Do not create PPD key for paper feed\n", __func__);
						break;
					}
					g_string_append( gPPDString, pPaperInfo->pSourceStr );
					g_string_append( gPPDString, "FeedList" );

					pPaperInfo->FeedList = PFeedUnitDlgMakePaperList( wnd, FEED_PREFIX, gPPDString->str );
					g_string_free_wrapper( gPPDString, TRUE );
				}
				if( pPaperInfo->FeedDispList == NULL )
				{
					pPaperInfo->FeedDispList = PFeedUnitDlgMakeComboList( wnd, pPaperInfo->FeedList );
					if( g_list_length( pPaperInfo->FeedList ) != g_list_length( pPaperInfo->FeedDispList ) )
					{
						UI_DEBUG("%s Paper Feed do not equal FeedList[%d] and DisplayList[%d]\n", __func__, g_list_length( pPaperInfo->FeedList ),g_list_length( pPaperInfo->FeedDispList ));
						bRet = FALSE;
						break;
					}
				}
				if( pPaperInfo->FeedPosList == NULL )
				{
					GString* gPPDString = NULL;

					gPPDString = g_string_new_wrapper( PFEEDUNITDLG_PPD_PREFIX, __FILE__, __LINE__);
					if ( gPPDString == NULL )
					{
						bRet = FALSE;
						UI_DEBUG("%s Do not create PPD key for paper feed position\n", __func__);
						break;
					}
					g_string_append( gPPDString, pPaperInfo->pSourceStr );
					g_string_append( gPPDString, "FeedPosList" );

					pPaperInfo->FeedPosList = PFeedUnitDlgMakePaperList( wnd, SIZE_PREFIX, gPPDString->str );
					g_string_free_wrapper( gPPDString, TRUE );
				}
				if( pPaperInfo->FeedPosHorList == NULL )
				{
					GString* gPPDString = NULL;

					gPPDString = g_string_new_wrapper( PFEEDUNITDLG_PPD_PREFIX, __FILE__, __LINE__);
					if ( gPPDString == NULL )
					{
						bRet = FALSE;
						UI_DEBUG("%s Do not create PPD key for paper feed position\n", __func__);
						break;
					}
					g_string_append( gPPDString, pPaperInfo->pSourceStr );
					g_string_append( gPPDString, "FeedPosHorList" );

					pPaperInfo->FeedPosHorList = PFeedUnitDlgMakePaperList( wnd, SIZE_PREFIX, gPPDString->str );
					g_string_free_wrapper( gPPDString, TRUE );
				}
				break;
			}
			default:
			{
				UI_DEBUG("PFeedUnitDlgAddPPDCtrlTbl_PaperInfo Ctrl[%d] do not Create List \n",pPaperInfo->PaperUnitPPDCtrlTbl[nIndex]->ctrlid);
				break;
			}
		}
		if( bRet == FALSE )
		{
			break;
		}
	}

	return bRet;
}

static gboolean PFeedUnitDlgAddPPDCtrlTbl( const UIStatusWnd * const wnd, CtrlTbl** const pSUCtrlTbl )
{
	int nIndex = 0;
	gboolean bRet = TRUE;
	int nLoop = 0;

	if( (wnd == NULL) || (wnd->pfeedunit_dlg == NULL) || (pSUCtrlTbl == NULL) )
	{
		return FALSE;
	}

	for( nIndex = 0; pSUCtrlTbl[nIndex] != NULL; ++nIndex)
	{
		switch( pSUCtrlTbl[nIndex]->ctrlid )
		{
			case ID_CTRLCS1FRAME_TEXT:
			case ID_CTRLCS1PSWFRAME_TEXT:
			case ID_CTRLCS2PSWFRAME_TEXT:
			case ID_CTRLCS3PSWFRAME_TEXT:
			case ID_CTRLCS4PSWFRAME_TEXT:
			case ID_CTRLMPTRAYFRAME_TEXT:
			{
				PaperUnitInformation* paperUnitInfomation = NULL;
				int nIdx = 0;

				for( nLoop = 0; nLoop < (sizeof( paperUnitInfomationTbl ) / sizeof( paperUnitInfomationTbl[0] )); nLoop++ )
				{
					if( pSUCtrlTbl[nIndex]->ctrlid == paperUnitInfomationTbl[nLoop].nCtrlID )
					{
						nIdx = paperUnitInfomationTbl[nLoop].nIdx;
						paperUnitInfomation = &(wnd->pfeedunit_dlg->pPaperUnitInformation[nIdx]);
						break;
					}
				}

				if(NULL != paperUnitInfomation)
				{
					paperUnitInfomation->pSourceStr = paperUnitInfomationTbl[nLoop].pSourceStr;
					paperUnitInfomation->addData = TRUE;
					bRet = PFeedUnitDlgAddPPDCtrlTbl_PaperInfo( wnd, paperUnitInfomation, paperUnitInfomationTbl[nLoop].pFrameCtrlTbl );
				}

				break;
			}
			case ID_CTRLASFRAME_TEXT:
			{
				wnd->pfeedunit_dlg->ASInformation.addData = TRUE;
				bRet = PFeedUnitDlgAddPPDCtrlTbl_AutoSelectInfo( wnd, &(wnd->pfeedunit_dlg->ASInformation), ASCtrlTbl );
				break;
			}
			default:
			{
				UI_DEBUG("PFeedUnitDlgAddPPDCtrlTbl Ctrl[%d] do not add Ctrl\n",pSUCtrlTbl[nIndex]->ctrlid);
				break;
			}
		}
		if( bRet == FALSE )
		{
			break;
		}
	}

	if( bRet != FALSE )
	{
		int nSourceIndex = 0;
		for( nLoop = 0; nLoop < wnd->pfeedunit_dlg->nMaxSlot; nLoop++ )
		{
			if( TRUE == wnd->pfeedunit_dlg->pPaperUnitInformation[nLoop].addData )
			{
				for( nSourceIndex = 0; wnd->pfeedunit_dlg->pPaperUnitInformation[nLoop].PaperUnitPPDCtrlTbl[nSourceIndex] != NULL; nSourceIndex++ )
				{
					pSUCtrlTbl[nIndex++] = wnd->pfeedunit_dlg->pPaperUnitInformation[nLoop].PaperUnitPPDCtrlTbl[nSourceIndex];
				}
			}
		}
		if( TRUE == wnd->pfeedunit_dlg->ASInformation.addData )
		{
			for( nSourceIndex = 0; wnd->pfeedunit_dlg->ASInformation.PaperUnitPPDCtrlTbl[nSourceIndex] != NULL; nSourceIndex++ )
			{
				pSUCtrlTbl[nIndex++] = wnd->pfeedunit_dlg->ASInformation.PaperUnitPPDCtrlTbl[nSourceIndex];
			}
		}
	}

	return bRet;
}

static int SetDrawerCtrl( GtkWidget * const gtkwidget_Pfeed, Dict* const pBaseDict, GList* const gCtrlList, GList* const gDispList, const char* const pKeyName, const char* const pCtrlName, int* const pPos )
{
	Dict* pCtrlDict = NULL;
	gint nPos = -1;
	char* pSelectName = NULL;
	GList* gtempList = NULL;

	if( (gtkwidget_Pfeed == NULL) || (pBaseDict == NULL) || (gCtrlList == NULL) || (gDispList == NULL) || (pKeyName == NULL) || (pCtrlName == NULL) )
	{
		UI_DEBUG("%s Augment error, from Line[%u]\n", __func__, __LINE__);
		return -1;
	}
	pCtrlDict = GetDict_forkey( pBaseDict, pKeyName );
	if( pCtrlDict == NULL )
	{
		UI_DEBUG("%s pCtrlDict NULL, from Line[%u]\n", __func__, __LINE__);
		return -1;
	}

	pSelectName = GetDictValuetype_char( pCtrlDict );
	if( pSelectName == NULL )
	{
		UI_DEBUG("%s pSelectName NULL, from Line[%u]\n", __func__, __LINE__);
		return -1;
	}

	gtempList = g_list_find_custom( gCtrlList, pSelectName, (GCompareFunc)strcmp);
	if( gtempList != NULL )
	{
		nPos = g_list_position( gCtrlList, gtempList );
	}

	SetGListToComboBox( gtkwidget_Pfeed, pCtrlName, gDispList );
	SetCurrComboBoxIndex( gtkwidget_Pfeed, pCtrlName, nPos );
	if( pPos != NULL )
	{
		*pPos = nPos;
	}
	return 0;
}

static int DrawerCtrlInitSetting( GtkWidget * const gtkwidget_Pfeed, const PaperUnitInformation* const pPaperInfo, Dict* const pDict )
{
	int nCrlIndex = 0;
	int nRet = -1;

	if( (gtkwidget_Pfeed == NULL) || (pPaperInfo == NULL) || (pPaperInfo->PaperUnitPPDCtrlTbl == NULL) || (pDict == NULL) )
	{
		UI_DEBUG("%s Arg error, from Line[%u]\n", __func__, __LINE__);
		return nRet;
	}

	for( nCrlIndex = 0; pPaperInfo->PaperUnitPPDCtrlTbl[nCrlIndex] != NULL; ++nCrlIndex )
	{

		switch( pPaperInfo->PaperUnitPPDCtrlTbl[nCrlIndex]->ctrlid )
		{
			case ID_CTRLSIZE_TEXT:
			{
				int nPos = 0;
				gboolean bEnable = FALSE;
				char* pSelectSize = NULL;
				char* pSourceCtrl = NULL;
				char* pFeedCtrl = NULL;

				pSourceCtrl = CreatePfeedUnitCtrlString( "Size_combo", pPaperInfo->pSourceStr );
				nRet = SetDrawerCtrl( gtkwidget_Pfeed,
							 pDict,
							 pPaperInfo->SizeList,
							 pPaperInfo->SizeDispList,
							 KEY_PAPER_SIZE,
							 pSourceCtrl,
							 &nPos );

				mem_free( pSourceCtrl );
				if( nRet == -1 )
				{
					break;
				}

				if( nPos > -1 )
				{
					pSelectSize = g_list_nth_data( pPaperInfo->SizeList, (unsigned int)nPos );
					bEnable = UpdatePaperFeedComboCtrl( pSelectSize, pPaperInfo->FeedPosList );
				}
				pFeedCtrl = CreatePfeedUnitCtrlString( "Feed_combo", pPaperInfo->pSourceStr );
				SetWidgetSensitive( gtkwidget_Pfeed, pFeedCtrl, bEnable );
				mem_free( pFeedCtrl );
				break;
			}
			case ID_CTRLTYPE_TEXT:
			{
				char* pSourceCtrl = NULL;

				pSourceCtrl = CreatePfeedUnitCtrlString( "Type_combo", pPaperInfo->pSourceStr );
				nRet = SetDrawerCtrl( gtkwidget_Pfeed,
							 pDict,
							 pPaperInfo->TypeList,
							 pPaperInfo->TypeDispList,
							 KEY_PAPER_TYPE,
							 pSourceCtrl,
							 NULL );
				mem_free( pSourceCtrl );
				break;
			}
			case ID_CTRLFEED_TEXT:
			{
				char* pSourceCtrl = NULL;

				pSourceCtrl = CreatePfeedUnitCtrlString( "Feed_combo", pPaperInfo->pSourceStr );
				nRet = SetDrawerCtrl( gtkwidget_Pfeed,
							 pDict,
							 pPaperInfo->FeedList,
							 pPaperInfo->FeedDispList,
							 KEY_ORIENTATION,
							 pSourceCtrl,
							 NULL );
				mem_free( pSourceCtrl );
				break;
			}
			default:
			{
				UI_DEBUG("DrawerCtrlInitSetting Source[%s] Ctrl[%d] do not add Ctrl\n", pPaperInfo->pSourceStr, pPaperInfo->PaperUnitPPDCtrlTbl[nCrlIndex]->ctrlid);
				nRet = 0;
				break;
			}
		}
		if( nRet == -1 )
		{
			break;
		}
	}

	return nRet;
}

#define PAPERSOURCESETTINGPPDNUM 3

static int InitPFeedUnitDlgWidgets( UIStatusWnd * const wnd )
{
	GtkWidget *gtkwidget_Pfeed = NULL;
	gboolean bRet = FALSE;
	int nRet = 0;
	GList* pGList = NULL;
	int i = 0;
	const char * const ctrl_type[PAPERSOURCESETTINGPPDNUM] = { "CNSUIPFeedUnitDlg", "CNSUICtrlFeedUnit", NULL };
	int nLoop = 0;
	char* pCtrlName = NULL;

	if( wnd == NULL )
	{
		UI_DEBUG("%s Augment error, from Line[%u]\n", __func__, __LINE__);
		return -1;
	}

	if( wnd->pfeedunit_dlg == NULL )
	{
		UI_DEBUG("%s Augment error, from Line[%u]\n", __func__, __LINE__);
		return -1;
	}
	else
	{
		gtkwidget_Pfeed = wnd->pfeedunit_dlg->dialog.window;
	}

	CreatePPDCtrlTbl( wnd, ctrl_type, ctrlTbl, PPDCtrlTbl );

	bRet = PFeedUnitDlgAddPPDCtrlTbl( wnd, PPDCtrlTbl );
	if( bRet == FALSE )
	{
		UI_DEBUG("%s Result fail of called PFeedUnitDlgAddPPDCtrlTbl, from Line[%u]\n", __func__, __LINE__);
		if( NULL != wnd->pfeedunit_dlg->pPaperUnitInformation )
		{
			for( nLoop = 0; nLoop < wnd->pfeedunit_dlg->nMaxSlot; nLoop++ )
			{
				DisposePaperUnitStruct( &(wnd->pfeedunit_dlg->pPaperUnitInformation[nLoop]) );
			}
			free(wnd->pfeedunit_dlg->pPaperUnitInformation);
			wnd->pfeedunit_dlg->pPaperUnitInformation = NULL;
		}
		return -1;
	}

	SetLabel_HideWidget( gtkwidget_Pfeed, PPDCtrlTbl, ctrlTbl );
	SetLabel_HideWidget( gtkwidget_Pfeed, PPDCtrlTbl, CS1CtrlTbl );
	SetLabel_HideWidget( gtkwidget_Pfeed, PPDCtrlTbl, CS1PSWCtrlTbl );
	SetLabel_HideWidget( gtkwidget_Pfeed, PPDCtrlTbl, CS2PSWCtrlTbl );
	SetLabel_HideWidget( gtkwidget_Pfeed, PPDCtrlTbl, CS3PSWCtrlTbl );
	SetLabel_HideWidget( gtkwidget_Pfeed, PPDCtrlTbl, CS4PSWCtrlTbl );
	SetLabel_HideWidget( gtkwidget_Pfeed, PPDCtrlTbl, MPTrayCtrlTbl );
	SetLabel_HideWidget( gtkwidget_Pfeed, PPDCtrlTbl, ASCtrlTbl );

	pGList = CreateGlist_DbId( PPDCtrlTbl );

	if( wnd->pfeedunit_dlg->pDialogDict != NULL )
	{
		DeleteDict( wnd->pfeedunit_dlg->pDialogDict );
		wnd->pfeedunit_dlg->pDialogDict = NULL;

	}

	wnd->pfeedunit_dlg->pDialogDict = CretateDict_GetData( pGList );
	g_list_free_wrapper(pGList);
	pGList = NULL;

	if( wnd->pfeedunit_dlg->pDialogDict == NULL )
	{
		return -1;
	}

	nRet = CommunicatePrinterData( wnd, NULL, wnd->pfeedunit_dlg->pDialogDict, CODE_COMMAND_ANALYZE, TRUE );
	if( nRet != 0 )
	{
		return -1;
	}

	for( i = 0; PPDCtrlTbl[i] != NULL; i++ )
	{
		switch( PPDCtrlTbl[i]->dbid )
		{
			case ID954:
			case ID1664:
			case ID1674:
			case ID1684:
			case ID1694:
			case ID974:
			{
				Dict* pDict = NULL;
				PaperUnitInformation* paperUnitInfomation = NULL;

				pDict = GetItemValueType_dict( wnd->pfeedunit_dlg->pDialogDict, PPDCtrlTbl[i]->dbid );
				if( pDict == NULL )
				{
					nRet = -1;
					UI_DEBUG("InitPFeedUnitDlgWidgets %d get value error \n", PPDCtrlTbl[i]->dbid);
					break;
				}

				for( nLoop = 0; nLoop < (sizeof( paperUnitInfomationTbl ) / sizeof( paperUnitInfomationTbl[0] )); nLoop++ )
				{
					if( PPDCtrlTbl[i]->dbid == paperUnitInfomationTbl[nLoop].nDBID )
					{
						paperUnitInfomation = &(wnd->pfeedunit_dlg->pPaperUnitInformation[paperUnitInfomationTbl[nLoop].nIdx]);
						break;
					}
				}

				if(NULL != paperUnitInfomation)
				{
					nRet = DrawerCtrlInitSetting( gtkwidget_Pfeed, paperUnitInfomation, pDict);
				}

				break;
			}
			case ID852:
			case ID812:
			case ID822:
			case ID832:
			case ID1192:
			case ID1202:
			{
				int nValue = 0;
				pCtrlName = NULL;
				for( nLoop = 0; nLoop < (sizeof( checkBox_IDs ) / sizeof( checkBox_IDs[0] )); nLoop++ )
				{
					if( PPDCtrlTbl[i]->dbid == checkBox_IDs[nLoop].nDbID )
					{
						pCtrlName = checkBox_IDs[nLoop].pCtrlName;
						break;
					}
				}

				if( NULL != pCtrlName )
				{
					nRet = GetItemValueType_int( wnd->pfeedunit_dlg->pDialogDict, PPDCtrlTbl[i]->dbid, &nValue );
					if( nRet == -1 )
					{
						UI_DEBUG("InitPFeedUnitDlgWidgets %d get value error \n", PPDCtrlTbl[i]->dbid);
						break;
					}
					SetActiveCheckButton( gtkwidget_Pfeed, pCtrlName, nValue, FALSE );
				}
				nRet = 0;
				break;
			}
			default:
			{
				UI_DEBUG("InitPFeedUnitDlgWidgets Ctrl[%d] do not have DB ID\n", PPDCtrlTbl[i]->ctrlid);
				break;
			}
		}

		if( nRet != 0 )
		{
			UI_DEBUG("InitPFeedUnitDlgWidgets init control error %d \n", nRet);
			break;
		}
	}
	return nRet;
}

static void DisposePaperUnitStruct( PaperUnitInformation* const pPaperInfo )
{
	if( pPaperInfo == NULL )
	{
		return;
	}
	if( pPaperInfo->SizeList != NULL )
	{
		g_list_foreach(pPaperInfo->SizeList, (GFunc)mem_free, NULL );
		g_list_free_wrapper(pPaperInfo->SizeList);
		pPaperInfo->SizeList = NULL;
	}

	if( pPaperInfo->SizeDispList != NULL )
	{
		g_list_foreach(pPaperInfo->SizeDispList, (GFunc)mem_free, NULL );
		g_list_free_wrapper(pPaperInfo->SizeDispList);
		pPaperInfo->SizeDispList = NULL;
	}

	if( pPaperInfo->TypeList != NULL )
	{
		g_list_foreach(pPaperInfo->TypeList, (GFunc)mem_free, NULL );
		g_list_free_wrapper(pPaperInfo->TypeList);
		pPaperInfo->TypeList = NULL;
	}

	if( pPaperInfo->TypeDispList != NULL )
	{
		g_list_foreach(pPaperInfo->TypeDispList, (GFunc)mem_free, NULL );
		g_list_free_wrapper(pPaperInfo->TypeDispList);
		pPaperInfo->TypeDispList = NULL;
	}

	if( pPaperInfo->FeedList != NULL )
	{
		g_list_foreach(pPaperInfo->FeedList, (GFunc)mem_free, NULL );
		g_list_free_wrapper(pPaperInfo->FeedList);
		pPaperInfo->FeedList = NULL;
	}

	if( pPaperInfo->FeedDispList != NULL )
	{
		g_list_foreach(pPaperInfo->FeedDispList, (GFunc)mem_free, NULL );
		g_list_free_wrapper(pPaperInfo->FeedDispList);
		pPaperInfo->FeedDispList = NULL;
	}

	if( pPaperInfo->FeedPosList != NULL )
	{
		g_list_foreach(pPaperInfo->FeedPosList, (GFunc)mem_free, NULL );
		g_list_free_wrapper(pPaperInfo->FeedPosList);
		pPaperInfo->FeedPosList = NULL;
	}
	if( pPaperInfo->FeedPosHorList != NULL )
	{
		g_list_foreach(pPaperInfo->FeedPosHorList, (GFunc)mem_free, NULL );
		g_list_free_wrapper(pPaperInfo->FeedPosHorList);
		pPaperInfo->FeedPosHorList = NULL;
	}
}

void DisposePFeedUnitDlg( UIStatusWnd* const wnd )
{
	UIPfeedUnitDlg * ui_pfeedunit_dlg = NULL;
	int nLoop = 0;

	if(wnd == NULL)
	{
		return;
	}

	ui_pfeedunit_dlg = wnd->pfeedunit_dlg;
	if( ui_pfeedunit_dlg != NULL)
	{
		if( ui_pfeedunit_dlg->pDialogDict != NULL )
		{
			DeleteDict( ui_pfeedunit_dlg->pDialogDict );
			ui_pfeedunit_dlg->pDialogDict = NULL;
		}
		if( NULL != wnd->pfeedunit_dlg->pPaperUnitInformation)
		{
			for( nLoop = 0; nLoop < wnd->pfeedunit_dlg->nMaxSlot; nLoop++ )
			{
				DisposePaperUnitStruct( &(wnd->pfeedunit_dlg->pPaperUnitInformation[nLoop]) );
			}
			free(wnd->pfeedunit_dlg->pPaperUnitInformation);
			wnd->pfeedunit_dlg->pPaperUnitInformation = NULL;
		}
		DisposeDialog( (UIDialog *)ui_pfeedunit_dlg );
		wnd->pfeedunit_dlg = NULL;
	}
}

