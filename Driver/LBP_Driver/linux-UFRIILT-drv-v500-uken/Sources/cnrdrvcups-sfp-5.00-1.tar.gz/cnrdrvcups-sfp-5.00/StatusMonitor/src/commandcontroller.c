/*
 *  Status monitor for Canon NCAP Printer.
 *  Copyright (C) 2004-2013 CANON INC.
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#include "commandcontroller.h"
#include "pksmncapcontroller.h"
#include "key_defines.h"
#include "value_defines.h"
#include "id_defines.h"
#include "buftool.h"
#include "cmdsendretry.h"
#include "widgets.h"

#define GET_ITEMIDDATATYPE(id) ((id) % 10)

static Mngpksmncap* GetMngpksmncap( const UIStatusWnd* const wnd );
static int CreateCommData( const UIStatusWnd* const wnd );
static int MakePrinterComData( const UIStatusWnd* const wnd, const int nType, const int nIndex, char* const pData, const long lDataSize, const char* const pKeyName, char* const pEncoding );
static int MakeSendData( const UIStatusWnd* const wnd );
static int ReadPrinterComData( const UIStatusWnd* const wnd, const int nType, const int nIndex, const char* const pKeyName, char* const pEncoding, BufTool** const ppData, int* const pDataSize );
static void DestroyCommData( const UIStatusWnd* const wnd );
static int MakeDataType_IntCommon( const UIStatusWnd* const wnd, const int type, const int value, const char * const pKeyName );
static int MakeDataType_Int( const UIStatusWnd* const wnd, const Dict* const dict, const gboolean bTypeA );
static int MakeDataType_StringCommon( const UIStatusWnd* const wnd, const int type, char* const value, const char* const pKeyName );
static int MakeDataType_String( const UIStatusWnd* const wnd, const Dict* const dict, const gboolean bTypeA );
static int ReadDataType_IntCommon( const UIStatusWnd* const wnd, const char* const pKeyName, int* const pData, const int nType, const int nIndex );
static int ReadDataType_StringCommon( const UIStatusWnd* const wnd, const char* const pKeyName, char** const pData, const int nType, const int nIndex );
static int ReadDataType_ArrayValue( const UIStatusWnd* const wnd, const char* const pKeyName, GList** const pList, const int nType );
static int ReadDataType_valueToGList( const UIStatusWnd* const wnd, const char* const pKeyName, GList** const pList, const int nType );

static int CreateSendData_SetData_Item( const UIStatusWnd* const wnd, Dict* const dict );
static Dict* GetItemValue_GetItemValueDict( Dict* const dict, const int nID );
static int CreateSendData_MakeDataCommon( const UIStatusWnd* const wnd, const Dict* const dict, const gboolean bTypeA );
static void GFunc_push_IDList( gpointer data, gpointer user_data );
static Dict* CreateDict_ReadDataAndMakeDict( const UIStatusWnd* const wnd, Dict* const dict, const char* const pKeyName, const int nType );
static int CreateDict_GetData_PaperInfo( const UIStatusWnd* const wnd, Dict* const dict );
static int CreateDict_GetData_ItemValue( const UIStatusWnd* const wnd, Dict* const dict );
static int GetStatus_NetWorkError( Dict* const dict );
static int GetStatus_LocalCommError( Dict* const dict );
static int GetStatus_PausePrinter( Dict* const dict );
static int GetStatus_ErrorCommunicate( Dict* const dict, const int nError );
static Dict* GetStatus_MakeModelCode( const UIStatusWnd* const wnd, Dict* const dict );
static int GetStatus_ErrorDeviceResponse( const UIStatusWnd* const wnd, Dict* const dict, const int nError );
static int GetStatus_Analyze_CommonPaperInfo( const UIStatusWnd* const wnd, Dict* const dict, const char* const pKey );
static int GetStatus_Analyze_PaperInfoList( const UIStatusWnd* const wnd, Dict* const dict );
static int GetStatus_Analyze_PaperError( const UIStatusWnd* const wnd, Dict* const dict );
static int GetStatus_Analyze_ServiceError( const UIStatusWnd* const wnd, Dict* const dict );
static int GetStatus_AnalyzeStatus( const UIStatusWnd* const wnd, Dict* const dict );
static int CreateSendData_GetData( const UIStatusWnd* const wnd, const Dict* const dict );
static int CreateSendData_SetData( const UIStatusWnd* const wnd, Dict* const dict );
static int CreateSendData_Common( const UIStatusWnd* const wnd, Dict* const dict );
static int CreateDict_GetDataResponsData( const UIStatusWnd* const wnd, const Dict* const dict );
static int CreateDict_GetConsumableResponsData( const UIStatusWnd* const wnd, Dict* const dict );
static int CreateDict_GetStatusResponsData( const UIStatusWnd* const wnd, Dict* const dict );
static int CheckResponsData_SetData( const UIStatusWnd* const wnd, Dict* const dict );
static int CheckResponsData_Common( const UIStatusWnd* const wnd, const Dict* const dict, int* const pError );

Dict* CretateDict_GetData( GList* const IDList )
{
	Dict* pCommandDict = NULL;
	Dict* retDict = NULL;
	int nCommand = COMMAND_GET_DATA;

	if( IDList == NULL )
	{
		return NULL;
	}

	pCommandDict = CreateDict_Number_Value(NULL, KEY_COMMAND, &nCommand);
	if( pCommandDict != NULL )
	{
		GList* ItemList = NULL;
		unsigned int nIndex = 0;

		for( nIndex = 0; nIndex < g_list_length(IDList); ++nIndex )
		{
			int* pnID = NULL;
			Dict* ItemDict = NULL;

			pnID = (int*)g_list_nth_data(IDList, nIndex);
			ItemDict = CreateDict_Number_Value(NULL, KEY_ID, pnID);
			if( ItemDict != NULL )
			{
				ItemList = g_list_append_wrapper(ItemList, (gpointer)ItemDict, __FILE__, __LINE__);
			}
		}

		retDict = CreateDict(pCommandDict, KEY_ITEM_LIST, DICT_TYPE_DICT, ItemList);
		if( retDict == NULL )
		{
			DeleteDict(pCommandDict);
		}
		g_list_free_wrapper(ItemList);
	}
	return retDict;
}

static
Dict* GetItemValue_GetItemValueDict( Dict* const dict, const int nID )
{
	Dict* retDict = NULL;
	Dict* KeyItemDict = NULL;
	GList* ValueList = NULL;
	unsigned int nIndex = 0;

	if( dict == NULL )
	{
		return NULL;
	}

	KeyItemDict = GetDict_forkey(dict, KEY_ITEM_LIST);
	if( KeyItemDict == NULL )
	{
		return NULL;
	}

	ValueList = KeyItemDict->value;
	if( ValueList == NULL )
	{
		return NULL;
	}

	for( nIndex = 0; nIndex < g_list_length(ValueList); ++nIndex )
	{
		Dict* IDDict = (Dict*)g_list_nth_data(ValueList, nIndex);
		if( IDDict != NULL )
		{
			int nTempID = 0;

			if( GetDictValuetype_int(IDDict, &nTempID) != FALSE )
			{
				if( nTempID == nID )
				{
					retDict = IDDict->next;
					break;
				}
			}
		}
	}

	return retDict;
}

int GetItemValueType_int( Dict* const GetDataDict, const int nID, int* const pValue )
{
	int nRet = -1;
	Dict* ItemDict = NULL;

	if( (GetDataDict == NULL) || (pValue == NULL) )
	{
		return nRet;
	}

	ItemDict = GetItemValue_GetItemValueDict(GetDataDict, nID);
	if( ItemDict != NULL )
	{
		if( GetDictValuetype_int(ItemDict, pValue) != FALSE )
		{
			nRet = 0;
		}
	}

	return nRet;
}

const char* GetItemValueType_char( Dict* const GetDataDict, const int nID )
{
	const char* pValue = NULL;

	if( GetDataDict != NULL )
	{
		Dict* ItemDict = NULL;

		ItemDict = GetItemValue_GetItemValueDict(GetDataDict, nID);
		if( ItemDict != NULL )
		{
			pValue = GetDictValuetype_char(ItemDict);
		}
	}

	return pValue;
}

Dict* GetItemValueType_dict( Dict* const GetDataDict, const int nID )
{
	Dict* pValue = NULL;

	if( GetDataDict == NULL )
	{
		return NULL;
	}

	pValue = GetItemValue_GetItemValueDict(GetDataDict, nID);

	return pValue;
}


Dict* GetPaperInfoDict(Dict* const statusDict, const char* const paperSource)
{
	GList* glValue = NULL;
	Dict* dictValue = NULL;
	const char* dictPaperSouce = NULL;

	if( (statusDict == NULL) || (paperSource == NULL) )
	{
		return NULL;
	}

	glValue = GetDictValueGList_forKey(statusDict, KEY_PAPER_LIST);
	while(glValue != NULL)
	{
		dictPaperSouce = GetDictValueString_forKey((Dict*)glValue->data, KEY_PAPER_SOURCE);
		if(dictPaperSouce != NULL)
		{
			if( strcmp(dictPaperSouce, paperSource) == 0 )
			{
				dictValue = (Dict*)glValue->data;
				break;
			}
		}
		glValue = g_list_next(glValue);
	}

	return dictValue;
}

int CreateDict_SetData( Dict* const dict )
{
	Dict* SetDataDict = NULL;
	int nRet = -1;

	if( dict == NULL )
	{
		return nRet;
	}

	SetDataDict = GetDict_forkey(dict, KEY_COMMAND);
	if( SetDataDict != NULL )
	{
		unsigned int nSetRet = DICT_SET_RETURN_ERROR;
		nSetRet = SetDictValuetype_int(SetDataDict, COMMAND_SET_DATA);
		if( nSetRet == DICT_SET_RETURN_CHANGE )
		{
			nRet = 0;
		}
	}

	return nRet;
}

unsigned int SetItemValuetype_int( Dict* const SetDataDict, const int nID, const int Value )
{
	Dict* ItemDict = NULL;
	unsigned int nRet = DICT_SET_RETURN_ERROR;

	if( SetDataDict == NULL )
	{
		return nRet;
	}

	ItemDict = GetItemValue_GetItemValueDict(SetDataDict, nID);
	if( ItemDict != NULL )
	{
		nRet = SetDictValuetype_int(ItemDict, Value);
	}

	return nRet;
}

unsigned int SetItemValuetype_char(Dict* const SetDataDict, const int nID, const char* const Value)
{
	unsigned int nRet = DICT_SET_RETURN_ERROR;

	if(( SetDataDict != NULL ) && ( Value != NULL ))
	{
		Dict* ItemDict = NULL;

		ItemDict = GetItemValue_GetItemValueDict(SetDataDict, nID);
		if( ItemDict != NULL )
		{
			nRet = SetDictValuetype_char(ItemDict, Value);
		}
	}

	return nRet;
}

int SetData_ItemDelete( Dict* const SetDataDict, const int nID )
{
	Dict* ItemDict = NULL;
	int nRet = -1;

	if( SetDataDict == NULL )
	{
		return -1;
	}

	ItemDict = GetDict_forkey(SetDataDict, KEY_ITEM_LIST);
	if( ItemDict != NULL )
	{
		GList* gItemList = NULL;

		gItemList = ItemDict->value;
		if( gItemList != NULL )
		{
			unsigned int nIndex = 0;
			Dict* IdDict = NULL;
			gboolean bFind = FALSE;
			UI_DEBUG("SetData_ItemDelete gItemList[%p]\n", gItemList);
			for( nIndex = 0; nIndex < g_list_length( gItemList ); ++nIndex )
			{
				IdDict = g_list_nth_data( gItemList, nIndex );
				if( IdDict != NULL )
				{
					int nValueID = 0;
					if( GetDictValuetype_int( IdDict, &nValueID ) != FALSE )
					{
						if( nID == nValueID )
						{
							bFind = TRUE;
							break;
						}
					}
				}
				UI_DEBUG("SetData_ItemDelete gItemList[%d] data[%p]\n", nIndex, g_list_nth_data(gItemList, nIndex ));
			}

			if( bFind != FALSE )
			{
				ItemDict->value = g_list_remove( gItemList, (gpointer)IdDict );
				DeleteDict( IdDict );
				UI_DEBUG("SetData_ItemDelete ItemDict->value[%p]\n", ItemDict->value);
				nRet = 0;
			}
		}
	}
	return nRet;
}

Dict* CreateDict_DeviceOperation( int nOperation )
{
	Dict* pCommandDict = NULL;
	int nCommand = COMMAND_DEVICE_OPERATION;

	pCommandDict = CreateDict_Number_Value(NULL, KEY_COMMAND, &nCommand);
	if( pCommandDict != NULL )
	{
		pCommandDict = CreateDict_Number_Value(pCommandDict, KEY_OPERATION, &nOperation);
	}
	return pCommandDict;
}

Dict* CreateDict_DeviceOperationIntParam( int nOperation, int nParam )
{
	Dict* pCommandDict = NULL;

	pCommandDict = CreateDict_DeviceOperation(nOperation);
	if( pCommandDict != NULL )
	{
		pCommandDict = CreateDict_Number_Value(pCommandDict, KEY_PARAM, &nParam);
	}
	return pCommandDict;
}

Dict* CreateDict_JobOperation( int nOperation, int nJobID )
{
	Dict* pCommandDict = NULL;
	int nCommand = COMMAND_JOB_OPERATION;

	pCommandDict = CreateDict_Number_Value(NULL, KEY_COMMAND, &nCommand);
	if( pCommandDict != NULL )
	{
		pCommandDict = CreateDict_Number_Value(pCommandDict, KEY_OPERATION, &nOperation);
		if( pCommandDict != NULL )
		{
			pCommandDict = CreateDict_Number_Value(pCommandDict, KEY_JOB_ID, &nJobID);
		}

	}
	return pCommandDict;
}

Dict* CreateDict_GetConsumable()
{
	Dict* pCommandDict = NULL;
	int nCommand = COMMAND_GET_CONSUMABLE_STATUS;

	pCommandDict = CreateDict_Number_Value(NULL, KEY_COMMAND, &nCommand);
	return pCommandDict;
}

Dict* CreateDict_GetStatus(const GetAreaInfoType getAreaInfo)
{
	Dict* pCommandDict = NULL;
	int nCommand = COMMAND_GET_STATUS;

	pCommandDict = CreateDict_Number_Value(NULL, KEY_COMMAND, &nCommand);
	if( pCommandDict != NULL )
	{
		int nGetAreaInfo = (int)getAreaInfo;

		pCommandDict = CreateDict_Number_Value(pCommandDict, KEY_GETAREAINFO, &nGetAreaInfo);
	}
	return pCommandDict;
}

static Mngpksmncap* GetMngpksmncap( const UIStatusWnd* const wnd )
{
	if( wnd == NULL )
	{
		return NULL;
	}

	return wnd->pMngpksmncap;
}

static int CreateCommData( const UIStatusWnd* const wnd )
{
	int nRet = COMM_HOST_ERROR;
	Mngpksmncap* pMngpksm = NULL;
	int nDriverPathLen = 0;

	if( wnd == NULL )
	{
		return nRet;
	}

	pMngpksm = GetMngpksmncap(wnd);
	if( pMngpksm == NULL )
	{
		return nRet;
	}
	nDriverPathLen = (int)strlen(wnd->pDriverPath);
	nRet = pksmncapWrite(pMngpksm->cmd_fd, PKSM_ID_CREATECOMMDATA, wnd->pDriverPath, nDriverPathLen);
	if( nRet == COMM_HOST_NO_ERROR )
	{
		nRet = pksmncapRead(pMngpksm->res_fd, PKSM_ID_CREATECOMMDATA, NULL, NULL);
	}
	return nRet;
}

#define MAKE_PRINTER_COMDATA_DEFAULTSIZE sizeof(int) + sizeof(int) + sizeof(int) + sizeof(int)  + sizeof(int)

static int MakePrinterComData( const UIStatusWnd* const wnd, const int nType, const int nIndex, char* const pData, const long lDataSize, const char* const pKeyName, char* const pEncoding )
{
	int nRet = COMM_HOST_ERROR;
	Mngpksmncap* pMngpksm = NULL;
	unsigned int nSize = 0;
	BufTool* buftool = NULL;

	pMngpksm = GetMngpksmncap(wnd);
	if( pMngpksm == NULL )
	{
		return nRet;
	}

	nSize = MAKE_PRINTER_COMDATA_DEFAULTSIZE;
	if( pData != NULL )
	{
		nSize += strlen(pData);
	}

	if( pKeyName != NULL )
	{
		nSize += strlen(pKeyName);
	}

	if( pEncoding != NULL )
	{
		nSize += strlen(pEncoding);
	}

	buftool = buftool_new((int)nSize, BUFTOOL_LITTLE_ENDIAN);
	if( buftool == NULL )
	{
		return nRet;
	}

	buftool_write_long(buftool, nType);
	buftool_write_long(buftool, nIndex);
	if( pData != NULL )
	{
		buftool_write_long(buftool, lDataSize);
		buftool_write(buftool, pData, (int)lDataSize);
	}
	else
	{
		buftool_write_long(buftool, 0);
	}

	if( pKeyName != NULL )
	{
		const unsigned int nKeyNameLen = strlen(pKeyName);
		buftool_write_long(buftool, (long)nKeyNameLen);
		buftool_write_string_Wrapper(buftool, pKeyName, (int)nKeyNameLen);
	}
	else
	{
		buftool_write_long(buftool, 0);
	}

	if( pEncoding != NULL )
	{
		const unsigned int nEncodingLen = strlen(pEncoding);
		buftool_write_long(buftool, (long)nEncodingLen);
		buftool_write(buftool, pEncoding, (int)nEncodingLen);
	}
	else
	{
		buftool_write_long(buftool, 0);
	}

	char* const pBuftoolData = (char*)buftool_data(buftool);
	const int nBuftoolSize = buftool_size(buftool);
	nRet = pksmncapWrite(pMngpksm->cmd_fd, PKSM_ID_MAKECOMMDATA, pBuftoolData, nBuftoolSize);
	if( nRet == COMM_HOST_NO_ERROR )
	{
		nRet = pksmncapRead(pMngpksm->res_fd, PKSM_ID_MAKECOMMDATA, NULL, NULL);
	}
	buftool_destroy(buftool);

	return nRet;
}

static int MakeSendData( const UIStatusWnd* const wnd )
{
	int nRet = COMM_HOST_ERROR;
	Mngpksmncap* pMngpksm = NULL;

	pMngpksm = GetMngpksmncap(wnd);
	if( pMngpksm == NULL )
	{
		return nRet;
	}

	nRet = pksmncapWrite(pMngpksm->cmd_fd, PKSM_ID_MAKESENDDATA, NULL, 0);
	if( nRet == COMM_HOST_NO_ERROR )
	{
		nRet = pksmncapRead(pMngpksm->res_fd, PKSM_ID_MAKESENDDATA, NULL, NULL);
	}
	return nRet;
}

int SendData( const UIStatusWnd* const wnd, const int nCode, const gboolean bRetry )
{
	int nRet = COMM_HOST_ERROR;
	Mngpksmncap* pMngpksm = NULL;
	unsigned int nSize = 0;
	BufTool* buftool = NULL;

	if( wnd == NULL )
	{
		return nRet;
	}

	pMngpksm = GetMngpksmncap(wnd);
	if( pMngpksm == NULL )
	{
		return nRet;
	}

	nSize = sizeof(nCode) + sizeof(wnd->nPortNum) + sizeof(char) + sizeof(int) + sizeof(int)  + sizeof(int) + sizeof(int) + sizeof(int) + strlen(wnd->locale) + strlen(wnd->pPrinterName)+ strlen(wnd->pDriverPath) + strlen(wnd->pPDLType);
	buftool = buftool_new((int)nSize, BUFTOOL_LITTLE_ENDIAN);
	if( buftool == NULL )
	{
		return nRet;
	}

	const unsigned int nLocaleLen = strlen(wnd->locale);
	const unsigned int nPrinterNameLen = strlen(wnd->pPrinterName);
	const unsigned int nDriverPathLen = strlen(wnd->pDriverPath);
	const unsigned int nPDLTypeLen = strlen(wnd->pPDLType);
	char* const pBuftoolData = (char*)buftool_data(buftool);
	const int nBuftoolSize = buftool_size(buftool);

	buftool_write_long(buftool, nCode);
	buftool_write_long(buftool, wnd->nPortNum);
	buftool_write_byte(buftool, bRetry);
	buftool_write_long(buftool, wnd->nMaxUSBRetrySec);
	buftool_write_long(buftool, (long)nLocaleLen);
	buftool_write(buftool, wnd->locale, (int)nLocaleLen);
	buftool_write_long(buftool, (long)nPrinterNameLen);
	buftool_write(buftool, wnd->pPrinterName, (int)nPrinterNameLen);
	buftool_write_long(buftool, (long)nDriverPathLen);
	buftool_write(buftool, wnd->pDriverPath, (int)nDriverPathLen);
	buftool_write_long(buftool, (long)nPDLTypeLen);
	buftool_write(buftool, wnd->pPDLType, (int)nPDLTypeLen);

	nRet = pksmncapWrite(pMngpksm->cmd_fd, PKSM_ID_SENDDATA_WITH_PDLTYPE, pBuftoolData, nBuftoolSize);
	if( nRet == COMM_HOST_NO_ERROR )
	{
		nRet = pksmncapRead(pMngpksm->res_fd, PKSM_ID_SENDDATA_WITH_PDLTYPE, NULL, NULL);
	}
	buftool_destroy(buftool);
	return nRet;
}

static int ReadPrinterComData( const UIStatusWnd* const wnd, const int nType, const int nIndex, const char* const pKeyName, char* const pEncoding, BufTool** const ppData, int* const pDataSize )
{
	int nRet = COMM_HOST_ERROR;
	Mngpksmncap* pMngpksm = NULL;
	unsigned int nSize = 0;
	BufTool* buftool = NULL;

	pMngpksm = GetMngpksmncap(wnd);
	if( pMngpksm == NULL )
	{
		return nRet;
	}

	nSize = sizeof(int) + sizeof(int) + sizeof(int) + sizeof(int);
	if( pKeyName != NULL )
	{
		nSize += strlen(pKeyName);
	}

	if( pEncoding != NULL )
	{
		nSize += strlen(pEncoding);
	}

	buftool = buftool_new((int)nSize, BUFTOOL_LITTLE_ENDIAN);
	if( buftool == NULL )
	{
		return nRet;
	}

	buftool_write_long(buftool, nType);
	buftool_write_long(buftool, nIndex);
	if( pKeyName != NULL )
	{
		const unsigned int nKeyNameLen = strlen(pKeyName);
		buftool_write_long(buftool, (long)nKeyNameLen);
		buftool_write_string_Wrapper(buftool, pKeyName, (int)nKeyNameLen);
	}
	else
	{
		buftool_write_long(buftool, 0);
	}

	if( pEncoding != NULL )
	{
		const unsigned int nEncodingLen = strlen(pEncoding);
		buftool_write_long(buftool, (long)nEncodingLen);
		buftool_write(buftool, pEncoding, (int)nEncodingLen);
	}
	else
	{
		buftool_write_long(buftool, 0);
	}

	char* const pBuftoolData = (char*)buftool_data(buftool);
	const int nBuftoolSize = buftool_size(buftool);
	nRet = pksmncapWrite(pMngpksm->cmd_fd, PKSM_ID_READCOMMDATA, pBuftoolData,nBuftoolSize);
	if( nRet == COMM_HOST_NO_ERROR )
	{
		char* pData = NULL;

		nRet = pksmncapRead(pMngpksm->res_fd, PKSM_ID_READCOMMDATA, pDataSize, &pData);
		if( nRet == COMM_HOST_NO_ERROR )
		{
			if( (pDataSize != NULL) && (pData != NULL) && (ppData != NULL) )
			{
				*ppData = buftool_new(*pDataSize, BUFTOOL_LITTLE_ENDIAN);
				if( *ppData != NULL )
				{
					buftool_write(*ppData, pData, *pDataSize);
					buftool_set_pos(*ppData, 0);
				}
			}
			if( pData != NULL )
			{
				mem_free(pData);
			}
		}
	}
	buftool_destroy(buftool);
	return nRet;
}

static void DestroyCommData( const UIStatusWnd* const wnd )
{
	int nRet = COMM_HOST_ERROR;
	Mngpksmncap* pMngpksm = NULL;

	pMngpksm = GetMngpksmncap(wnd);
	if( pMngpksm == NULL )
	{
		return;
	}

	nRet = pksmncapWrite(pMngpksm->cmd_fd, PKSM_ID_DESTROYCOMMDATA, NULL, 0);
	if( nRet == COMM_HOST_NO_ERROR )
	{
		pksmncapRead(pMngpksm->res_fd, PKSM_ID_DESTROYCOMMDATA, NULL, NULL);
	}
	return;
}

int CommunicatePrinterData( UIStatusWnd* const wnd, UIDialog* const parent, Dict* const dict, const int code, const gboolean bRetry )
{
	return CommunicatePrinterDataAndControlMsgDlg( wnd, parent, dict, code, ID_USBWAIT_MSGDLG1, bRetry );
}

int CommunicatePrinterDataAndControlMsgDlg( UIStatusWnd* const wnd, UIDialog* const parent, Dict* const dict, const int code, const int msgId, const gboolean bRetry )
{
	Dict* CmdDict = NULL;
	int nCommRet = COMM_HOST_ERROR;
	int nCommand = 0;

	if( dict == NULL )
	{
		return nCommRet;
	}

	CmdDict = GetDict_forkey(dict, KEY_COMMAND);
	if( CmdDict == NULL )
	{
		return nCommRet;
	}

	if( GetDictValuetype_int(CmdDict, &nCommand) == FALSE )
	{
		return nCommRet;
	}
	EnterCriticalSection(&g_CommuticateSection);
	UI_DEBUG("%s EnterCriticalSection Command[%d], from Line[%u] \n", __func__, nCommand, __LINE__);

	nCommRet = CreateCommData(wnd);
	if( nCommRet != COMM_HOST_NO_ERROR )
	{
		LeaveCriticalSection(&g_CommuticateSection);
		UI_DEBUG("%s CreateCommData error[%d], from Line[%u] \n", __func__, nCommRet, __LINE__);
		return nCommRet;
	}

	switch( nCommand )
	{
		case COMMAND_GET_STATUS:
		case COMMAND_GET_CONSUMABLE_STATUS:
		case COMMAND_JOB_OPERATION:
		case COMMAND_DEVICE_OPERATION:
		{
			nCommRet = CreateSendData_Common(wnd, dict);
			break;
		}
		case COMMAND_GET_DATA:
		{
			nCommRet = CreateSendData_GetData(wnd, dict);
			break;
		}
		case COMMAND_SET_DATA:
		{
			nCommRet = CreateSendData_SetData(wnd, dict);
			break;
		}
		default:
			UI_DEBUG("%s Command value unknown, from Line[%u] \n", __func__, __LINE__);
			nCommRet = COMM_HOST_ERROR;
			break;
	}

	if( nCommRet == COMM_HOST_NO_ERROR )
	{
		nCommRet = MakeSendData(wnd);
	}

	if( nCommRet == COMM_HOST_NO_ERROR )
	{
		nCommRet = SendData(wnd, code, FALSE);
		if( ( nCommRet == COMM_HOST_ERROR_USB_RETRY ) &&
			( bRetry == TRUE ) )
		{
			 nCommRet = cmdSendRetry( wnd, parent, code, msgId );
		}
	}

	if( nCommRet == COMM_HOST_NO_ERROR )
	{
		switch( nCommand )
		{
			case COMMAND_GET_STATUS:
			{
				nCommRet = CreateDict_GetStatusResponsData(wnd, dict);
				break;
			}
			case COMMAND_GET_CONSUMABLE_STATUS:
			{
				nCommRet = CreateDict_GetConsumableResponsData(wnd, dict);
				break;
			}
			case COMMAND_JOB_OPERATION:
			case COMMAND_DEVICE_OPERATION:
			{
				nCommRet = CheckResponsData_Common(wnd, dict, NULL);
				break;
			}
			case COMMAND_GET_DATA:
			{
				nCommRet = CreateDict_GetDataResponsData(wnd, dict);

				break;
			}
			case COMMAND_SET_DATA:
			{
				nCommRet = CheckResponsData_SetData(wnd, dict);
				break;
			}
			default:
				UI_DEBUG("%s Command value unknown, from Line[%u] \n", __func__, __LINE__);
				nCommRet = COMM_HOST_ERROR;
				break;
		}
	}
	else
	{
		if( nCommand == COMMAND_GET_STATUS )
		{
			nCommRet = GetStatus_ErrorCommunicate(dict, nCommRet);
		}
		UI_DEBUG("%s SendData error[%d], from Line[%u] \n", __func__, nCommRet, __LINE__);
	}

	DestroyCommData(wnd);

	if( nCommRet != COMM_HOST_NO_ERROR )
	{
		UI_DEBUG("%s error nCommRet[%d], from Line[%u] \n", __func__, nCommRet, __LINE__);
		nCommRet = COMM_HOST_ERROR;
	}

	UI_DEBUG("%s LeaveCriticalSection Command[%d], from Line[%u] \n", __func__, nCommand, __LINE__);
	LeaveCriticalSection(&g_CommuticateSection);

	return nCommRet;
}

static int MakeDataType_IntCommon( const UIStatusWnd* const wnd, const int type, const int value, const char* const pKeyName )
{
	int nRet = COMM_HOST_ERROR;
	BufTool* buftool = NULL;

	buftool = buftool_new((int)sizeof(int), BUFTOOL_LITTLE_ENDIAN);
	if( buftool == NULL )
	{
		return nRet;
	}

	char* const pBuftoolData = (char*)buftool_data(buftool);
	const int nBuftoolSize = buftool_size(buftool);
	buftool_write_long(buftool, value);
	nRet = MakePrinterComData(wnd, type, 0, pBuftoolData, nBuftoolSize, pKeyName, NULL);
	buftool_destroy(buftool);

	return nRet;
}

static int MakeDataType_Int( const UIStatusWnd* const wnd, const Dict* const dict, const gboolean bTypeA )
{
	int nRet = COMM_HOST_ERROR;

	if( dict == NULL )
	{
		return nRet;
	}

	if( bTypeA != FALSE )
	{
		GList* pList = NULL;

		pList = dict->value;
		if( pList != NULL )
		{
			nRet = MakePrinterComData(wnd, DATATYPE_A_OP, 0, NULL, 0, dict->pKeyName, NULL);
			if( nRet == COMM_HOST_NO_ERROR )
			{
				while( pList != NULL )
				{
					int nValue = *(int*)(pList->data);

					nRet = MakeDataType_IntCommon(wnd, DATATYPE_A_L, nValue, NULL);
					if( nRet != COMM_HOST_NO_ERROR )
					{
						break;
					}
					pList = g_list_next(pList);
				}

				if( nRet == COMM_HOST_NO_ERROR )
				{
					nRet = MakePrinterComData(wnd, DATATYPE_A_CL, 0, NULL, 0, NULL, NULL);
				}
			}
		}
	}
	else
	{
		int nValue = 0;

		if( GetDictValuetype_int(dict, &nValue) == FALSE )
		{
			nRet = COMM_HOST_ERROR;
		}
		else {
			nRet = MakeDataType_IntCommon(wnd, DATATYPE_L, nValue, dict->pKeyName);
		}
	}

	return nRet;
}

static int MakeDataType_StringCommon( const UIStatusWnd* const wnd, const int type, char* const value, const char * const pKeyName )
{
	int nRet = COMM_HOST_ERROR;
	BufTool* buftool = NULL;
	unsigned int nValueLen = 0;

	if( (wnd == NULL) || (value == NULL) )
	{
		return nRet;
	}

	nValueLen = strlen(value) + NULL_CHAR_SIZE;

	buftool = buftool_new((int)nValueLen, BUFTOOL_LITTLE_ENDIAN);
	if( buftool == NULL )
	{
		return nRet;
	}

	char* const pBuftoolData = (char*)buftool_data(buftool);
	const int nBuftoolSize = buftool_size(buftool);

	buftool_write(buftool, value, (int)nValueLen);
	nRet = MakePrinterComData(wnd, type, 0, pBuftoolData, nBuftoolSize, pKeyName, wnd->encoding);
	buftool_destroy(buftool);

	return nRet;
}

static int MakeDataType_String( const UIStatusWnd* const wnd, const Dict* const dict, const gboolean bTypeA )
{
	int nRet = COMM_HOST_ERROR;

	if( dict == NULL )
	{
		return nRet;
	}

	if( bTypeA != FALSE )
	{
		GList* pList = NULL;

		pList = dict->value;
		if( pList != NULL )
		{
			nRet = MakePrinterComData(wnd, DATATYPE_A_OP, 0, NULL, 0, dict->pKeyName, NULL);
			if( nRet == COMM_HOST_NO_ERROR )
			{
				while( pList != NULL )
				{
					char* pValue = pList->data;

					nRet = MakeDataType_StringCommon(wnd, DATATYPE_A_S, pValue, NULL);
					if( nRet != COMM_HOST_NO_ERROR )
					{
						break;
					}

					pList = g_list_next(pList);
				}

				if( nRet == COMM_HOST_NO_ERROR )
				{
					nRet = MakePrinterComData(wnd, DATATYPE_A_CL, 0, NULL, 0, NULL, NULL);
				}
			}
		}
	}
	else
	{
		char* const pValue = GetDictValuetype_char(dict);
		nRet = MakeDataType_StringCommon(wnd, DATATYPE_S, pValue, dict->pKeyName);
	}

	return nRet;
}

static int ReadDataType_IntCommon( const UIStatusWnd* const wnd, const char* const pKeyName, int* const pData, const int nType, const int nIndex )
{
	int nRet = COMM_HOST_ERROR;
	int nDataSize = 0;
	long lTemp = 0;
	BufTool* buftool = NULL;

	if( pData == NULL )
	{
		return nRet;
	}

	nRet =	ReadPrinterComData(wnd, nType, nIndex, pKeyName, NULL, &buftool, &nDataSize);
	if( nRet != COMM_HOST_NO_ERROR )
	{
		return nRet;
	}
	buftool_read_long(buftool, &lTemp);
	buftool_destroy(buftool);

	*pData = (int)lTemp;
	return nRet;
}

static int ReadDataType_StringCommon( const UIStatusWnd* const wnd, const char* const pKeyName, char** const pData, const int nType, const int nIndex )
{
	int nRet = COMM_HOST_ERROR;
	int nDataSize = 0;
	BufTool* buftool = NULL;

	if( (wnd == NULL) || (pData == NULL) )
	{
		return nRet;
	}

	nRet =	ReadPrinterComData(wnd, nType, nIndex, pKeyName, wnd->encoding, &buftool, &nDataSize);
	if( nRet != COMM_HOST_NO_ERROR )
	{
		return nRet;
	}

	*pData = mem_alloc((unsigned int)nDataSize+1u, __FILE__, __LINE__);
	buftool_read(buftool, *pData, nDataSize);
	buftool_destroy(buftool);

	return nRet;
}

static int ReadDataType_ArrayValue( const UIStatusWnd* const wnd, const char* const pKeyName, GList** const pList, const int nType )
{
	int nRet = COMM_HOST_ERROR;
	int nCount = 0;

	if( (pKeyName == NULL) || (pList == NULL) )
	{
		return nRet;
	}

	nRet = ReadDataType_IntCommon(wnd, pKeyName, &nCount, DATATYPE_A_CNT, 0);
	if( nRet != COMM_HOST_NO_ERROR )
	{
		return nRet;
	}
	nRet = ReadPrinterComData(wnd, DATATYPE_A_OP, 0, pKeyName, NULL, NULL, NULL);
	if( nRet == COMM_HOST_NO_ERROR )
	{
		int nIndex = 0;

		for( nIndex = 0; nIndex < nCount; ++nIndex )
		{
			switch( nType )
			{
				case DATATYPE_A_L:
				{
					int* pData = NULL;

					pData = mem_alloc(sizeof(int), __FILE__, __LINE__);
					nRet = ReadDataType_IntCommon(wnd, NULL, pData, nType, nIndex);
					if( nRet == COMM_HOST_NO_ERROR )
					{
						*pList = g_list_append_wrapper(*pList, (gpointer)pData, __FILE__, __LINE__);
					}
					else
					{
						mem_free(pData);
					}
					break;
				}
				case DATATYPE_A_S:
				{
					char* pData = NULL;

					nRet = ReadDataType_StringCommon(wnd, NULL, &pData, nType, nIndex);
					if( nRet == COMM_HOST_NO_ERROR )
					{
						if( strcmp(pData, " ") != 0 )
						{
							*pList = g_list_append_wrapper(*pList, (gpointer)pData, __FILE__, __LINE__);
						}
						else
						{
							mem_free(pData);
						}
					}
					break;
				}
				default:
				{
					UI_DEBUG("ReadDataType_ArrayValue Type value[%d] unknown\n", nType);
					nRet = COMM_HOST_ERROR;
					break;
				}
			}
			if( nRet != COMM_HOST_NO_ERROR )
			{
				break;
			}
		}
	}

	if( nRet == COMM_HOST_NO_ERROR )
	{
		nRet = ReadPrinterComData(wnd, DATATYPE_A_CL, 0, NULL, NULL, NULL, NULL);
	}

	return nRet;
}

static int ReadDataType_valueToGList( const UIStatusWnd* const wnd, const char* const pKeyName, GList** const pList, const int nType )
{
	int nRet = COMM_HOST_ERROR;
	if( pList == NULL )
	{
		return nRet;
	}

	switch( nType )
	{
		case DATATYPE_L:
		{
			int* pData = NULL;

			pData = mem_alloc(sizeof(int), __FILE__, __LINE__);
			nRet = ReadDataType_IntCommon(wnd, pKeyName, pData, nType, 0);
			if( nRet != COMM_HOST_NO_ERROR )
			{
				UI_DEBUG("ReadDataType_valueToGList ReadDataType_IntCommon error pKeyName[%s]\n", pKeyName);
				mem_free(pData);
				break;
			}

			*pList = g_list_append_wrapper(*pList, (gpointer)pData, __FILE__, __LINE__);
			break;
		}
		case DATATYPE_S:
		{
			char* pData = NULL;

			nRet = ReadDataType_StringCommon(wnd, pKeyName, &pData, nType, 0);
			if( nRet != COMM_HOST_NO_ERROR )
			{
				UI_DEBUG("ReadDataType_valueToGList ReadDataType_StringCommon error pKeyName[%s]\n", pKeyName);
				break;
			}

			if( strcmp(pData, " ") != 0 )
			{
				*pList = g_list_append_wrapper(*pList, (gpointer)pData, __FILE__, __LINE__);
			}
			else
			{
				UI_DEBUG("ReadDataType_valueToGList ReadDataType_StringCommon pKeyName[%s] return value = " "\n", pKeyName);
				mem_free(pData);
			}
			break;
		}
		case DATATYPE_A_L:
		case DATATYPE_A_S:
		{
			nRet = ReadDataType_ArrayValue(wnd, pKeyName, pList, nType);
			break;
		}
		default:
		{
			UI_DEBUG("ReadDataType_valueToGList Type value[%d] unknown\n", nType);
			nRet = COMM_HOST_ERROR;
			break;
		}
	}

	if( nRet != COMM_HOST_NO_ERROR )
	{
		if( *pList != NULL )
		{
			g_list_foreach(*pList, (GFunc)mem_free, NULL);
			g_list_free_wrapper(*pList);
		}
	}

	return nRet;
}

static int CreateSendData_MakeDataCommon( const UIStatusWnd* const wnd, const Dict* const dict, const gboolean bTypeA )
{
	int nRet = COMM_HOST_ERROR;

	if( dict == NULL )
	{
		return nRet;
	}

	switch( dict->type )
	{
		case DICT_TYPE_NUMBER:
		{
			nRet = MakeDataType_Int(wnd, dict, bTypeA);
			break;
		}
		case DICT_TYPE_STRING:
		{
			nRet = MakeDataType_String(wnd, dict, bTypeA);
			break;
		}
		default:
			UI_DEBUG("%s Type value unknown, from Line[%u] \n", __func__, __LINE__);
			nRet = COMM_HOST_ERROR;
			break;
	}


	return nRet;
}

static void GFunc_push_IDList( gpointer data, gpointer user_data )
{
	GList* pList = (GList*)user_data;
	Dict* const pValue = (Dict*)data;
	if( (pValue != NULL) && (pValue->value != NULL) )
	{
		pList = g_list_append_wrapper(pList, pValue->value->data, __FILE__, __LINE__);
	}
}

static int CreateSendData_GetData( const UIStatusWnd* const wnd, const Dict* const dict )
{
	int nRet = COMM_HOST_ERROR;
	Dict* temp = NULL;

	if( dict == NULL )
	{
		return nRet;
	}

	nRet = CreateSendData_MakeDataCommon(wnd, dict, FALSE);
	if( nRet != COMM_HOST_NO_ERROR )
	{
		return nRet;
	}

	temp = (Dict*)dict->next;
	if( temp != NULL )
	{
		GList* IDList = g_list_alloc_wrapper( __FILE__, __LINE__);
		Dict IDListDict = {0};

		g_list_foreach(temp->value, (GFunc)GFunc_push_IDList, (gpointer)IDList);

		IDList = g_list_delete_link_wrapper(IDList, IDList, __FILE__, __LINE__);

		IDListDict.pKeyName = KEY_ID_LIST;
		IDListDict.type = DICT_TYPE_NUMBER;
		IDListDict.value = IDList;

		nRet = CreateSendData_MakeDataCommon(wnd, &IDListDict, TRUE);
		g_list_free_wrapper(IDList);
	}

	return nRet;
}

static int CreateSendData_SetData_Item( const UIStatusWnd* const wnd, Dict* const dict )
{
	int nRet = COMM_HOST_ERROR;
	Dict* temp = dict;
	int nID = 0;

	if( temp == NULL )
	{
		return nRet;
	}

	nRet = CreateSendData_MakeDataCommon(wnd, temp, FALSE);
	if( nRet != COMM_HOST_NO_ERROR )
	{
		return nRet;
	}

	if( GetDictValuetype_int(temp, &nID) == FALSE )
	{
		nRet = COMM_HOST_ERROR;
		return nRet;
	}
	temp = (Dict*)temp->next;

	switch(nID)
	{
		case ID954:
		case ID964:
		case ID974:
		case ID1664:
		case ID1674:
		case ID1684:
		case ID1694:
		{
			int nIndex = 0;

			nRet = MakePrinterComData(wnd, DATATYPE_A_OP, 0, NULL, 0, KEY_ITEM, NULL);
			while( temp != NULL )
			{
				if( temp->type == DICT_TYPE_NUMBER )
				{
					int nValue = 0;

					if( GetDictValuetype_int(temp, &nValue) != FALSE )
					{
						nRet = MakeDataType_IntCommon(wnd, DATATYPE_A_L, nValue, NULL);
					}
					else
					{
						nRet = COMM_HOST_ERROR;
					}
				}
				else
				{
					char* const pDictValue = GetDictValuetype_char(temp);
					nRet = MakeDataType_StringCommon(wnd, DATATYPE_A_S, pDictValue, NULL);
				}

				if( nRet != COMM_HOST_NO_ERROR )
				{
					break;
				}

				temp = temp->next;
				++nIndex;
			}
			if( nRet == COMM_HOST_NO_ERROR )
			{
				nRet = MakePrinterComData(wnd, DATATYPE_A_CL, 0, NULL, 0, NULL, NULL);
			}
			break;
		}
		default:
		{
			gboolean bArray = FALSE;

			if( temp->type == DICT_TYPE_NUMBER )
			{
				bArray = TRUE;
			}

			nRet = CreateSendData_MakeDataCommon(wnd, temp, bArray);

			break;
		}
	}

	return nRet;
}

static int CreateSendData_SetData( const UIStatusWnd* const wnd, Dict* const dict )
{
	int nRet = COMM_HOST_ERROR;
	Dict* temp = dict;

	if( dict == NULL )
	{
		return nRet;
	}

	nRet = CreateSendData_MakeDataCommon(wnd, dict, FALSE);
	if( nRet != COMM_HOST_NO_ERROR )
	{
		return nRet;
	}

	temp = dict->next;
	if( temp != NULL )
	{
		nRet = COMM_HOST_ERROR;
		GList* const ItemList = temp->value;
		if( ItemList != NULL )
		{
			unsigned int nIndex = 0;
			for( nIndex = 0; nIndex < g_list_length(ItemList); ++nIndex )
			{
				Dict* ItemDict = NULL;

				nRet = MakePrinterComData(wnd, DATATYPE_D_OP, (int)nIndex, NULL, 0, temp->pKeyName, NULL);
				if( nRet != COMM_HOST_NO_ERROR )
				{
					break;
				}
				ItemDict = (Dict*)g_list_nth_data(ItemList, nIndex);

				nRet = CreateSendData_SetData_Item(wnd, ItemDict);
				if( nRet != COMM_HOST_NO_ERROR )
				{
					break;
				}

				nRet = MakePrinterComData(wnd, DATATYPE_D_CL, (int)nIndex, NULL, 0, NULL, NULL);
				if( nRet != COMM_HOST_NO_ERROR )
				{
					break;
				}
			}
		}
	}

	return nRet;
}

static int CreateSendData_Common( const UIStatusWnd* const wnd, Dict* const dict )
{
	int nRet = COMM_HOST_ERROR;
	Dict* tmp = dict;
	if( dict == NULL )
	{
		return nRet;
	}

	while( tmp != NULL )
	{
		nRet = CreateSendData_MakeDataCommon(wnd, tmp, FALSE);
		if( nRet != COMM_HOST_NO_ERROR )
		{
			break;
		}
		tmp = tmp->next;
	}
	return nRet;
}

static Dict* CreateDict_ReadDataAndMakeDict( const UIStatusWnd* const wnd, Dict* const dict, const char* const pKeyName, const int nType )
{
	int nRet = COMM_HOST_ERROR;
	GList* valueList = NULL;
	Dict* retDict = NULL;
	dict_type dicttype = DICT_TYPE_NUMBER;

	if( pKeyName == NULL )
	{
		return retDict;
	}

	nRet = ReadDataType_valueToGList(wnd, pKeyName, &valueList, nType);
	if( nRet != COMM_HOST_NO_ERROR )
	{
		return retDict;
	}

	switch( nType )
	{
		case DATATYPE_L:
		case DATATYPE_A_L:
		{
			dicttype = DICT_TYPE_NUMBER;
			break;
		}
		case DATATYPE_S:
		case DATATYPE_A_S:
		{
			dicttype = DICT_TYPE_STRING;
			break;
		}
		default:
		{
			UI_DEBUG("CreateDict_ReadDataAndMakeDict not support type[%d]\n", nType);
			break;
		}
	}
	retDict = CreateDict(dict, pKeyName, dicttype, valueList);

	if( valueList != NULL )
	{
		g_list_foreach(valueList, (GFunc)mem_free, NULL);
		g_list_free_wrapper(valueList);
	}

	return retDict;
}

#define PAPER_INFO_KEY_NUM 7

static int CreateDict_GetData_PaperInfo( const UIStatusWnd* const wnd, Dict* const dict )
{
	int nRet = COMM_HOST_ERROR;
	GList* keyList = NULL;
	int nItemIndex = 0;
	int nItemCount = 0;
	int i = 0;
	char* const pPaperInfoKey[PAPER_INFO_KEY_NUM] = { KEY_PAPER_SIZE,
													  KEY_PAPER_TYPE,
													  KEY_ORIENTATION,
													  KEY_CUSTOM_X,
													  KEY_CUSTOM_Y,
													  KEY_CUSTOM_UNIT,
													  NULL };

	nRet = ReadDataType_IntCommon(wnd, KEY_ITEM, &nItemCount, DATATYPE_A_CNT, 0);
	if( nRet != COMM_HOST_NO_ERROR )
	{
		return nRet;
	}

	nRet = ReadPrinterComData(wnd, DATATYPE_A_OP, 0, KEY_ITEM, NULL, NULL, NULL);
	if( nRet != COMM_HOST_NO_ERROR )
	{
		return nRet;
	}

	for(i = 0; pPaperInfoKey[i] != NULL ; i++)
	{
		keyList = g_list_append_wrapper(keyList, pPaperInfoKey[i], __FILE__, __LINE__);
	}

	for( nItemIndex = 0; nItemIndex < nItemCount; ++nItemIndex)
	{
		char* pKeyName_local = (char*)g_list_nth_data(keyList, (unsigned int)nItemIndex);
		int nValue = 0;
		char* pData = NULL;

		int compKeyX = strcmp(KEY_CUSTOM_X, pKeyName_local);
		int compKeyY = strcmp(KEY_CUSTOM_Y, pKeyName_local);
		if( (compKeyX == 0) || (compKeyY == 0) )
		{
			nRet = ReadDataType_IntCommon(wnd, NULL, &nValue, DATATYPE_A_L, nItemIndex);
			if( nRet != COMM_HOST_NO_ERROR )
			{
				break;
			}
			if( CreateDict_Number_Value(dict, pKeyName_local, &nValue) == NULL )
			{
				nRet = COMM_HOST_ERROR;
				break;
			}
		}
		else
		{
			nRet = ReadDataType_StringCommon(wnd, NULL, &pData, DATATYPE_A_S, nItemIndex);
			if( nRet != COMM_HOST_NO_ERROR )
			{
				break;
			}

			if( CreateDict_String_Value(dict, pKeyName_local, pData) == NULL )
			{
				nRet = COMM_HOST_ERROR;
			}

			if( pData != NULL )
			{
				mem_free(pData);
			}

			if( nRet != COMM_HOST_NO_ERROR )
			{
				break;
			}
		}

	}
	if( nRet == COMM_HOST_NO_ERROR )
	{
		nRet = ReadPrinterComData(wnd, DATATYPE_A_CL, 0, NULL, NULL, NULL, NULL);
	}
	g_list_free_wrapper( keyList );

	return nRet;
}

static int CreateDict_GetData_ItemValue( const UIStatusWnd* const wnd, Dict* const dict )
{
	int nRet = COMM_HOST_ERROR;
	int nID = 0;
	int nDictID = 0;
	int nIDType = 0;

	if( dict == NULL )
	{
		return nRet;
	}

	nRet = ReadDataType_IntCommon(wnd, dict->pKeyName, &nID, DATATYPE_L, 0);
	if( nRet != COMM_HOST_NO_ERROR )
	{
		return nRet;
	}

	if( GetDictValuetype_int(dict, &nDictID) == FALSE )
	{
		nRet = COMM_HOST_ERROR;
		return nRet;
	}

	if( nID != nDictID )
	{
		nRet = COMM_HOST_ERROR;
		return nRet;
	}

	nIDType = GET_ITEMIDDATATYPE(nID);
	switch( nIDType )
	{
		case ID_DATA_TYPE_LONG:
		{
			if( CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_ITEM, DATATYPE_A_L) == NULL )
			{
				nRet = COMM_HOST_ERROR;
			}
			break;
		}
		case ID_DATA_TYPE_STRING:
		{
			if( CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_ITEM, DATATYPE_S) == NULL )
			{
				nRet = COMM_HOST_ERROR;
			}
			break;
		}
		case ID_DATA_TYPE_BINARY:
		{
			UI_DEBUG("%s not support type, from Line[%u] \n", __func__, __LINE__);
			nRet = COMM_HOST_ERROR;
			break;
		}
		default:
		{
			switch( (unsigned int)nID )
			{
				case ID954:
				case ID964:
				case ID974:
				case ID1664:
				case ID1674:
				case ID1684:
				case ID1694:
				{
					nRet = CreateDict_GetData_PaperInfo(wnd, dict);
					break;
				}
				case ID120764:
				{
					CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_CONNECT_STATUS, DATATYPE_S);
					CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_WLAN_STATUS, DATATYPE_S);
					CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_WLAN_INFO, DATATYPE_A_L);
					CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_WLAN_STATUS_BSSID, DATATYPE_A_L);
					break;
				}
				default:
				{
					UI_DEBUG("CreateDict_GetDataResponsData not support ID[%d]\n", nID);
					nRet = COMM_HOST_ERROR;
					break;
				}
			}
			break;
		}
	}

	return nRet;
}

static int CreateDict_GetDataResponsData( const UIStatusWnd* const wnd, const Dict* const dict )
{
	int nRet = COMM_HOST_ERROR;
	Dict* ItemDict = NULL;
	int nCount = 0;
	unsigned int nIndex = 0;
	GList* pList = NULL;

	if( dict == NULL )
	{
		return nRet;
	}

	nRet = CheckResponsData_Common(wnd, dict, NULL);
	if( nRet != COMM_HOST_NO_ERROR )
	{
		return nRet;
	}

	ItemDict = dict->next;
	if( ItemDict == NULL )
	{
		return COMM_HOST_ERROR;
	}

	nRet = ReadDataType_IntCommon(wnd, ItemDict->pKeyName, &nCount, DATATYPE_D_CNT, 0);
	if( nRet != COMM_HOST_NO_ERROR )
	{
		return nRet;
	}

	pList = ItemDict->value;
	if( (unsigned int)nCount != g_list_length(pList) )
	{
		return COMM_HOST_ERROR;
	}

	for( nIndex = 0; nIndex < (unsigned int)nCount; ++nIndex )
	{
		Dict* IDDict = (Dict*)g_list_nth_data(pList, nIndex);

		if( IDDict == NULL )
		{
			nRet = COMM_HOST_ERROR;
			break;
		}

		nRet = ReadPrinterComData(wnd, DATATYPE_D_OP, (int)nIndex, ItemDict->pKeyName, NULL, NULL, NULL);
		if( nRet != COMM_HOST_NO_ERROR )
		{
			break;
		}

		nRet = CreateDict_GetData_ItemValue(wnd, IDDict);
		if( nRet != COMM_HOST_NO_ERROR )
		{
			break;
		}

		nRet = ReadPrinterComData(wnd, DATATYPE_D_CL, 0, NULL, NULL, NULL, NULL);
		if( nRet != COMM_HOST_NO_ERROR )
		{
			break;
		}
	}

	return nRet;
}

#define CONSUMABLE_KEY_NUM 13

typedef struct _ConsumableKey
{
	char *key;
	int type;
} ConsumableKey;

static int CreateDict_GetConsumableResponsData( const UIStatusWnd* const wnd, Dict* const dict )
{
	int nRet = COMM_HOST_ERROR;
	int i = 0;
	GList* keyList = NULL;
	unsigned int nIndex = 0;

	const ConsumableKey pConsumableKey[CONSUMABLE_KEY_NUM] =
	{
		{KEY_WARNING1, DATATYPE_A_S},
		{KEY_WARNING2, DATATYPE_A_S},
		{KEY_WARNING3, DATATYPE_A_S},
		{KEY_WARNING4, DATATYPE_A_S},
		{KEY_ABSENT, DATATYPE_A_S},
		{KEY_MISPLACE, DATATYPE_A_S},
		{KEY_MEMERROR, DATATYPE_A_S},
		{KEY_MOUNTERROR, DATATYPE_A_S},
		{KEY_SEALEDERROR, DATATYPE_A_S},
		{KEY_WARNING5, DATATYPE_A_S},
		{KEY_REMAIN_K, DATATYPE_L},
		{KEY_DRUMREMAIN_K, DATATYPE_L},
		{NULL, -1}
	};

	if( dict == NULL )
	{
		return nRet;
	}

	nRet = CheckResponsData_Common(wnd, dict, NULL);
	if( nRet != COMM_HOST_NO_ERROR )
	{
		return nRet;
	}

	for(i = 0; pConsumableKey[i].key != NULL; i++)
	{
		keyList = g_list_append_wrapper(keyList, pConsumableKey[i].key, __FILE__, __LINE__);
	}

	for( nIndex = 0; nIndex < g_list_length(keyList); ++nIndex )
	{
		char* const pKeyName_local = (char*)g_list_nth_data(keyList, nIndex);
		CreateDict_ReadDataAndMakeDict(wnd, dict, pKeyName_local, pConsumableKey[nIndex].type);
	}

	g_list_free_wrapper(keyList);

	return COMM_HOST_NO_ERROR;
}

static int GetStatus_NetWorkError( Dict* const dict )
{
	if( dict == NULL )
	{
		return COMM_HOST_ERROR;
	}

	CreateDict_String_Value(dict, KEY_STATUS_GRP, SGROUP_COMMERROR);
	CreateDict_String_Value(dict, KEY_STATUS, SCODE_NICCOMMERROR);

	return COMM_HOST_NO_ERROR;
}

static int GetStatus_LocalCommError( Dict* const dict )
{
	if( dict == NULL )
	{
		return COMM_HOST_ERROR;
	}

	CreateDict_String_Value(dict, KEY_STATUS_GRP, SGROUP_COMMERROR);
	CreateDict_String_Value(dict, KEY_STATUS, SCODE_LOCALCOMMERROR);

	return COMM_HOST_NO_ERROR;
}

static int GetStatus_PausePrinter( Dict* const dict )
{
	if( dict == NULL )
	{
		return COMM_HOST_ERROR;
	}

	CreateDict_String_Value(dict, KEY_STATUS_GRP, SGROUP_COMMERROR);
	CreateDict_String_Value(dict, KEY_STATUS, SCODE_PAUSEPRINTER);

	return COMM_HOST_NO_ERROR;
}

static int GetStatus_ErrorCommunicate( Dict* const dict, const int nError )
{
	int nRet = COMM_HOST_ERROR;

	switch( nError )
	{
		case COMM_HOST_NETWORK_ERROR:
		{
			GetStatus_NetWorkError(dict);
			nRet = COMM_HOST_NO_ERROR;
			break;
		}
		case COMM_HOST_USB_ERROR:
		{
			GetStatus_LocalCommError(dict);
			nRet = COMM_HOST_NO_ERROR;
			break;
		}
		case COMM_HOST_PRINTER_PAUSE:
		{
			GetStatus_PausePrinter(dict);
			nRet = COMM_HOST_NO_ERROR;
			break;
		}
		default:
			UI_DEBUG("GetStatus_ErrorCommunicate nError[%d]\n", nError);
			break;
	}

	return nRet;
}

static Dict* GetStatus_MakeModelCode( const UIStatusWnd* const wnd, Dict* const dict )
{
	char *pSupportedInfoStr = NULL;
	char **ppSeparateStr = NULL;
	if( (dict == NULL) || (wnd == NULL) )
	{
		return dict;
	}

	pSupportedInfoStr = CngplpGetValue_AddPrefix(wnd, SUPPORTEDPRINTER_KEY);
	if(pSupportedInfoStr != NULL)
	{
		UI_DEBUG("%s pSupportedInfoStr[%s], from Line[%u] \n", __func__, pSupportedInfoStr, __LINE__);
		ppSeparateStr = SeparateString(pSupportedInfoStr, CHARACTER_COMMA);
		mem_free(pSupportedInfoStr);
	}

	if( ppSeparateStr != NULL )
	{
		CreateDict_String_Value( dict, KEY_MODEL_CODE, ppSeparateStr[0] );
		mem_free_list(ppSeparateStr);
	}

	return dict;
}

static int GetStatus_ErrorDeviceResponse( const UIStatusWnd* const wnd, Dict* const dict, const int nError )
{
	int nRet = COMM_HOST_ERROR;

	if( dict == NULL )
	{
		return nRet;
	}

	switch( nError )
	{
		case ERROR_NIC:
		{
			nRet = GetStatus_NetWorkError(dict);
			break;
		}
		case ERROR_USB:
		{
			nRet = GetStatus_LocalCommError(dict);
			break;
		}
		case ERROR_DOWNLOADER_UPDATE:
		{
			CreateDict_String_Value(dict, KEY_STATUS_GRP, SGROUP_MAINTENANCE);
			CreateDict_String_Value(dict, KEY_STATUS, SCODE_UPDATINGFIRMWARE);
			GetStatus_MakeModelCode( wnd, dict );
			nRet = COMM_HOST_NO_ERROR;
			break;
		}
		case ERROR_DOWNLOADER_READY:
		{
			Dict* CodeDict = NULL;
			char* const pService = "E196 002";

			CreateDict_String_Value(dict, KEY_STATUS_GRP, SGROUP_SERVICE_ERROR);
			CreateDict_String_Value(dict, KEY_STATUS, SCODE_SERVICEERROR);
			GetStatus_MakeModelCode( wnd, dict );
			CodeDict = CreateDict_String_Value(NULL, KEY_CODE, pService);

			CreateDict_Dict_Value(dict, KEY_SERVICE_ERROR_CODE, CodeDict);
			nRet = COMM_HOST_NO_ERROR;
			break;
		}
		default:
			UI_DEBUG("GetStatus_ErrorDeviceResponse nError[%d]\n", nError);
			break;
	}

	return nRet;
}

#define COMMON_PAPER_INFO_KEY_NUM 5

static int GetStatus_Analyze_CommonPaperInfo( const UIStatusWnd* const wnd, Dict* const dict, const char* const pKey )
{
	int nRet = COMM_HOST_ERROR;
	int nCount = 0;
	int nIndex = 0;
	int i = 0;
	GList* PaperList = NULL;
	GList* KeyList = NULL;

	char * const pCommonPaperInfoKey[COMMON_PAPER_INFO_KEY_NUM] = { KEY_PAPER_SOURCE,
																	KEY_PAPER_SIZE,
																	KEY_PAPER_TYPE,
																	KEY_ORIENTATION,
																	NULL };


	if( ( wnd == NULL ) || ( dict == NULL ) || ( pKey == NULL ) )
	{
		return nRet;
	}

	nRet = ReadDataType_IntCommon(wnd, pKey, &nCount, DATATYPE_D_CNT, 0);
	if( nRet != COMM_HOST_NO_ERROR )
	{
		return nRet;
	}

	for(i = 0; pCommonPaperInfoKey[i] != NULL; i++)
	{
		KeyList = g_list_append_wrapper(KeyList, pCommonPaperInfoKey[i], __FILE__, __LINE__);
	}

	for( nIndex = 0; nIndex < nCount; ++nIndex )
	{
		Dict* PaperDict = NULL;
		int nDictRet = 0;
		unsigned int nKeyIndex = 0;

		nDictRet = ReadPrinterComData(wnd, DATATYPE_D_OP, nIndex, pKey, NULL, NULL, NULL);
		if( nDictRet != COMM_HOST_NO_ERROR )
		{
			nRet = COMM_HOST_ERROR;
			break;
		}

		for( nKeyIndex = 0; nKeyIndex < g_list_length(KeyList); ++nKeyIndex )
		{
			char* pKeyName_local = (char*)g_list_nth_data(KeyList, nKeyIndex);
			Dict* tempDict = NULL;

			tempDict = CreateDict_ReadDataAndMakeDict(wnd, PaperDict, pKeyName_local, DATATYPE_S);
			if( tempDict == NULL )
			{
				nRet = COMM_HOST_ERROR;
				break;
			}
			else
			{
				PaperDict = tempDict;
			}
		}

		if( nRet != COMM_HOST_NO_ERROR )
		{
			DeleteDict(PaperDict);
			break;
		}
		else
		{
			DebugOutputDict(PaperDict);
			PaperList = g_list_append_wrapper(PaperList, (gpointer)PaperDict, __FILE__, __LINE__);
		}

		nDictRet = ReadPrinterComData(wnd, DATATYPE_D_CL, 0, NULL, NULL, NULL, NULL);
		if( nDictRet != COMM_HOST_NO_ERROR )
		{
			nRet = COMM_HOST_ERROR;
			break;
		}
	}

	if( nRet == COMM_HOST_NO_ERROR )
	{
		if( CreateDict(dict, pKey, DICT_TYPE_DICT, PaperList ) == NULL )
		{
			nRet = COMM_HOST_ERROR;
		}
	}

	if( PaperList != NULL )
	{
		if( nRet != COMM_HOST_NO_ERROR )
		{
			g_list_foreach(PaperList, (GFunc)DeleteDict, NULL );
		}
		g_list_free_wrapper(PaperList);
	}

	g_list_free_wrapper(KeyList);

	return nRet;
}

static int GetStatus_Analyze_PaperInfoList( const UIStatusWnd* const wnd, Dict* const dict )
{
	int nRet = COMM_HOST_ERROR;

	nRet = GetStatus_Analyze_CommonPaperInfo(wnd, dict, KEY_PAPER_LIST);

	return nRet;
}
static int GetStatus_Analyze_PaperError( const UIStatusWnd* const wnd, Dict* const dict )
{
	int nRet = COMM_HOST_ERROR;

	nRet = GetStatus_Analyze_CommonPaperInfo(wnd, dict, KEY_ERROR_PAPER_STATUS);

	return nRet;
}

static int GetStatus_Analyze_ServiceError( const UIStatusWnd* const wnd, Dict* const dict )
{
	int nRet = COMM_HOST_ERROR;
	int nCount = 0;
	int nIndex = 0;
	GList* CodeList = NULL;

	if( dict == NULL )
	{
		return nRet;
	}

	nRet = ReadDataType_IntCommon(wnd, KEY_SERVICE_ERROR_CODE, &nCount, DATATYPE_D_CNT, 0);
	if( nRet != COMM_HOST_NO_ERROR )
	{
		return nRet;
	}

	for( nIndex = 0; nIndex < nCount; ++nIndex )
	{
		Dict* CodeDict = NULL;

		nRet = ReadPrinterComData(wnd, DATATYPE_D_OP, nIndex, KEY_SERVICE_ERROR_CODE, NULL, NULL, NULL);
		if( nRet != COMM_HOST_NO_ERROR )
		{
			break;
		}

		CodeDict = CreateDict_ReadDataAndMakeDict(wnd, NULL, KEY_CODE, DATATYPE_S);
		if( CodeDict == NULL )
		{
			nRet = COMM_HOST_ERROR;
			break;
		}

		CodeList = g_list_append_wrapper(CodeList, (gpointer)CodeDict, __FILE__, __LINE__);

		nRet = ReadPrinterComData(wnd, DATATYPE_D_CL, 0, NULL, NULL, NULL, NULL);
		if( nRet != COMM_HOST_NO_ERROR )
		{
			break;
		}
	}

	if( nRet == COMM_HOST_NO_ERROR )
	{
		if( CreateDict(dict, KEY_SERVICE_ERROR_CODE, DICT_TYPE_DICT, CodeList ) == NULL )
		{
			nRet = COMM_HOST_ERROR;
		}
	}

	if( CodeList != NULL )
	{
		if( nRet != COMM_HOST_NO_ERROR )
		{
			g_list_foreach(CodeList, (GFunc)DeleteDict, NULL );
		}
		g_list_free_wrapper(CodeList);
	}

	return nRet;
}

static int GetStatus_AnalyzeStatus( const UIStatusWnd* const wnd, Dict* const dict )
{
	CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_STATUS_GRP, DATATYPE_S);
	CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_STATUS, DATATYPE_S);
	CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_EQUIPMENT, DATATYPE_A_S);
	CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_OPERATION, DATATYPE_A_S);

	CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_PAPER_WARNING, DATATYPE_A_S);

	CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_TONER_LIFETIME_WARNING, DATATYPE_A_S);
	CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_TONEROUT2_WARNING, DATATYPE_A_S);
	CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_TONEROUT1_WARNING, DATATYPE_A_S);
	CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_TONER_MEMORY_WARNING, DATATYPE_A_S);
	CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_CONSUMABLE_ERROR, DATATYPE_A_S);

	CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_JAM_ACCESS, DATATYPE_A_S);
	CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_COVER_POS, DATATYPE_A_S);
	CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_WAIT_DETAIL, DATATYPE_A_S);
	CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_OTHER_WAR, DATATYPE_A_S);
	CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_TONEROUT3_WARNING, DATATYPE_A_S);

	CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_TONER_ACCESS, DATATYPE_A_S);
	CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_MODEL_CODE, DATATYPE_S);

	GetStatus_Analyze_PaperError(wnd, dict);

	GetStatus_Analyze_PaperInfoList(wnd, dict);

	GetStatus_Analyze_ServiceError(wnd, dict);

	CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_DOCUMENT, DATATYPE_S);
	CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_USER, DATATYPE_S);
	CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_JOB_ID, DATATYPE_L);
	CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_JOB_STATUS, DATATYPE_S);
	CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_TOTAL_PAGE, DATATYPE_L);
	CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_PRINTED_PAGE, DATATYPE_L);
	CreateDict_ReadDataAndMakeDict(wnd, dict, KEY_AREAINFO, DATATYPE_S);

	return COMM_HOST_NO_ERROR;
}

static int CreateDict_GetStatusResponsData( const UIStatusWnd* const wnd, Dict* const dict )
{
	int nRet = COMM_HOST_ERROR;
	int nError = 0;

	nRet = CheckResponsData_Common(wnd, dict, &nError);
	if( nRet != COMM_HOST_NO_ERROR )
	{
		nRet = GetStatus_ErrorDeviceResponse(wnd, dict, nError);
	}
	else
	{
		nRet = GetStatus_AnalyzeStatus(wnd, dict);
	}

	return nRet;
}

static int CheckResponsData_SetData( const UIStatusWnd* const wnd, Dict* const dict )
{
	int nRet = COMM_HOST_ERROR;
	Dict* temp = dict;
	GList* ResIDList = NULL;

	if( dict == NULL )
	{
		return nRet;
	}

	nRet = CheckResponsData_Common(wnd, dict, NULL);
	if( nRet != COMM_HOST_NO_ERROR )
	{
		return nRet;
	}

	nRet = ReadDataType_valueToGList(wnd, KEY_ID_LIST, &ResIDList, DATATYPE_A_L);
	if( nRet != COMM_HOST_NO_ERROR )
	{
		return nRet;
	}

	temp = dict->next;
	if( temp != NULL )
	{
		GList* SendIDList = g_list_alloc_wrapper( __FILE__, __LINE__);

		g_list_foreach(temp->value, (GFunc)GFunc_push_IDList, (gpointer)SendIDList);

		SendIDList = g_list_delete_link_wrapper(SendIDList, SendIDList, __FILE__, __LINE__);

		if ( CompareGListValue(SendIDList, ResIDList, DICT_TYPE_NUMBER) == FALSE )
		{
			nRet = COMM_HOST_ERROR;
		}

		g_list_free_wrapper(SendIDList);
	}

	if( ResIDList != NULL )
	{
		g_list_foreach(ResIDList, (GFunc)mem_free, NULL);
		g_list_free_wrapper(ResIDList);
	}

	return nRet;
}

static int CheckResponsData_Common( const UIStatusWnd* const wnd, const Dict* const dict, int* const pError )
{
	int nRet = COMM_HOST_ERROR;
	int nCommand = 0;
	int nDictCommand = 0;
	int nError = 0;

	if( dict == NULL )
	{
		return nRet;
	}
	nRet = ReadDataType_IntCommon(wnd, dict->pKeyName, &nCommand, DATATYPE_L, 0);
	if( nRet != COMM_HOST_NO_ERROR )
	{
		UI_DEBUG("%s do not get Command value form key[%s]\n", __func__, dict->pKeyName);
		return nRet;
	}

	if( GetDictValuetype_int(dict, &nDictCommand) == FALSE )
	{
		nRet = COMM_HOST_ERROR;
		UI_DEBUG("%s do not get Argment dict Command value form key[%s]\n", __func__, dict->pKeyName);
		return nRet;
	}

	if( nCommand != nDictCommand )
	{
		UI_DEBUG("%s Do not Agree Out Command[%d], In Command[%d]\n", __func__, nCommand, nDictCommand);
		return COMM_HOST_ERROR;
	}

	nRet = ReadDataType_IntCommon(wnd, KEY_ERROR, &nError, DATATYPE_L, 0);
	if( nRet != COMM_HOST_NO_ERROR )
	{
		return COMM_HOST_NO_ERROR;
	}
	if( pError != NULL )
	{
		*pError = nError;
	}
	UI_DEBUG("%s Error key value[%d]\n", __func__, nError);
	return COMM_HOST_ERROR;
}
